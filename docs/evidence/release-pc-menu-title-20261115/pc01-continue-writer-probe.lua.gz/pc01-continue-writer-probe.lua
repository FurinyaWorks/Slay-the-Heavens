package.path='build/lua/?.lua;src/lua/?.lua;'..package.path
local Theme=require('abyss_theme');Theme.presentationProfile='official-assets-first'
local V25=require('abyss_v25_menu_view')
local function control(name)
 local c={name=name,children={},visible=true}
 function c:GetChild(k)return self.children[k]end
 function c:SetVisible(v)self.visible=v end
 function c:SetAnchoredPosition(x,y)self.x,self.y=x,y end
 function c:SetSizeDelta(w,h)self.w,self.h=w,h end
 return c
end
local function button(name)
 local c=control(name)
 for _,n in ipairs({'label','v25MenuFace','menuAccent'})do c.children[n]=control(n)end
 for _,n in ipairs({'normal','hover','pressed','disabled'})do c.children.v25MenuFace.children[n]=control(n)end
 c.children.menuAccent.children.line=control('line');c.children.menuAccent.children.line.imageColor={a=0}
 return c
end
local start,quit,resume=button('start'),button('titleQuit'),button('continueRun')
local menu=control('menu');menu.children.titleQuit,menu.children.continueRun=quit,resume
local ctx={start=start,menu=menu,owner={mode='menu',sessionPaused=true,motion={}},platform={color=function(r,g,b,a)return{r=r,g=g,b=b,a=a}end}}
for _,c in ipairs({start,quit,resume})do V25.button(c,true)end
V25.pointer(start,'enter',true);V25.pointer(resume,'enter',true)
V25.animateMenu(ctx,.2)
assert(start.children.menuAccent.children.line.imageColor.a==255)
assert(resume.children.v25MenuFace.children.hover.visible,'resume still changes its static face')
print('PC01_CONTINUE_WRITER startAlpha='..start.children.menuAccent.children.line.imageColor.a..' resumeAlpha='..resume.children.menuAccent.children.line.imageColor.a..' resumeFaceHover='..tostring(resume.children.v25MenuFace.children.hover.visible))
assert(resume.children.menuAccent.children.line.imageColor.a>0,'existing Continue never receives the menu hover animation writer')
