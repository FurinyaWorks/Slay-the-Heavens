package.path="F:/New folder/.artifacts/release-pc-qa-20261115/pc07-build/?.lua;F:/New folder/.worktrees/release-pc-map-bounds-1116/src/lua/?.lua"
local Map=require('abyss_map');local Data=require('abyss_data')
for _,act in ipairs({1,2})do for _,seed in ipairs({"0","1","-17","42","200","313","600","65535","20261023","123456789","673465884448","2780424839485660359"})do
 local map=Map.generate(Data,seed,act)
 for _,n in ipairs(map.nodes)do print(table.concat({act,seed,n.floor-(map.firstFloor or 1)+1,n.lane},'	'))end
end end