import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import crypto from 'node:crypto';
const root='F:/New folder',tree=root+'/.worktrees/release-pc-map-bounds-1116',out=root+'/.artifacts/release-pc-qa-20261115';
process.chdir(tree);
process.env.TEMP=process.env.TMP=out+'/tmp';fs.mkdirSync(process.env.TEMP,{recursive:true});
const mod=n=>import(pathToFileURL(tree+'/scripts/'+n));
const {buildUI}=await mod('build-ui.mjs'),{buildLuaData,luaString,toLua}=await mod('build-lua-data.mjs');
const build=out+'/pc07-build';fs.mkdirSync(build,{recursive:true});
buildLuaData('data',build+'/abyss_data.lua');buildUI(build,undefined,{officialAssets:true,nativePageLifecycle:true});
const modules=fs.readdirSync(build).filter(n=>n.endsWith('.lua')).map(n=>n.slice(0,-4));
const seeds=[0,1,-17,42,200,313,600,65535,20261023,123456789,'673465884448','2780424839485660359'];
const source=`package.path=${luaString(build+'/?.lua;'+tree+'/src/lua/?.lua')}
for _,name in ipairs(${toLua(modules)})do package.preload[name]=assert(loadfile(${luaString(build)}..'/'..name..'.lua'))end
local F=dofile('tests/lua/support/game_ui_fixture.lua');local Map=require('abyss_map')
local function initial(c,s)
 c.position=s.position or {0,0};c.size=s.size;c.scale=s.scale or {1,1};c.rotation=s.rotation or 0
 c.imageId=s.image;c.opacity=s.opacity or 1
 for _,d in ipairs(s.children or {})do initial(c:GetChild(d.name),d)end
end
local function world(c)
 local p=c.position or {0,0};local x,y=c.x or p[1],c.y or p[2]
 local scale=c.scale or {1,1};local sx,sy=c.localScaleX or scale[1],c.localScaleY or scale[2]
 local angle=c.localRotationZ or (type(c.rotation)=='table' and c.rotation[3] or c.rotation) or 0
 if c.parent then
  local px,py,psx,psy,pa=world(c.parent);local rad=pa*math.pi/180
  x,y=px+x*psx*math.cos(rad)-y*psy*math.sin(rad),py+x*psx*math.sin(rad)+y*psy*math.cos(rad)
  sx,sy,angle=sx*psx,sy*psy,angle+pa
 end
 return x,y,sx,sy,angle
end
local function emit(kind,c,seed,floor,scroll,nodeId,part)
 local x,y,sx,sy,a=world(c);local size=c.size or {0,0};local w,h=c.sizeDeltaX or size[1],c.sizeDeltaY or size[2]
 print(table.concat({kind,tostring(seed),floor,scroll,nodeId or '',part or '',x,y,w*sx,h*sy,a,c.opacity or 1,c.imageId or 0},'\t'))
end
local checks=0
for _,seed in ipairs(${toLua(seeds)})do
 local canvas=F.control({children=F.Layout})
 for _,s in ipairs(F.Layout)do initial(canvas:GetChild(s.name),s)end
 local root=F.Viewport.apply(canvas,1280,720)
 local h=F.GameUI.new(root,F.Data,F.Presentation,'click',{seed=seed,nativeMonsterArtEnabled=false,imageSource='static',color=function(r,g,b,a)return{r=r,g=g,b=b,a=a}end})
 root.ui=h;assert(F.start(h));assert(h.mode=='map' and h.map.runSeed==tostring(seed))
 local panel=root:GetChild('mapPanel');local legend=F.mapControl(panel,'typeLegend')
 local function chrome(c,p)
  if c.visible==false then return end
  if c.kind=='image'then emit('legend',c,seed,0,0,'',p)end
  for name,child in pairs(c.children)do chrome(child,p..'/'..name)end
 end
 chrome(legend,'typeLegend')
 local function audit()
  checks=checks+1
  for i,n in ipairs(h.map.nodes)do
   local box=F.mapControl(panel,'node'..i)
   if box.visible then
    for _,part in ipairs({'icon','ring','positionToken','emeraldLabel','hit'})do local c=box:GetChild(part)
     if c.visible~=false then emit('node',c,seed,h.map.floor,h.mapUI.scroll,n.id,part)end
    end
   end
  end
  for i=1,126 do local c=F.mapControl(panel,'edge'..i);if c.visible then emit('edge',c,seed,h.map.floor,h.mapUI.scroll,'edge'..i,'dash-parent-conservative')end end
 end
 -- All initial scroll pages, then a legal rightmost path. Frontier isolation
 -- uses real Map.choose; it does not claim to complete gameplay rooms.
 for scroll=0,850,38 do assert(h.mapUI:setScroll(scroll));audit()end
 for i=1,17 do
  local options=Map.available(h.map);table.sort(options,function(a,b)return a.lane>b.lane end)
  assert(Map.choose(h.map,assert(options[1]).id));h.run.floor=h.map.floor
  h.mapUI:setNavigationEnabled(true);assert(h.mapUI:focusCurrent());audit()
  for _,fx in ipairs(h.mapUI.activeFx)do if fx.visible and fx.state=='available'then fx.hovered=true end end
  h.mapUI:update(.17);audit()
 end
end
print('CHECKS\t'..checks)
`;
fs.writeFileSync(out+'/pc07-audit.lua',source);
const require=createRequire(pathToFileURL(root+'/.worktrees/release-pc-closeout-1115/package.json'));
const r=spawnSync(process.execPath,[require.resolve('fengari-node-cli/src/lua-cli.js'),'-e',`dofile(${luaString(out+'/pc07-audit.lua')})`],{cwd:tree,encoding:'utf8',timeout:120000,maxBuffer:32*1024*1024});
fs.writeFileSync(out+'/pc07-audit.stdout.tsv',r.stdout??'');fs.writeFileSync(out+'/pc07-audit.stderr.log',r.stderr??'');
if(r.status!==0)throw Error(JSON.stringify({status:r.status,error:String(r.error??''),stderr:r.stderr,tail:r.stdout?.slice(-3000)}));
const rows=r.stdout.trim().split(/\r?\n/).map(l=>l.split('\t'));
const data=rows.filter(r=>['legend','node','edge'].includes(r[0])).map(r=>({kind:r[0],seed:r[1],floor:+r[2],scroll:+r[3],node:r[4],part:r[5],x:+r[6],y:+r[7],w:+r[8],h:+r[9],angle:+r[10],opacity:+r[11],image:+r[12]}));
const vertices=r=>{const a=r.angle*Math.PI/180,c=Math.cos(a),s=Math.sin(a);return [[-1,-1],[1,-1],[1,1],[-1,1]].map(([x,y])=>[r.x+x*r.w/2*c-y*r.h/2*s,r.y+x*r.w/2*s+y*r.h/2*c]);};
function intersects(a,b){const av=vertices(a),bv=vertices(b);for(const v of [av,bv])for(let i=0;i<4;i++){const p=v[i],q=v[(i+1)%4],axis=[-(q[1]-p[1]),q[0]-p[0]],project=v=>v.map(p=>p[0]*axis[0]+p[1]*axis[1]);const aa=project(av),bb=project(bv);if(Math.max(...aa)<=Math.min(...bb)+1e-7||Math.max(...bb)<=Math.min(...aa)+1e-7)return false;}return true;}
const legends=new Map(seeds.map(s=>[String(s),data.filter(r=>r.kind==='legend'&&r.seed===String(s))]));
const collisions=[];
for(const r of data.filter(r=>r.kind!=='legend'))for(const c of legends.get(r.seed))if(intersects(r,c))collisions.push({...r,legendPart:c.part,legendImage:c.image,legendOpacity:c.opacity});
const dedup=Object.values(Object.fromEntries(collisions.map(r=>[[r.seed,r.floor,r.scroll,r.node,r.part,r.legendPart].join('|'),r])));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const report={status:'BOUNDED_SOURCE_AUDIT',base:'36b9b157ee6f05b65eb9f1da7e2978647d36c210',profile:{officialAssets:true,nativePageLifecycle:true},seeds,checks:+rows.find(r=>r[0]==='CHECKS')[1],scope:'Real generated Host and MapUI; initial scrolling and legal rightmost frontiers, no official client or gameplay-room completion',rowCounts:Object.fromEntries(['legend','node','edge'].map(k=>[k,data.filter(r=>r.kind===k).length])),overlapCounts:{total:dedup.length,node:dedup.filter(r=>r.kind==='node').length,edge:dedup.filter(r=>r.kind==='edge').length,excludingShadow:dedup.filter(r=>!r.legendPart.endsWith('/shadow')).length},affectedSeeds:[...new Set(dedup.map(r=>r.seed))],collisions:dedup,limitations:['Texture alpha / real pixel coverage unknown; image rectangles and ring rotation are conservative native geometry bounds.','Dashed route parent is conservative; gaps are not treated as painted pixels.','Original private PNG and original seed unavailable; this is not reproduction of screenshot01.'],inputs:Object.fromEntries(['scripts/map-ui-layout.mjs','scripts/v25-map-layout.mjs','scripts/v25-layout.mjs','scripts/official-assets-layout.mjs','src/lua/abyss_map_ui.lua','src/lua/abyss_map.lua','data/presentation/ui_theme.json','tests/lua/support/game_ui_fixture.lua'].map(p=>[p,sha(tree+'/'+p)])),artifacts:Object.fromEntries(['pc07-audit.mjs','pc07-audit.lua','pc07-audit.stdout.tsv','pc07-audit.stderr.log'].map(p=>[p,sha(out+'/'+p)]))};
fs.writeFileSync(out+'/pc07-source-intake.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,collisions:report.collisions.slice(0,8)},null,2));
