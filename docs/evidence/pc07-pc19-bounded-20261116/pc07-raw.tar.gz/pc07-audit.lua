package.path="F:/New folder/.artifacts/release-pc-qa-20261115/pc07-build/?.lua;F:/New folder/.worktrees/release-pc-map-bounds-1116/src/lua/?.lua"
for _,name in ipairs({"abyss_art_features","abyss_component_binding","abyss_data","abyss_map_controls","abyss_map_layout","abyss_menu_background_asset","abyss_monster_actor_binding","abyss_monster_art_data","abyss_narrative","abyss_original_v4_data","abyss_presentation","abyss_ready_card_assets","abyss_ready_card_binding","abyss_theme","abyss_traveler_portrait_assets","abyss_ui_layout","abyss_ui_profile","abyss_ui_templates","abyss_v25_card_assets"})do package.preload[name]=assert(loadfile("F:/New folder/.artifacts/release-pc-qa-20261115/pc07-build"..'/'..name..'.lua'))end
local F=dofile('tests/lua/support/game_ui_fixture.lua');local Map=require('abyss_map')
local function initial(c,s)
 c.position=s.position or {0,0};c.size=s.size;c.scale=s.scale or {1,1};c.rotation=s.rotation or 0
 c.imageId=s.image;c.opacity=s.opacity or 1
 for _,d in ipairs(s.children or {})do initial(c:GetChild(d.name),d)end
end
local function world(c)
 local p=c.position or {0,0};local x,y=c.x or p[1],c.y or p[2]
 local scale=c.scale or {1,1};local sx,sy=c.localScaleX or scale[1],c.localScaleY or scale[2]
 local angle=c.localRotationZ or (type(c.rotation)=='table' and c.rotation[3] or c.rotation) or 0
 if c.parent then
  local px,py,psx,psy,pa=world(c.parent);local rad=pa*math.pi/180
  x,y=px+x*psx*math.cos(rad)-y*psy*math.sin(rad),py+x*psx*math.sin(rad)+y*psy*math.cos(rad)
  sx,sy,angle=sx*psx,sy*psy,angle+pa
 end
 return x,y,sx,sy,angle
end
local function emit(kind,c,seed,floor,scroll,nodeId,part)
 local x,y,sx,sy,a=world(c);local size=c.size or {0,0};local w,h=c.sizeDeltaX or size[1],c.sizeDeltaY or size[2]
 print(table.concat({kind,tostring(seed),floor,scroll,nodeId or '',part or '',x,y,w*sx,h*sy,a,c.opacity or 1,c.imageId or 0},'	'))
end
local checks=0
for _,seed in ipairs({0,1,-17,42,200,313,600,65535,20261023,123456789,"673465884448","2780424839485660359"})do
 local canvas=F.control({children=F.Layout})
 for _,s in ipairs(F.Layout)do initial(canvas:GetChild(s.name),s)end
 local root=F.Viewport.apply(canvas,1280,720)
 local h=F.GameUI.new(root,F.Data,F.Presentation,'click',{seed=seed,nativeMonsterArtEnabled=false,imageSource='static',color=function(r,g,b,a)return{r=r,g=g,b=b,a=a}end})
 root.ui=h;assert(F.start(h));assert(h.mode=='map' and h.map.runSeed==tostring(seed))
 local panel=root:GetChild('mapPanel');local legend=F.mapControl(panel,'typeLegend')
 local function chrome(c,p)
  if c.visible==false then return end
  if c.kind=='image'then emit('legend',c,seed,0,0,'',p)end
  for name,child in pairs(c.children)do chrome(child,p..'/'..name)end
 end
 chrome(legend,'typeLegend')
 local function audit()
  checks=checks+1
  for i,n in ipairs(h.map.nodes)do
   local box=F.mapControl(panel,'node'..i)
   if box.visible then
    for _,part in ipairs({'icon','ring','positionToken','emeraldLabel','hit'})do local c=box:GetChild(part)
     if c.visible~=false then emit('node',c,seed,h.map.floor,h.mapUI.scroll,n.id,part)end
    end
   end
  end
  for i=1,126 do local c=F.mapControl(panel,'edge'..i);if c.visible then emit('edge',c,seed,h.map.floor,h.mapUI.scroll,'edge'..i,'dash-parent-conservative')end end
 end
 -- All initial scroll pages, then a legal rightmost path. Frontier isolation
 -- uses real Map.choose; it does not claim to complete gameplay rooms.
 for scroll=0,850,38 do assert(h.mapUI:setScroll(scroll));audit()end
 for i=1,17 do
  local options=Map.available(h.map);table.sort(options,function(a,b)return a.lane>b.lane end)
  assert(Map.choose(h.map,assert(options[1]).id));h.run.floor=h.map.floor
  h.mapUI:setNavigationEnabled(true);assert(h.mapUI:focusCurrent());audit()
  for _,fx in ipairs(h.mapUI.activeFx)do if fx.visible and fx.state=='available'then fx.hovered=true end end
  h.mapUI:update(.17);audit()
 end
end
print('CHECKS	'..checks)
