import fs from 'node:fs';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root='F:/New folder',tree=root+'/.worktrees/release-pc-map-bounds-1116',out=root+'/.artifacts/release-pc-qa-20261115';
const report=JSON.parse(fs.readFileSync(out+'/pc07-source-intake.json','utf8'));
const rows=fs.readFileSync(out+'/pc07-audit.stdout.tsv','utf8').trim().split(/\r?\n/).map(l=>l.split('\t'));
const legends=rows.filter(r=>r[0]==='legend').map(r=>({seed:r[1],part:r[5],x:+r[6],y:+r[7],w:+r[8],h:+r[9],angle:+r[10],opacity:+r[11],image:+r[12]}));
function circleRect(circle,rect){
 const a=-rect.angle*Math.PI/180,dx=circle.x-rect.x,dy=circle.y-rect.y;
 const x=dx*Math.cos(a)-dy*Math.sin(a),y=dx*Math.sin(a)+dy*Math.cos(a);
 const qx=Math.max(0,Math.abs(x)-rect.w/2),qy=Math.max(0,Math.abs(y)-rect.h/2);
 return qx*qx+qy*qy<(circle.w/2)**2-1e-7;
}
const refined=report.collisions.filter(r=>{const c=legends.find(c=>c.seed===r.seed&&c.part===r.legendPart);return c.image!==100002||circleRect(c,r);});
const rectOnlyFalsePositives=report.collisions.filter(r=>!refined.includes(r));
const opaque=refined.filter(r=>!r.legendPart.endsWith('/shadow'));
const build=out+'/pc07-build';
const q=s=>JSON.stringify(s);
const lua=`package.path=${q(build+'/?.lua;'+tree+'/src/lua/?.lua')}
local Map=require('abyss_map');local Data=require('abyss_data')
for _,act in ipairs({1,2})do for _,seed in ipairs({${report.seeds.map(s=>q(String(s))).join(',')}})do
 local map=Map.generate(Data,seed,act)
 for _,n in ipairs(map.nodes)do print(table.concat({act,seed,n.floor-(map.firstFloor or 1)+1,n.lane},'\t'))end
end end`;
fs.writeFileSync(out+'/pc07-topology.lua',lua);
const req=createRequire(pathToFileURL(root+'/.worktrees/release-pc-closeout-1115/package.json'));
const r=spawnSync(process.execPath,[req.resolve('fengari-node-cli/src/lua-cli.js'),'-e',`dofile(${q(out+'/pc07-topology.lua')})`],{cwd:tree,encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
fs.writeFileSync(out+'/pc07-topology.stdout.tsv',r.stdout??'');fs.writeFileSync(out+'/pc07-topology.stderr.log',r.stderr??'');
if(r.status!==0)throw Error(r.stderr+String(r.error??''));
const nodes=r.stdout.trim().split(/\r?\n/).map(l=>l.split('\t')).map(([act,seed,floor,lane])=>({act:+act,seed,floor:+floor,lane:+lane,x:(+lane-4)*112}));
const distributions=[];
for(const act of [1,2])for(const seed of report.seeds.map(String)){
 const n=nodes.filter(n=>n.act===act&&n.seed===seed),bands={};
 for(const [name,lo,hi] of [['lower',1,5],['middle',6,10],['upper',11,15]]){
  const band=n.filter(n=>n.floor>=lo&&n.floor<=hi);
  bands[name]={nodes:band.length,minX:Math.min(...band.map(n=>n.x)),maxX:Math.max(...band.map(n=>n.x)),meanX:Math.round(band.reduce((s,n)=>s+n.x,0)/band.length*100)/100};
 }
 distributions.push({act,seed,bands});
}
const layout=JSON.parse(fs.readFileSync(build+'/game-ui.json','utf8'));
const stage=layout.controls.find(c=>c.name==='stage'),panel=stage.children.find(c=>c.name==='mapPanel');
const controls=panel.children.filter(c=>/^mapGroup\d+$/.test(c.name)).flatMap(c=>c.children);
const order={legend:controls.findIndex(c=>c.name==='typeLegend'),firstEdge:controls.findIndex(c=>c.name==='edge1'),firstNode:controls.findIndex(c=>c.name==='node1')};
const legend=controls.find(c=>c.name==='typeLegend');const flat=n=>[n,...(n.children??[]).flatMap(flat)];
const prList=JSON.parse(fs.readFileSync(out+'/pc07-open-prs.json','utf8'));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
report.interpretation={status:'NO_PRODUCT_FIX_JUSTIFIED_BY_CURRENT_EVIDENCE',refinedOpaqueImageVsPaintedNodeOverlap:opaque.filter(r=>r.kind==='node'&&r.part!=='hit').length,
 opaqueImageVsInvisibleHit:opaque.length,boundingSquareFalsePositives:rectOnlyFalsePositives.length,shadowTextureRectangles:refined.filter(r=>r.legendPart.endsWith('/shadow')).length,
 reason:'Only opaque contact is 7/12 seeds at floor2/scroll0, f3_l7 invisible hit versus lower roll; the image rectangle misses the circular corner by ~0.074px. Glyph/texture alpha remains unverified. Shadow rectangles overlap, so no claim of pixel clearance is made.',
 geometry:{rightmostLaneCentre:336,availableGlyphMaxWidth:53.76,availableGlyphRight:362.88,hitRight:364,bodyLeft:372,lowerRollCentre:[484,-130.5],lowerRollCircularCorner:{centre:[369.5,-127.5],radius:8},cornerToGlyphClosestDistance:Math.hypot(369.5-362.88,-127.5-(-122.88)),lowerRollLightLeft:363},
 drawOrder:order,legendInteractiveControls:flat(legend).filter(c=>['cursorArea','presetButton'].includes(c.kind)).length,
 transform:'MapUI.position.x = (lane-4)*112 and y = firstY+(localFloor-1)*76-scroll. No seed-, row- or scroll-dependent horizontal translation/scale. Host viewport uniformly scales the entire stage.',
 viewports:[{width:1280,height:720,stageScale:1},{width:1920,height:1080,stageScale:1.5},{width:1600,height:900,stageScale:1.25},{width:2340,height:1080,stageScale:1.5}],
 viewportBoundary:'Scale values derived from actual Viewport.apply formula; not separate device runs.',
 upperDistribution:'24 real generated maps (12 seeds × 2 acts) retained below. Means describe source topology, not a symmetry requirement or the original unknown seed.',distributions,
 sourceFeedback:{time:'06:09–07:52',image01Sha256:'9b4a5e5e72a475fcdd0067f7a5a498fa8c790844e8f064ab2502949b56625bce',pngAvailable:false,seed:null},
 currentPrRange:{openCount:prList.length,prs672and684:'PC07-specific x projection, legend position and map topology are absent from their map diffs. Map setVisible retainPage lifecycle change only; see saved diff and PR snapshots.'},
 unchanged:['No product source changed','No topology or rule RNG changed','No Backlog, push, PR, tag or release mutation','No official import, ready, PC/phone test or native capacity claim'],
 nextEvidence:['Original/current comparable screenshot01 pixels and matching candidate identity','Map runSeed/mapSeed, act, current node, scroll and canvas size for that symptom','Actual current candidate official import / new ready / same-device visual and click evidence']};
report.originalSourceInputs={};
for(const [name,p] of Object.entries({verbatim:root+'/.worktrees/release-pc-closeout-1115/docs/qa/playtests/pc-20261115-verbatim.txt',imageManifest:root+'/.worktrees/release-pc-closeout-1115/docs/qa/playtests/pc-20261115-image-manifest.json',continuation:root+'/.worktrees/release-pc-item-title-shadow-1116/docs/backlog-details/PC-QA-20261115-CONTINUATION.md'}))report.originalSourceInputs[name]={path:p,sha256:sha(p)};
for(const name of ['pc07-interpretation.mjs','pc07-topology.lua','pc07-topology.stdout.tsv','pc07-topology.stderr.log','pc07-open-prs.json','pc07-pr672.json','pc07-pr684.json','pc07-release684-map.diff'])report.artifacts[name]=sha(out+'/'+name);
report.generatedOutputs=Object.fromEntries(['game-ui.json','abyss_ui_layout.lua','abyss_theme.lua','abyss_map_layout.lua','abyss_data.lua'].map(n=>[n,sha(build+'/'+n)]));
fs.writeFileSync(out+'/pc07-source-intake.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report.interpretation,distributions:distributions.slice(0,2)},null,2));
