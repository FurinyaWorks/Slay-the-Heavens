# PC07 有界源码诊断（未修复产品 / 未验收）

2026-11-16；canonical TASK-4.13。独立树 `F:/New folder/.worktrees/release-pc-map-bounds-1116`，分支 `feat/release-pc-map-bounds-1116`，HEAD 与诊断基线均为 `36b9b157ee6f05b65eb9f1da7e2978647d36c210`。工作树干净，未提交产品改动、未推送、未建 PR、未改 Backlog 或 Release 分支。

结论：本轮没有足以支持最小产品修复的缺陷证据。正式图例容器与节点的矩形会重叠，但不能据此判定可见路线遮挡或点击失败。PC07 原画面中“上段全部歪向一边”的现象仍未复现，TASK-4.13 的设备与整体体验 AC 保持未验收。

## 原反馈与在途范围

- 原逐字稿 `pc-20261115-verbatim.txt` 的 06:09–07:52：用户认为地图向一侧偏移，要求改善专业感。
- 图01 manifest：`01-map-legend-offset.png`，SHA256 `9b4a5e5e72a475fcdd0067f7a5a498fa8c790844e8f064ab2502949b56625bce`，310622 bytes。私人 PNG 未取得，seed、act、当前节点、scroll 与画布尺寸未知；未猜 seed，未把“应当对称”当规则。
- 当前 38 项台账来自 `release-pc-item-title-shadow-1116` 的 continuation，PC07 保持“待复现/修”。逐字稿、manifest、台账文件 SHA 见 JSON `originalSourceInputs`。
- 实际只读取得 28 个开放 PR（仓库实际名 `FurinyaWorks/Slay-the-Heavens`）。#672 `1f7ce04c` 与 #684 `00ff9b27` 的地图差异未改变 x 投影、图例位置或拓扑；地图仅有 `setVisible(..., retainPage)` 生命周期接续。真实 PR 快照与 Release684 地图 diff 已保存。没有重复这些在途修复。

## 本轮新增证据

生成 `officialAssets:true, nativePageLifecycle:true` 的真实生产 UI schema、主题与数据，使用现有 Fengari/`game_ui_fixture.lua` 装配完整生产 GameUI，再执行真实 MapUI/Map。为几何测量，将 schema 的静态 position/scale/rotation 装入现有原生 API mock；运行中真实 setter 写入的位置与尺寸优先。没有官方客户端或设备输入。

使用现有 12 个 golden seed：`0, 1, -17, 42, 200, 313, 600, 65535, 20261023, 123456789, 673465884448, 2780424839485660359`。每个第一幕 Host 检查 23 个初始 scroll 采样（0 至 836，步长38），再沿真实 `Map.available` 的最右合法路径依次 `Map.choose`，检查 17 个当前层 focus 和 available hover；后段 focus 到达 scroll 上限862。共 **684 个状态**，记录 **17311 个节点子控件**、**24039 条可见边线父控件**。合法前沿隔离直接推进 Map，不代表打完游戏房间。

| 测量对象 | 结果 / 证据边界 |
|---|---|
| 边线与图例全部 image 几何 | 0 交叠；以完整边线父矩形作保守包络，实际虚线更小 |
| 节点与图例 image 的矩形交叠 | 357 条去重记录；336 仅落在半透明阴影贴图的保守矩形 |
| 其余21条 | 7/12 seed 的 floor2、scroll0、`f3_l7`，图标/透明 hit 与 bottomRoll 的矩形接触；这是样本比例，不是所有 seed 的发生率 |
| 圆角100002的实际圆形几何 | 7条“图标碰到圆角”是外接正方形假阳性。该角圆心 `[369.5,-127.5]`、半径8，图标矩形最近距离 `8.0727194922`；仍不作平台抗锯齿像素结论 |
| 剩余实体几何接触 | 14条均为**透明56px hit**与下卷轴圆角/rollLight；没有测到实体图例 image 与可绘制节点矩形的交叠 |
| 图例主体 / 图例文字与图标 | paper 主体左372；路线最右列中心336，available图标最右362.88、hit最右364；图例内容更靠右。纸主体及内容没有本轮测得交叠 |
| 图层 / 点击 | 生成控制序列 legend=15、edge1=16、node1=142；图例先画，路线与节点后画。图例递归0个 cursorArea/presetButton，因此不能声称图例拦截节点输入 |

阴影贴图真实 alpha 尚未采样，本轮保留其可能接触，不宣称像素全无交叠。下卷轴图标仅约0.073px的圆角几何间隙也不足以凭离线几何评价真实观感。没有把轻微阴影/透明热区接触升级为P1阻塞。

## “上段偏斜”的源码边界

实际投影是 `x=(lane-4)*112`，`y=firstY+(localFloor-1)*76-scroll`。x 不依赖楼层、scroll 或 seed 的额外变换；Host 的 `Viewport.apply` 对整个 stage 统一缩放。1280×720、1920×1080、1600×900、2340×1080的比例分别为1、1.5、1.25、1.5——这是公式推导，未冒充四设备实测。

另外生成了 **12 seed × 第一、二幕 = 24 张真实地图**，保存每层 lane 与上下段质心。不同种子/幕的上段确会向不同侧集中：例如 seed0 第一幕下段平均x=41.26，上段=-143.11。该数值只描述真实拓扑分布，不说明原未知种子是哪一个，也不建立“应当左右对称”的规则。完整24图数据见 `pc07-topology.stdout.tsv` 与 JSON `interpretation.distributions`。

因此没有移动、拉伸或按可见节点重排路线；没有改变拓扑、规则 RNG、点选路径、滚动机制、私图或平衡。没有引入 future map 功能。

## 复现与交接

在该独立树执行：

```powershell
& 'F:/New folder/build/tools/node-v24.18.0-win-x64/node.exe' 'F:/New folder/.artifacts/release-pc-qa-20261115/pc07-audit.mjs'
& 'F:/New folder/build/tools/node-v24.18.0-win-x64/node.exe' 'F:/New folder/.artifacts/release-pc-qa-20261115/pc07-interpretation.mjs'
```

依赖仅复用 `release-pc-closeout-1115/node_modules` 的现成物理副本，未安装。TEMP/TMP 与生成 schema 均落在根 `.artifacts/release-pc-qa-20261115/`。JSON保留生产输入、生成输出、原始 stdout/stderr、脚本与 PR 证据 SHA256。原始 Host TSV 3737172 bytes；stderr 为空仅证明此次离线执行没有 stderr，不能代替新候选客户端日志。

下一步需要取得与症状对应的 PNG / 当前候选身份、runSeed/mapSeed、act/currentNode/scroll/canvas，才可同条件复现“向一侧偏移”的具体问题。随后应在本轮授权窗口对新候选做官方导入、新ready与真实PC/受影响手机的视觉和点击检查。本轮没有这些证据，也没有启动客户端或MCP；不作已修复、已通过设备验收或可发布结论。
