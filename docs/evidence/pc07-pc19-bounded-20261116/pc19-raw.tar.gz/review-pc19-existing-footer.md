# PC19 既有 Continue footer 诊断独立核对

**PASS_SCOPED_EVIDENCE**：已有 PC26 按钮切片覆盖本次固定 `golden_wing` option3 leave 后的 held `resultFooter`「继续」路径。不证明整条 PC19、`golden_idol` 的终末事件选项或私图05已修复。本轮未重跑探针，没有产品/Backlog/GUI修改。

- base：`36b9b157ee6f05b65eb9f1da7e2978647d36c210`，实际树 `.worktrees/release-pc-map-bounds-1116`。
- 比较：`bcca699509a159f21555d870f96fdfeca7191856`，实际树 `.worktrees/release-pc-picker-controls-1116`。
- 输入：root `pc19-event-continue.lua`、`run-pc19-event-continue.mjs`；`pc19/{picker-bcca-native,release36-native-external-cli}.{json,stdout.log,stderr.log}`。最终两 receipt 均 exit0/error空；probe SHA `7732c34ec915c95ffced2b82944a89c6eab46f4b807d93f00c25150a521425fd` 独立重算吻合。
- #676 传入的 manifest05 在 `8a44cd2f` 文本同时写 filename `05-golden-idol-event.png` 与 description「金翼雕像事件大面积黑底和继续按钮」。这是身份歧义的事实，不从索引猜定原图 sourceId；未看 PNG。实际枚举两个 sourceId 的做法合理。

独立读取结果：两树 `golden_idol` 均 option2→option1，两步后 phase=map、没有 held footer；不能把 node root confirm 皮肤等同其 event option1 的统一。`golden_wing` option3 leave 一步后 phase=map、result held、confirmLabel=继续。Release `shared=false`；bcca `shared=true`。这是一条具体的已有装饰复用覆盖，未创建新的产品 fix。

关键生产逻辑吻合：`abyss_node_ui::chooseFooter/resultFooter` 在 result 存在时给出「继续」，确认只清理 UI result/notice并刷新；Run/map 已在离开命令后进入地图。`official-picker-controls::applyOfficialPickerControls` 将共享 flag 装饰绑定到原 node confirm，保留 hit/label；`abyss_node_ui_feedback::sharedButtonChrome` 驱动其状态。没有为本诊断改事件业务或来源。

最终 probe 的事件选择和 Continue 使用公开 `ui:press`，状态用真实 hit 的 enter/down/up/exit；旧触点测试为 Down→`ui:render()`→Up/Click，之后保持同一 held result。源码 `abyss_node_ui_input` 记录 Down 的 action、Up 的 released gesture，Click 对比当前 action身份，故新 render 后旧释放不能触发新 action；不是直接调用私有 handler。Continue 使用公开 press 成功后，额外旧 click 仍不能改变 Run/map。

正常/hover/pressed 的真实共享面可见性断言以及每阶段完整递归 Run/map 快照相等均在脚本内。disabled 仅作为“其他面应隐藏”检查，未覆盖独立禁用态交互。最终 Continue 前后完整 Run/map（包含其 RNG）保持，不应扩称事件选择本身不改变规则状态。

独立物理核验：两次 sourceBefore/sourceAfter 数组各633/632条完全一致，且当前文件逐SHA复核一致；各25个生成文件 before/after相同且保留目录实际字节逐SHA一致；两 stdout/stderr、probe、CLI SHA均吻合。生成文件通过 package.preload 装入本次生成模块，生产模块从各自 cwd 的 src加载。两 receipt package-lock SHA同为 `a9e29383804620101b775e5c4f03a9f0d4c69df3e02ff60ebab90090bbd0fd77`；baseline显式复用bcca的同锁 Fengari CLI（SHA `dd3642afeffa41e547bb4ea970feacff98e53ef4a81f8c7659eeaa6f1579e972`），不从bcca装入 baseline生产代码。Node记录v24.18.0。

最初假定两个事件都必有 held footer，和第二版直接调用旧 `actions.confirm.handler` 期望其失效，均为无效探针假设。`.initial.lua` / `.trace-v2.lua` 保留，不能计作产品 RED；最终使用公开输入归属路径的结果才支持上述结论。

未验：原图05实际候选与事件身份/像素、大黑底/版式、其他事件/选项/奖励结果、disabled交互、异步原生调度、官方ready/候选、PC/手机与官方容量。Host为固定seed/人为节点初始化与 native control mock，不是用户自然遭遇或设备实测。PC19和相关任务维持未完成，原图身份及其他结果继续留在台账。
