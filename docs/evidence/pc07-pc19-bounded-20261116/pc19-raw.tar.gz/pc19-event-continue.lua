local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Run,Map,C=require('abyss_run'),require('abyss_map'),require('abyss_combat')
local events={CursorEnter='enter',CursorExit='exit',CursorDown='down',CursorUp='up',CursorEndDrag='endDrag'}
local function same(a,b)
 assert(type(a)==type(b));if type(a)~='table'then assert(a==b);return end
 for k,v in pairs(a)do same(v,b[k])end;for k in pairs(b)do assert(a[k]~=nil)end
end
for _,eventId in ipairs({'golden_idol','golden_wing'})do
 local host,root=F.fixture(nil,nil,nil,events);assert(F.start(host))
 local run,map=Run.new(F.Data,42),Map.generate(F.Data,42)
 local first=Map.available(map)[1]
 for _,n in ipairs(map.nodes)do if n.id==first.id then n.type='event';n.eventId=eventId end end
 assert(F.Nodes.enter(run,map,first.id))
 host.run,host.map=run,map;host.battleUI.run=run;host.mapUI.map=map
 host.nodeUI.run,host.nodeUI.map=run,map;host:refresh()
 local panel,ui=root:GetChild('nodePanel'),host.nodeUI
 local function get(path)local n=panel;for name in path:gmatch('[^/]+')do n=assert(n:GetChild(name),path)end;return n end
 local steps=0
 while not ui.result and run.phase=='node' and steps<6 do
  local chosen
  for i=4,1,-1 do local key='eventView/option'..i;local action=ui.actions[key]
   if action and action.enabled then chosen=key;break end
  end
  assert(chosen,'no visible enabled event action '..eventId)
  assert(ui:press(chosen));host:refresh();steps=steps+1
  print('PC19_STEP '..eventId..' key='..chosen..' phase='..run.phase..' stage='..tostring(run.nodeFlow.event.stage)..' hold='..tostring(ui.result~=nil)..' confirm='..get('confirm/label').text..' confirmVisible='..tostring(get('confirm').visible))
 end
 if ui.result then
 assert(ui:holding(),eventId..' result is not holding')
 local button=get('confirm');assert(button.visible and get('confirm/label').text=='继续')
 local chrome,before=button:GetChild('sharedButtonChrome'),nil
 before={run=C.copy(run),map=C.copy(map)}
 local function painted(state)
  if chrome then for _,name in ipairs({'normal','hover','pressed','disabled'})do assert(chrome:GetChild(name).visible==(name==state),eventId..' '..state..' '..name)end end
  same(run,before.run);same(map,before.map)
 end
 painted('normal')
 local hit=button:GetChild('hit');hit.listeners.enter({touchId=21});painted('hover')
 hit.listeners.down({touchId=21});painted('pressed');hit.listeners.up({touchId=21});hit.listeners.exit({touchId=21});painted('normal')
 local hold=ui.result
 hit.listeners.down({touchId=22});ui:render()
 hit.listeners.up({touchId=22});hit.click({touchId=22})
 assert(ui.result==hold,'stale native release consumed a newly rendered result')
 before={run=C.copy(run),map=C.copy(map)}
 assert(ui:press('confirm'));same(run,before.run);same(map,before.map)
 assert(not ui.result and run.phase=='map')
 hit.click({touchId=22});same(run,before.run);same(map,before.map)
 print('PC19_EVENT '..eventId..' steps='..steps..' shared='..tostring(chrome~=nil)..' phase='..run.phase..' run_map_unchanged=true')
 else
  print('PC19_NO_HELD_FOOTER '..eventId..' phase='..run.phase..' steps='..steps..'; existing shared root confirm does not prove terminal event-option styling')
 end
 host:disable()
end
print('PC19_DIAG_COMPLETE controlled actual event commands; footer hypothesis can be falsified; not screenshot or device evidence')
