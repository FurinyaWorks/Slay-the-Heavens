import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {integrationCapacityCiRead} from '../../tests/helpers/release-picker-b9-integration.mjs';
const path='tests/release-selection-map-source.test.mjs';let changed=null,calls=0;
const raw=(p,e)=>{calls++;if(p===changed)throw Error('missing '+p);return readFileSync(p,e);};
const view=integrationCapacityCiRead(raw);const text=view(path,'utf8');assert.equal(typeof text,'string');assert.notEqual(text,readFileSync(path,'utf8'));
assert.equal(view(path).toString('utf8'),text);
changed='scripts/native-ui-card-sharing.mjs';assert.throws(()=>view(path),/missing scripts\/native-ui-card-sharing.mjs/);changed=null;assert.equal(view(path,'utf8'),text);
for(const value of ['foreign\n',Buffer.from('foreign\n'),null,17]){let count=0;const foreign=integrationCapacityCiRead(()=>{count++;return value;});assert.strictEqual(foreign(path),value);assert.equal(count,1);}
console.log('PASS string/Buffer same-current, warm capacity owner missing+recovery, foreign/no-op exact identity and one input read');
