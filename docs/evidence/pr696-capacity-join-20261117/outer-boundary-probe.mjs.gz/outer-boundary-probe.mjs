import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {integrationRead} from '../../tests/helpers/release-picker-b9-integration.mjs';
import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
const request='tests/helpers/integrated-ci-source.mjs';
let target=null,mode=null;const raw=(p,e)=>{if(p===target&&mode==='missing')throw Error('missing '+p);const v=readFileSync(p,e);return p===target&&mode==='drift'?typeof v==='string'?v+'\n':Buffer.concat([v,Buffer.from('\n')]):v;};
const publicRead=integrationRead('picker',raw),t=performance.now();let checks=0;
assertIntegratedCurrent(raw);checks++;const expected=publicRead(request);assert(Buffer.isBuffer(expected));checks++;
for(const path of ['scripts/native-ui-card-sharing.mjs','tests/helpers/release-capacity-b9-reader-repair.json.gz','tests/ci-complete-calibration.test.mjs','tests/release-selection-map-source.test.mjs','src/lua/abyss_card_flow.lua','tests/helpers/release-picker-b9-integration.json','tests/helpers/release-picker-capacity-join.json']){
 for(const kind of ['missing','drift']){
  target=path;mode=kind;
  const precise=e=>{assert(e.message.includes(path)||path.endsWith('release-picker-capacity-join.json')&&/picker capacity join packet/.test(e.message));return true;};
  assert.throws(()=>assertIntegratedCurrent(raw),precise);checks++;
  assert.throws(()=>publicRead(request),precise);checks++;
 }
 target=null;mode=null;assert.deepEqual(publicRead(request),expected);checks++;
 console.log(JSON.stringify({path,status:'missing/drift rejected through public+fixed; Buffer restored'}));
}
assertIntegratedCurrent(raw);checks++;
console.log(JSON.stringify({status:'PASS',checks,ms:performance.now()-t}));
