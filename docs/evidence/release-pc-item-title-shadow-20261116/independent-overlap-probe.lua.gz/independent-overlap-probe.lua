-- Independent synthetic native-handle lookup-loss probe. Exact production
-- reward/Art modules, stubbed Theme/identity providers, no Host/device claim.
local dir=assert(os.getenv('PC689_PROBE_DIR'))
local variant=assert(os.getenv('PC689_PROBE_VARIANT'))
local mode=assert(os.getenv('PC689_PROBE_MODE'))
local function control(parent)
 local c={alive=true,parent=parent,visible=true,children={}}
 function c:GetChild(name)return self.children[name]end
 function c:GetChildren()return {}end
 function c:SetVisible(v)self.visible=v end
 function c:SetImage(_,id)self.imageId=id end
 function c:SetLocalScale()end
 function c:SetAnchoredPosition()end
 function c:SetSizeDelta()end
 function c:SetLocalRotation()end
 return c
end
local shape={image=100001,x=0,y=0,w=10,h=10,colour={r=255,g=255,b=255,a=255}}
local theme={presentationProfile='official-assets-first',officialAssets={rewardRows={normal={},iconSize=28,ink={}}},
 color={textMuted={}},icon={node={treasure=10}},lowCostArt={relic={capacity=16,assets={blue_candle={shapes={shape}}}}}}
package.loaded.abyss_theme=theme
package.loaded.abyss_relic_view_ui={icon=function()return 123 end}
package.loaded.abyss_relic_hooks={localId=function(id)return id end}
package.loaded.abyss_lowcost_art=dofile(dir..'/art.lua')
local Reward=dofile(dir..'/'..variant..'-reward.lua')
local row=control();local face=control(row)
local owner=variant=='pr689'and row or face
local icon=control(owner);icon.name='rewardIcon';owner.children.rewardIcon=icon
local pool=control(owner);owner.children.rewardIconArt=pool
for i=0,15 do pool.children['shape'..i]=control(pool)end
face.children.stsRewardFace=control(face);face.children.label=control(face)
local run={rewards={relics={{id='blue_candle'}}}}
local platform={imageSource='static',color=function(r,g,b,a)return {r=r,g=g,b=b,a=a}end}
local function paint()assert(Reward.paintButton('relicReward1',face,'normal',run,platform,function()end,function()end))end
paint();assert(pool.visible and not icon.visible,'successful initial art is required')
if mode=='missing'then owner.children.rewardIconArt=nil
elseif mode=='throw'then
 local get=owner.GetChild;owner.GetChild=function(self,key)if key=='rewardIconArt'then error('lookup unavailable')end;return get(self,key)end
else error('unknown mode')end
paint()
print('OBSERVATION variant='..variant..' mode='..mode..' fallback='..tostring(icon.visible)..' oldPool='..tostring(pool.visible)..' oldPoolStillOwned='..tostring(pool.parent==owner))
assert(icon.visible,'fallback restored')
assert(not pool.visible,'live old glyph remains visible over fallback after lookup loss')
print('LOOKUP_LOSS_RETIREMENT_PASS')
