import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {assertReleaseIntegrationCurrent} from '../../../tests/helpers/release-picker-b9-integration.mjs';
let count=0,bytes=0;const read=(p,e)=>{const v=readFileSync(p,e);count++;bytes+=Buffer.byteLength(v);return v;};
const start=performance.now();assertReleaseIntegrationCurrent(read);console.log(JSON.stringify({phase:'healthy',count,bytes,ms:performance.now()-start}));
const packet=JSON.parse(readFileSync('tests/helpers/release-picker-b9-integration.json','utf8'));
const archive=Object.keys(packet.archives).find(p=>p.endsWith('.gz'));
let checks=0;
for(const mode of ['missing','tail','null']){
 assert.throws(()=>assertReleaseIntegrationCurrent((p,e)=>{const v=readFileSync(p,e);if(p!==archive)return v;if(mode==='missing')throw Error('missing '+p);if(mode==='null')return null;return Buffer.concat([Buffer.isBuffer(v)?v:Buffer.from(v),Buffer.from('\n')]);}));checks++;
}
assertReleaseIntegrationCurrent();checks++;
console.log(JSON.stringify({phase:'archive-negative-and-recovery',archive,checks}));
