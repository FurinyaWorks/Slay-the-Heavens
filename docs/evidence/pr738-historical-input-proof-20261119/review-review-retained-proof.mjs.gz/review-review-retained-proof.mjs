import assert from 'node:assert/strict';
import {readFileSync,readdirSync,lstatSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
const cwd=process.cwd(), out=process.argv[2];
assert(out,'directory for frozen proof artifacts');
const path=p=>join(out,p);
const git=(...a)=>execFileSync('git',a);
const norm=s=>s.replaceAll('\r\n','\n');
const sha=(s)=>createHash('sha256').update(s).digest('hex');
const blob=b=>createHash('sha1').update(`blob ${b.length}\0`).update(b).digest('hex');
const log=readFileSync(path('paired-final.log'),'utf8');
const proof=readFileSync(path('proof.mjs'),'utf8');
const manifest=JSON.parse(readFileSync(path('source-manifest.json'),'utf8'));
assert.equal(manifest.head,'c3d7cf072b1942291a4ab7a14cc7231274a545bc');
assert.equal(manifest.tree,'e57acd44f70a608975d207908236729a8d5b4446');
assert.equal(manifest.generatedShadowing,0);
assert.match(proof,/spawnSync\(process\.execPath,\[cli,'-e',/);
assert.match(proof,/timeout:30000,maxBuffer:1024\*1024/);
assert.match(proof,/LUA_PATH:'\.\/build\/lua\/\?\.lua;\.\/src\/lua\/\?\.lua;;',LUA_PATH_5_3:'\.\/build\/lua\/\?\.lua;\.\/src\/lua\/\?\.lua;;',LUA_INIT:'',LUA_INIT_5_3:''/);
for(const [name,m] of Object.entries(manifest.inputs)){
 const b=readFileSync(name);
 assert.equal(b.length,m.size,name);
 assert.equal(sha(b),m.sha256,name);
 assert.equal(blob(b),m.blob,name);
 assert.equal(git('rev-parse',manifest.head+':'+name).toString().trim(),m.blob,name);
}
const src=git('ls-tree','-z','-r',manifest.head,'src/lua').toString().split('\0').filter(Boolean).map(row=>{
 const m=row.match(/^\d+ blob ([0-9a-f]{40})\t(.+)$/);assert(m,row);return m.slice(1);
});
assert.equal(src.length,manifest.productionInputCount);
for(const [expected,name] of src){assert(lstatSync(name).isFile());assert.equal(blob(readFileSync(name)),expected,name);}
const list=d=>readdirSync(d,{withFileTypes:true}).filter(e=>e.name.endsWith('.lua')).map(e=>{assert(e.isFile());return e.name}).sort();
assert.deepEqual(list('src/lua'),src.map(([,p])=>p.split('/').at(-1)).sort());
const prod=new Set(list('src/lua')),generated=list('build/lua');
assert.deepEqual(Object.keys(manifest.generatedLua).sort(),generated.map(n=>'build/lua/'+n));
assert(generated.every(n=>!prod.has(n)));
for(const n of generated){
 const file='build/lua/'+n,b=readFileSync(file),m=manifest.generatedLua[file];
 assert.equal(b.length,m.size,file);assert.equal(sha(b),m.sha256,file);
}
const load=p=>import(pathToFileURL(resolve(cwd,p)));
const [hist,hand,event,texture,old,projection,build]=await Promise.all([
 'tests/helpers/historical-card-input.mjs','tests/helpers/battle-life-frozen-hand.mjs',
 'tests/helpers/event-combat-route-input.mjs','tests/helpers/v25-texture-binding-fixture.mjs',
 'tests/helpers/historical-baseline-inputs.mjs','tests/helpers/pr372-integration-source.mjs',
 'scripts/build-lua-data.mjs',
].map(load));
const expected=JSON.parse(readFileSync(new URL('./review-source-probe.log',import.meta.url),'utf8'));
const lines=log.split(/\r?\n/);
const execution=lines.filter(l=>l.startsWith('{"script":')).map(JSON.parse);
const observedNames=lines.map(l=>l.match(/^PASS source card input (.+)$/)?.[1]).filter(Boolean);
const observedPrefixes=lines.filter(l=>l.startsWith('{"prefixes":')).map(l=>JSON.parse(l).prefixes);
assert.deepEqual(observedNames,expected.names);
assert.equal(execution.length,3);assert.equal(observedPrefixes.length,3);
const archived=old.loadHistoricalBaselineInputs();
const readSource=p=>{assert(Object.hasOwn(archived,p),p);return archived[p].toString('utf8')};
const bpath='src/lua/abyss_battle_card_bindings.lua';
const bbase=projection.preIntegrationSource(bpath,norm(readSource(bpath)),'base',{readSource});
assert.equal(sha(bbase),'0c370951117718e9f2c7247cc6ff4db7836e019d6c59a097e3b9ea9e632cbf8b');
const inserted=`package.preload.abyss_battle_card_bindings=function()return assert(load(${build.luaString(bbase)},'@pre-browse-binding'))()end\n`;
for(const [i,script] of hist.historicalCardInputFixtures.entries()){
 assert.equal(execution[i].script,script);
 assert.deepEqual([execution[i].first,execution[i].last],[[1,6],[7,10],[11,12]][i]);
 assert(execution[i].elapsedMs>0&&execution[i].elapsedMs<30000);
 assert.equal(execution[i].status,0);assert.equal(execution[i].error,undefined);
 const four=[hist.historicalCardInputPrelude(script,{cwd}),hand.frozenBattleHandPrelude(script,{cwd}),
  event.eventCombatRoutePrelude(script,{cwd}),texture.v25TextureBindingPrelude(script,{cwd})];
 const signatures=['historicalCardInputPrelude','frozenBattleHandPrelude','eventCombatRoutePrelude','v25TextureBindingPrelude'];
 assert.deepEqual(observedPrefixes[i],four.map((p,j)=>[signatures[j],sha(p),Buffer.byteLength(p)]));
 assert.equal(readFileSync(path(`paired-${i+1}.lua`),'utf8'),
  four[0]+inserted+four.slice(1).join('')+`dofile(${build.luaString(resolve(cwd,script))})\n`);
}
assert.match(log,/PAIRED ORIGINAL 12\/12/);
const originalRed=readFileSync(path('formal-unpaired-red.log'),'utf8');
assert.match(originalRed,/attempt to index a nil value \(upvalue 'Intent'\)/);
const settleRed=readFileSync(path('exact-pair-without-settle.log'),'utf8');
assert.match(settleRed,/LUA_CARD_INPUT_PORT_PASS 5/);
assert.match(settleRed,/source input failures: 1/);
const identityOnlyProof=readFileSync(path('archive-binding-with-settle.log'),'utf8');
assert.deepEqual(identityOnlyProof.split(/\r?\n/).filter(l=>/^LUA_CARD_INPUT_PORT_PASS [642]$/.test(l)),
 ['LUA_CARD_INPUT_PORT_PASS 6','LUA_CARD_INPUT_PORT_PASS 4','LUA_CARD_INPUT_PORT_PASS 2']);
console.log(JSON.stringify({scope:'static verification of already produced Lua results; no tests executed',
 artifacts:Object.fromEntries(['proof.mjs','paired-final.log','source-manifest.json','formal-unpaired-red.log','exact-pair-without-settle.log','archive-binding-with-settle.log'].map(n=>[n,sha(readFileSync(path(n)))])),
 trackedProductionInputs:src.length,generatedInputs:generated.length,generatedShadowing:0,currentFixture:manifest.inputs['tests/lua/support/card_input_port_cases.lua'],
 budgets:execution,originalCasesMatched:observedNames.length,exactLaunchEntries:3,
 absenceOfBinding:'Intent=nil red',absenceOfFrozenHand:'same pair, 5/6 and red',
 archiveBindingNotProjected:'also passes; unauthorized source identity, not causal failure'},null,2));
