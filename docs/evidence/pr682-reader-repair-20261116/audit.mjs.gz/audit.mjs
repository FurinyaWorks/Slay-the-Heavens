import assert from'node:assert/strict';import{readFileSync,writeFileSync,readdirSync}from'node:fs';import{execFileSync}from'node:child_process';import{createHash}from'node:crypto';
import{dependencyCiRepairPacket as p,assertDependencyCiRepairCurrent}from'../../tests/helpers/dependency-ci-repair-source.mjs';
import{dependencyCiProof}from'../../tests/helpers/dependency-ci-source.mjs';
import{sourceEpoch}from'../../tests/helpers/closeout-source-epoch.mjs';
const base='1b60f71c4733ced0c91dc814dc5c7a6644c8fe56',checkpoint='ce075f014702b70a2a20456e7dc6ef0f5659be59',hash=b=>createHash('sha256').update(b).digest('hex'),norm=b=>b.toString('utf8').replaceAll('\r\n','\n');
const git=(...args)=>execFileSync('git',args,{maxBuffer:32*1024*1024}),blob=s=>createHash('sha1').update(`blob ${Buffer.byteLength(s)}\0`).update(s).digest('hex');
const changed=git('diff','--name-only',base,checkpoint).toString().trim().split('\n').sort(),trust=['tests/helpers/dependency-ci-repair-source.mjs','tests/helpers/dependency-ci-repair-source.json.gz'];
assert.deepEqual(changed,[...Object.keys(p.files),...trust].sort(),'every executable change is captured or an explicit trust leaf/packet boundary');
for(const[path,row]of Object.entries(p.files)){
 assert.equal(norm(git('show',base+':'+path)),row.before.source,path+' genuine before');
 assert.equal(norm(git('show',checkpoint+':'+path)),row.current.source,path+' committed current');
 assert.equal(blob(row.current.source),row.current.gitBlob,path+' current blob');
}
let lfsArchives=0;
for(const[path,sha]of Object.entries(p.archives)){
 const old=git('show',base+':'+path),oid=old.toString().match(/^version https:\/\/git-lfs.github.com\/spec\/v1\r?\noid sha256:([a-f0-9]{64})\r?\nsize (\d+)/);
 if(oid){lfsArchives++;assert.equal(sha,oid[1]);assert.equal(readFileSync(path).length,Number(oid[2]));}
 else assert.equal(hash(old),sha,path+' unchanged old archive');
 assert.equal(hash(readFileSync(path)),sha,path+' physical retained archive');
}
assert.equal(git('diff','--name-only',base,checkpoint,'--','src/lua','config/architecture.json').length,0);
assertDependencyCiRepairCurrent();
const result={baseCommit:base,codeCheckpoint:checkpoint,captureCurrentTreeCommitted:p.currentTreeCommitted,allExecutablePathsBound:true,beforeCurrent:Object.keys(p.files),trustBoundaries:trust,archives:Object.keys(p.archives).length,lfsArchives,production:Object.keys(p.production).length,owners:sourceEpoch.proof.owners.length,addedOwners:[],oldDomain:{js:dependencyCiProof.inventoryBefore.length,lua:dependencyCiProof.luaInventoryBefore.length},parentDomain:{js:dependencyCiProof.inventoryAfter.length,lua:dependencyCiProof.luaInventoryAfter.length},currentDomain:{js:p.inventory.js.length,lua:p.inventory.lua.length},rawDelta:{js:0,lua:0},status:'PASS'};
writeFileSync('.artifacts/ci682-repair/audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
