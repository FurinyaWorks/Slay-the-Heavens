import{readFileSync,writeFileSync,readdirSync,mkdirSync}from'node:fs';import{gzipSync}from'node:zlib';import{createHash}from'node:crypto';
const dir='.artifacts/ci682-repair',out='docs/evidence/pr682-reader-repair-20261116',hash=b=>createHash('sha256').update(b).digest('hex'),manifest=[];mkdirSync(out,{recursive:true});
function save(name,raw,source){const bytes=gzipSync(raw);writeFileSync(out+'/'+name+'.gz',bytes);manifest.push({path:name+'.gz',source,bytes:bytes.length,sha256:hash(bytes),rawBytes:raw.length,rawSha256:hash(raw)});}
for(const file of readdirSync(dir).filter(n=>n.endsWith('.log')))save(file,readFileSync(dir+'/'+file),'local bounded verification stdout/stderr');
for(const id of[132986880772,132986880785]){const p=JSON.parse(readFileSync('F:/New folder/.artifacts/pr682-ci-triage-1116/job-'+id+'.json'));save('job-'+id+'.log',Buffer.from(p.content),'GitHub completed job log API; exact decoded content');}
for(const file of['capture.mjs','audit.mjs','archive.mjs'])save(file,readFileSync(dir+'/'+file),'bounded local collector/audit');
for(const file of['capture.json','audit.json'])writeFileSync(out+'/'+file,readFileSync(dir+'/'+file));
writeFileSync(out+'/archive-manifest.json',JSON.stringify(manifest,null,2)+'\n');console.log('ARCHIVED',manifest.length,manifest.reduce((sum,row)=>sum+row.bytes,0));
