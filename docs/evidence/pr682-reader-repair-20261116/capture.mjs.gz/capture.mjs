// Bounded exact successor, using the existing collector's Git/LF bindings.
import{readFileSync,writeFileSync,readdirSync}from'node:fs';import{execFileSync}from'node:child_process';import{createHash}from'node:crypto';import{gzipSync}from'node:zlib';
const base='1b60f71c4733ced0c91dc814dc5c7a6644c8fe56',hash=b=>createHash('sha256').update(b).digest('hex'),norm=s=>s.replaceAll('\r\n','\n');
const git=(...args)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:8*1024*1024}),bind=source=>({source,sha256:hash(source),gitBlob:createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex')});
const paths=['tests/dependency-bgm-source.test.mjs','tests/helpers/integrated-ci-source.mjs','tests/sts-style-source-epoch.test.mjs'];
const files=Object.fromEntries(paths.map(path=>[path,{before:bind(norm(git('show',base+':'+path))),current:bind(norm(readFileSync(path,'utf8')))}]));
const archives=Object.fromEntries(git('ls-tree','-r','--name-only',base,'tests/helpers').trim().split('\n').filter(p=>p.endsWith('.gz')).map(path=>[path,hash(readFileSync(path))]));
const production=Object.fromEntries(git('ls-tree','-r',base,'src/lua','config/architecture.json').trim().split('\n').map(line=>{const m=line.match(/^\d+ blob ([a-f0-9]+)\t(.+)$/);return[m[2],m[1]];}));
const inventory={js:readdirSync('tests').filter(p=>p.endsWith('.test.mjs')).map(p=>'tests/'+p).sort(),lua:readdirSync('tests/lua').filter(p=>p.endsWith('.lua')).map(p=>'tests/lua/'+p).sort()};
const packet={schemaVersion:1,normalization:'LF',baseCommit:base,fixtureCommit:'cfe8a040c1f7e937f1a38c14d6822f44fc6ac717',currentTreeCommitted:false,files,archives,production,inventory};
const bytes=gzipSync(JSON.stringify(packet));writeFileSync('tests/helpers/dependency-ci-repair-source.json.gz',bytes);
const helper='tests/helpers/dependency-ci-repair-source.mjs';writeFileSync(helper,readFileSync(helper,'utf8').replace(/REPAIR_PACKET_SHA|(?<=hash\(bytes\),')[a-f0-9]{64}(?=',)/,hash(bytes)));
const receipt={sha256:hash(bytes),bytes:bytes.length,paths,archives:Object.keys(archives).length,production:Object.keys(production).length,rawJs:inventory.js.length,rawLua:inventory.lua.length,addedOwners:[]};
writeFileSync('.artifacts/ci682-repair/capture.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
