from pathlib import Path
import subprocess,sys
root=Path('.artifacts/enemy-geometry-final')
for path,name in [('tests/helpers/enemy-geometry-ci-source.mjs','patched-leaf.mjs'),('tests/helpers/enemy-geometry-ci-source.json.gz','patched-ci.json.gz')]:
 target=Path(path);saved=root/name
 if sys.argv[1]=='old':
  saved.write_bytes(target.read_bytes());target.write_bytes(subprocess.check_output(['git','show','d19b3d9cacc5397f0880a9435cc18c1f6095883e:'+path]))
 else:target.write_bytes(saved.read_bytes())
