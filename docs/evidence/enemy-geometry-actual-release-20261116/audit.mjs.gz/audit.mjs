import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {sourceEpoch,preEnemyGeometrySourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {enemyGeometryCiPacket,assertEnemyGeometryCiCurrent} from '../../tests/helpers/enemy-geometry-ci-source.mjs';
import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
const original='2c038f8dac2b707eecd0366437552f97a16f4e9d',merged='d19b3d9cacc5397f0880a9435cc18c1f6095883e',actual='1cc5479b713edab6fd26db4e20f8eb22b7401cb2',oldBase='b67226945c2be47c8fff31f1362412b973f68875';
const git=(...args)=>execFileSync('git',['-c','core.commitGraph=false',...args],{maxBuffer:32*1024*1024});
const oid=ref=>git('rev-parse',ref).toString().trim(),hash=b=>createHash('sha256').update(b).digest('hex');
assert.equal(oid(oldBase+'^{tree}'),oid(actual+'^{tree}'));
assert.equal(oid(merged+'^{tree}'),oid(original+'^{tree}'));
git('merge-base','--is-ancestor',original,merged);git('merge-base','--is-ancestor',actual,merged);
assert.equal(oid(merged+':src/lua'),oid('61bdf6c069f8e30e6aa3ff44d3ecddd25c159ee2:src/lua'));
const oldBytes=git('show',merged+':tests/helpers/enemy-geometry-ci-source.json.gz'),old=JSON.parse(gunzipSync(oldBytes));
for(const key of Object.keys(old))if(key!=='files')assert.deepEqual(enemyGeometryCiPacket[key],old[key],key+' immutable original packet field');
let changed=[],added=[];
for(const [path,row]of Object.entries(enemyGeometryCiPacket.files)){
 if(!Object.hasOwn(old.files,path)){
  assert(['tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs','tests/sts-style-source-epoch.test.mjs'].includes(path));
  assert.equal(row.before.source,git('show',oldBase+':'+path).toString().replaceAll('\r\n','\n'),path+' complete real newly registered predecessor');
  assert.equal(row.beforeCommit,oldBase);added.push(path);continue;
 }
 assert.deepEqual(row.before,old.files[path].before,path+' exact original predecessor');
 assert.equal(row.beforeCommit,old.files[path].beforeCommit,path+' exact original before commit');
 if(row.current.sha256!==old.files[path].current.sha256)changed.push(path);
}
assert.deepEqual(changed,['tests/helpers/integrated-ci-source.mjs','tests/integrated-ci-source.cases.mjs']);
assert.equal(added.length,3);
for(const path of ['src/lua/abyss_battle_enemy_view.lua','src/lua/abyss_battle_render_actors.lua','src/lua/abyss_battle_targeting.lua','tests/helpers/isolated-battle-regression.mjs','tests/enemy-geometry-metrics.test.mjs','tests/lua/enemy_geometry_metrics.lua','tests/helpers/enemy-geometry-source.mjs','tests/helpers/enemy-geometry-source.json.gz','tests/helpers/closeout-source-epoch.mjs','tests/helpers/copy-integration-source-closure.mjs']){
 const bytes=readFileSync(path),originalBytes=git('show',original+':'+path);
 assert.equal(hash(path.endsWith('.gz')?bytes:Buffer.from(bytes.toString().replaceAll('\r\n','\n'))),hash(originalBytes),path+' unchanged original product/helper');
}
const proof=sourceEpoch.proof;let productionBindings=0;
for(const [path,row]of Object.entries(proof.current))if(row!==null){
 assert.equal(readFileSync(path,'utf8').replaceAll('\r\n','\n'),row.source,path+' actual current production');productionBindings++;
}
const integrated=readFileSync('tests/helpers/integrated-ci-source.mjs','utf8'),start=integrated.indexOf('export function assertIntegratedCurrent('),end=integrated.indexOf('export function extendIntegratedHelperClosure('),scope=integrated.slice(start,end);
assert(scope.includes('assertEnemyGeometryCiCurrent(read)'));
assert(scope.includes('enemyGeometryCiCheckedSource(path,read(path,\'utf8\'))'));
assert(scope.indexOf('assertEnemyGeometryCiCurrent(read)')<scope.indexOf('enemyGeometryCiCheckedSource(path,read(path,\'utf8\'))'),'explicit internal comparator has complete fresh same-reader precondition');
assertEnemyGeometryCiCurrent();assertIntegratedCurrent();
const result={status:'pass',original,actualRelease:actual,merged,oldBootstrapTree:oid(oldBase+'^{tree}'),actualBootstrapTree:oid(actual+'^{tree}'),mergeTree:oid(merged+'^{tree}'),originalTree:oid(original+'^{tree}'),unchangedProductionTree:oid(merged+':src/lua'),originalActiveCiSha256:hash(oldBytes),changedActiveCiBindings:changed,addedActiveCiBindings:added,productionBindings,ownersBefore:preEnemyGeometrySourceEpoch.proof.owners.length,ownersCurrent:proof.owners.length,newOwners:proof.owners.filter(path=>!preEnemyGeometrySourceEpoch.proof.owners.includes(path)),bindings:Object.keys(enemyGeometryCiPacket.files).length,archives:Object.keys(enemyGeometryCiPacket.immutableArchives).length,checkedSourceCallers:['tests/helpers/integrated-ci-source.mjs:assertIntegratedCurrent; complete same-reader assertion precedes private comparison'],rawBefore:Object.fromEntries(Object.entries(enemyGeometryCiPacket.priorInventory).map(([k,v])=>[k,v.length])),rawCurrent:Object.fromEntries(Object.entries(enemyGeometryCiPacket.currentInventory).map(([k,v])=>[k,v.length]))};
writeFileSync('.artifacts/enemy-geometry-final/audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
