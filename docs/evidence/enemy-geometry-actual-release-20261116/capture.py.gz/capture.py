from pathlib import Path
import gzip,hashlib,json,re,subprocess
base='d19b3d9cacc5397f0880a9435cc18c1f6095883e'
git=lambda *args:subprocess.check_output(['git','-c','core.commitGraph=false',*args])
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def record(raw):
 s=raw.decode().replace('\r\n','\n');b=s.encode()
 return dict(source=s,sha256=sha(b),gitBlob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
name='tests/helpers/enemy-geometry-ci-source.json.gz'
oldbytes=git('show',base+':'+name);packet=json.loads(gzip.decompress(oldbytes))
changed=[]
for path,row in packet['files'].items():
 current=record(Path(path).read_bytes())
 if current!=row['current']:changed.append(path);row['current']=current
assert set(changed)<= {'tests/helpers/integrated-ci-source.mjs','tests/integrated-ci-source.cases.mjs'} and 'tests/integrated-ci-source.cases.mjs' in changed,changed
added=['tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs','tests/sts-style-source-epoch.test.mjs']
for path in added:
 packet['files'][path]=dict(beforeCommit=packet['baseCommit'],before=record(git('show',packet['baseCommit']+':'+path)),current=record(Path(path).read_bytes()))
common=Path(git('rev-parse','--git-common-dir').decode().strip()).resolve();restored=[]
for path,expected in packet['immutableArchives'].items():
 raw=Path(path).read_bytes()
 if raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1])
  raw=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes();assert sha(raw)==oid and len(raw)==size
  Path(path).write_bytes(raw);restored.append(dict(path=path,oid=oid,size=size))
 assert sha(raw)==expected,path
newbytes=gzip.compress((json.dumps(packet,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0)
Path(name).write_bytes(newbytes)
leaf=Path('tests/helpers/enemy-geometry-ci-source.mjs');text=leaf.read_text();oldhash=sha(oldbytes)
if oldhash not in text:
 prior=json.loads(Path('.artifacts/enemy-geometry-final/capture.json').read_text())['currentPacketSha256'];assert text.count(prior)==1;text=text.replace(prior,oldhash)
assert text.count(oldhash)==1;leaf.write_text(text.replace(oldhash,sha(newbytes)),encoding='utf8',newline='\n')
result=dict(originalPacketCommit=base,originalPacketSha256=oldhash,currentPacketSha256=sha(newbytes),currentPacketBytes=len(newbytes),changedBindings=changed,addedBindings=added,bindings=len(packet['files']),archives=len(packet['immutableArchives']),runtimeUnchanged=True,priorInventory={k:len(v)for k,v in packet['priorInventory'].items()},currentInventory={k:len(v)for k,v in packet['currentInventory'].items()},restoredInputs=restored)
Path('.artifacts/enemy-geometry-final/capture.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
