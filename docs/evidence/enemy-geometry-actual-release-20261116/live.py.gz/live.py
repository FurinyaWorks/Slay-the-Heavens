from pathlib import Path
def edit(path,before,after):
 p=Path(path);s=p.read_text();assert s.count(before)==1,(path,before);p.write_text(s.replace(before,after),encoding='utf8',newline='\n')
for path in ['tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs']:
 edit(path,"stsStyleEpoch,menuRedEpoch} from './helpers/closeout-source-epoch.mjs';","stsStyleEpoch,menuRedEpoch,preEnemyGeometrySourceEpoch} from './helpers/closeout-source-epoch.mjs';")
 s=Path(path).read_text()
 if 'defect-' in path:
  before=" assert.deepEqual(current.owners,[...menuRedEpoch.proof.owners,...additions].sort());assert.equal(current.owners.length,116);"
 else:
  before=" assert.deepEqual(current.owners,[...menuRedEpoch.proof.owners,...additions].sort());\n assert.equal(current.owners.length,116);"
 after=" assert.deepEqual(preEnemyGeometrySourceEpoch.proof.owners,[...menuRedEpoch.proof.owners,...additions].sort());\n assert.equal(preEnemyGeometrySourceEpoch.proof.owners.length,116,'complete bootstrap predecessor remains a separate historical domain');\n assert.deepEqual(current.owners,[...preEnemyGeometrySourceEpoch.proof.owners,'src/lua/abyss_battle_targeting.lua'].sort());\n assert.equal(current.owners.length,117);\n assert.deepEqual(current.targets.enemyGeometryPrior.files,preEnemyGeometrySourceEpoch.proof.current);"
 edit(path,before,after)
 s=Path(path).read_text().replace('authenticates all 116 disk owners','authenticates all 117 disk owners')
 Path(path).write_text(s,encoding='utf8',newline='\n')
path='tests/sts-style-source-epoch.test.mjs'
edit(path,"import {discoverJs,jsPlanningWeights,timings} from '../scripts/ci-shards.mjs';","import {discoverJs,jsPlanningWeights,timings} from '../scripts/ci-shards.mjs';\nimport {enemyGeometryPriorInventory,assertEnemyGeometryRawInventory} from './helpers/enemy-geometry-ci-source.mjs';")
edit(path," const rawJs=discoverJs(),rawLua=readdirSync('tests/lua').filter(p=>p.endsWith('.lua')).map(p=>'tests/lua/'+p).sort();", " const currentRaw={js:discoverJs(),lua:readdirSync('tests/lua').filter(p=>p.endsWith('.lua')).map(p=>'tests/lua/'+p).sort()},historical={};\n for(const [kind,paths]of Object.entries(currentRaw)){\n  assertEnemyGeometryRawInventory(paths,kind);\n  historical[kind]=enemyGeometryPriorInventory(paths,kind,readFileSync);\n  for(const path of paths.filter(path=>!historical[kind].includes(path))){\n   assert.throws(()=>assertEnemyGeometryRawInventory(paths.filter(p=>p!==path),kind),/inventory/);\n   for(const value of [null,readFileSync(path,'utf8')+'\\n'])assert.throws(()=>enemyGeometryPriorInventory(paths,kind,(p,e)=>p===path?value:readFileSync(p,e)),/fresh complete integration source|replaceAll/);\n  }\n }\n const {js:rawJs,lua:rawLua}=historical;")
