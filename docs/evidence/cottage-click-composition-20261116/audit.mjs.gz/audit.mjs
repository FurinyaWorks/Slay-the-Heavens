import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {sourceEpoch,preCottageClickSourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {cottageClickSourcePacket as packet,extendCottageClickSource} from '../../tests/helpers/cottage-click-source.mjs';
import {cottageClickCiPacket,assertCottageClickCiCurrent} from '../../tests/helpers/cottage-click-ci-source.mjs';
import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex'),norm=b=>b.toString('utf8').replaceAll('\r\n','\n');
const git=(...args)=>execFileSync('git',['-c','core.commitGraph=false',...args],{maxBuffer:32*1024*1024});
const tree=commit=>new Map(git('ls-tree','-r',commit).toString().trim().split('\n').map(line=>{const [meta,path]=line.split('\t');return[path,meta.split(' ')[2]];}));
const actual=tree(packet.currentCommit),legacy=tree(packet.legacyCommit),proof=sourceEpoch.proof;
let currentCount=0,legacyCount=0;
for(const [path,row]of Object.entries(proof.current)){
 if(row===null)continue;
 assert.equal(norm(readFileSync(path)),row.source,path+' current disk');
 assert.equal(hash(row.source),row.sha256,path+' current digest');
 assert.equal(actual.get(path),row.gitBlob,path+' real product Git blob');currentCount++;
}
for(const [path,row]of Object.entries(packet.legacyCurrent)){
 assert.equal(legacy.get(path),row.gitBlob,path+' real retained legacy Git blob');
 assert.equal(hash(row.source),row.sha256,path+' complete legacy source');legacyCount++;
}
for(const [path,row]of Object.entries(packet.combinedProducers)){
 assert.equal(git('rev-parse',row.commit+':'+path).toString().trim(),actual.get(path),path+' actual producer');
 assert.deepEqual(git('show','-s','--format=%P',row.commit).toString().trim().split(' ').filter(Boolean),row.parents,path+' actual producer parents');
}
assert.deepEqual(proof.owners,[...preCottageClickSourceEpoch.proof.owners,'src/lua/abyss_relic_pending_ui.lua'].sort());
assert.equal(proof.owners.length,118);
for(const bad of [{...packet,legacyCurrent:{}},{...packet,legacyCommit:'0'.repeat(40)}])assert.throws(()=>extendCottageClickSource(preCottageClickSourceEpoch,bad));
const priorTree=tree(packet.baseCommit),originalTree=tree('3eb212bd18e3af038f65ac67ed93049af70cc78e');let oldArchives=0;
for(const [path,sha]of Object.entries(cottageClickCiPacket.immutableArchives)){
 assert.equal(hash(readFileSync(path)),sha,path+' current immutable archive');
 const commit=priorTree.has(path)?packet.baseCommit:originalTree.has(path)?'3eb212bd18e3af038f65ac67ed93049af70cc78e':null;
 if(commit){const bytes=git('show',commit+':'+path),pointer=bytes.toString('utf8').match(/^version https:\/\/git-lfs.github.com\/spec\/v1\noid sha256:([a-f0-9]{64})\nsize (\d+)\n$/);assert.equal(sha,pointer?pointer[1]:hash(bytes),path+' original committed archive');oldArchives++;}
}
for(const kind of ['source','ci-source'])assert.deepEqual(readFileSync('tests/helpers/cottage-regression-legacy-'+kind+'.json.gz'),git('show','7eac3d3131e12dfceae09356464433b83485e397:tests/helpers/mobile-cottage-'+kind+'.json.gz'));
assertCottageClickCiCurrent();assertIntegratedCurrent();
const result={status:'pass',prior:packet.baseCommit,product:packet.currentCommit,legacy:packet.legacyCommit,currentBindings:currentCount,legacyBindings:legacyCount,owners:proof.owners.length,newOwners:proof.owners.filter(path=>!preCottageClickSourceEpoch.proof.owners.includes(path)),originalArchives:oldArchives,currentArchives:Object.keys(cottageClickCiPacket.immutableArchives).length,raw:{before:Object.fromEntries(Object.entries(cottageClickCiPacket.priorInventory).map(([k,v])=>[k,v.length])),current:Object.fromEntries(Object.entries(cottageClickCiPacket.currentInventory).map(([k,v])=>[k,v.length]))}};
writeFileSync('.artifacts/cottage-final/audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
