import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('.artifacts/cottage-final');prepared=json.loads(root.joinpath('prepared.json').read_text())
prior,checkpoint=prepared['prior'],prepared['product']
git=lambda *args:subprocess.check_output(['git','-c','core.commitGraph=false','-c','core.quotePath=false',*args])
sha=lambda b:hashlib.sha256(b).hexdigest()
def record(raw):
 text=raw.decode().replace('\r\n','\n');data=text.encode()
 return dict(source=text,sha256=sha(data),gitBlob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
basefiles=git('ls-tree','-r','--name-only',prior).decode().splitlines()
inventory=lambda paths:dict(js=sorted(p for p in paths if re.fullmatch(r'tests/[^/]+\.test\.mjs',p)),lua=sorted(p for p in paths if re.fullmatch(r'tests/lua/[^/]+\.lua',p)))
paths=set(git('diff','--name-only',prior,checkpoint).decode().splitlines())|set(git('diff','--name-only',checkpoint).decode().splitlines())
paths|={'tests/helpers/cottage-click-source.mjs'}
paths|={'src/lua/abyss_battle_card_gestures.lua','src/lua/abyss_battle_potion_popup.lua','src/lua/abyss_battle_ui.lua'}
paths={p for p in paths if p.startswith(('src/','tests/','scripts/','config/')) and not p.endswith('.gz')}
leaf='tests/helpers/cottage-click-ci-source.mjs';paths.discard(leaf)
currentfiles=[p.as_posix() for p in Path('tests').rglob('*') if p.is_file()]
p=dict(schemaVersion=1,normalization='LF',baseCommit=prior,releaseBase='1cc5479b713edab6fd26db4e20f8eb22b7401cb2',prerequisites=[prior],currentCommit=checkpoint,currentTreeCommitted=False,currentCommitRole='real original-cottage/current-potion committed product merge; auxiliary snapshot separately captured',files={},immutableArchives={},priorInventory=inventory(basefiles),currentInventory=inventory(currentfiles))
for path in sorted(paths):
 p['files'][path]=dict(beforeCommit=prior,before=record(git('show',prior+':'+path)) if path in basefiles else None,current=record(Path(path).read_bytes()))
for path in sorted(Path('tests/helpers').rglob('*.gz')):
 if path.as_posix()=='tests/helpers/cottage-click-ci-source.json.gz':continue
 raw=path.read_bytes()
 # Materialize only exact local objects, never download or mutate their identity.
 if raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1])
  common=Path(git('rev-parse','--git-common-dir').decode().strip()).resolve()
  obj=common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid
  content=obj.read_bytes();assert len(content)==size and sha(content)==oid,path
  path.write_bytes(content);raw=content
 p['immutableArchives'][path.as_posix()]=sha(raw)
data=gzip.compress((json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0)
Path('tests/helpers/cottage-click-ci-source.json.gz').write_bytes(data)
text=Path(leaf).read_text();marker='COTTAGE_CLICK_CI_PACKET_SHA256'
if marker not in text:
 old=json.loads(root.joinpath('capture.json').read_text())['ciSha256'];assert text.count(old)==1;text=text.replace(old,marker)
assert text.count(marker)==1;Path(leaf).write_text(text.replace(marker,sha(data)),encoding='utf8',newline='\n')
receipt=dict(prior=prior,product=checkpoint,ciSha256=sha(data),ciBytes=len(data),files=len(p['files']),archives=len(p['immutableArchives']),priorInventory={k:len(v)for k,v in p['priorInventory'].items()},currentInventory={k:len(v)for k,v in p['currentInventory'].items()})
root.joinpath('capture.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
