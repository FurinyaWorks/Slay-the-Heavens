"""Append a real cottage epoch over a supplied, committed potion candidate.

Reads immutable Git inputs; never overwrites an existing packet or trust leaf.
Run only after merging that exact prerequisite into this tree. CI capture is a
separate final step, after all consumers and copy hashes are stable.
"""
import gzip, hashlib, json, re, subprocess, sys
from pathlib import Path

prior, checkpoint = sys.argv[1:3]
legacy = '7eac3d3131e12dfceae09356464433b83485e397'
legacy_product = '89f3d88c47b72d843db113be5a2e91896cf1f869'
release = '1cc5479b713edab6fd26db4e20f8eb22b7401cb2'
root = Path('.artifacts/cottage-final')
git = lambda *args: subprocess.check_output(['git','-c','core.commitGraph=false','-c','core.quotePath=false',*args])
sha = lambda b: hashlib.sha256(b).hexdigest()
def record(raw):
    text = raw.decode().replace('\r\n','\n'); data = text.encode()
    return dict(source=text,sha256=sha(data),gitBlob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
def put(path, text): Path(path).write_text(text,encoding='utf8',newline='\n')
def edit(path, before, after):
    text=Path(path).read_text(encoding='utf8')
    if text.count(after)==1:return
    assert text.count(before)==1,(path,before[:140],text.count(before))
    put(path,text.replace(before,after))
def append(path,text):
    current=Path(path).read_text(encoding='utf8')
    if text.lstrip() in current:return
    put(path,current.rstrip()+'\n\n'+text.lstrip())
def transform(text):
    return text.replace('mobile-cottage','cottage-click').replace('MobileCottage','CottageClick').replace('mobileCottage','cottageClick').replace('preMobileCottageSourceEpoch','preCottageClickSourceEpoch').replace('cottage composition','cottage click composition').replace(legacy_product,checkpoint).replace('89dfc774b1c6bb146b91e6064039f4d648db0d33',prior).replace('actualCottage','actualCottageClick')

assert git('merge-base','--is-ancestor',prior,checkpoint)==b''
assert git('merge-base','--is-ancestor','3eb212bd18e3af038f65ac67ed93049af70cc78e',checkpoint)==b''
production=['src/lua/abyss_node_ui_events.lua','src/lua/abyss_relic_pending_ui.lua']
potion=['src/lua/abyss_battle_card_gestures.lua','src/lua/abyss_battle_potion_popup.lua','src/lua/abyss_battle_ui.lua']
p=dict(schemaVersion=1,normalization='LF',baseCommit=prior,releaseBase=release,prerequisites=[prior],currentCommit=checkpoint,currentTreeCommitted=True,currentCommitRole='committed original-cottage/current-potion merge; official and device acceptance independent',before={},current={},producers={},originalSources={},inheritedSources={},combinedProducers={})
legacy_packet=json.loads(gzip.decompress(git('show',legacy+':tests/helpers/mobile-cottage-source.json.gz')))
for path in production+potion:
    commit=git('log','-1','--format=%H',checkpoint,'--',path).decode().strip()
    producer=dict(commit=commit,parents=git('show','-s','--format=%P',commit).decode().split())
    p['combinedProducers'][path]=producer
    if path in production:
        p['before'][path]=record(git('show',prior+':'+path));p['current'][path]=record(git('show',checkpoint+':'+path));p['producers'][path]=producer
        p['originalSources'][path]=legacy_packet['originalSources'][path]
        assert p['current'][path]['gitBlob']==p['originalSources'][path]['gitBlob']
    else:
        p['inheritedSources'][path]=record(git('show',prior+':'+path))
        assert git('rev-parse',prior+':'+path)==git('rev-parse',checkpoint+':'+path)
# Whole real historical view, not a projection fabricated from today's tree.
p['legacyCommit']=legacy_product
p['legacyCurrent']={path:record(git('show',legacy_product+':'+path)) for path in git('ls-tree','-r','--name-only',legacy_product).decode().splitlines() if path=='config/architecture.json' or re.fullmatch(r'src/lua/[^/]+\.lua',path)}
packet_path='tests/helpers/cottage-click-source.json.gz'
data=gzip.compress((json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0)
if Path(packet_path).exists():assert Path(packet_path).read_bytes()==data
Path(packet_path).write_bytes(data)
source=transform(git('show',legacy+':tests/helpers/mobile-cottage-source.mjs').decode())
source=source.replace('c854c2a5b21dfda72a92a738b6fc8f08ff52aa8c1008f1b957c73d1f11f5f3da',sha(data))
source=source.replace(" const targets={...prior.targets};assert(!Object.hasOwn(targets,'cottageClickPrior'));", " assert.equal(packet.legacyCommit,'"+legacy_product+"');\n assert.deepEqual(packet.legacyCurrent,cottageClickSourcePacket.legacyCurrent,'complete real historical cottage production');\n const targets={...prior.targets,cottageRegressionLegacy:{commit:packet.legacyCommit,files:packet.legacyCurrent}};assert(!Object.hasOwn(targets,'cottageClickPrior'));")
put('tests/helpers/cottage-click-source.mjs',source)
# Keep the original prepared packets byte-for-byte as explicit historical inputs.
for kind in ['source','ci-source']:
    Path('tests/helpers/cottage-regression-legacy-'+kind+'.json.gz').write_bytes(git('show',legacy+':tests/helpers/mobile-cottage-'+kind+'.json.gz'))
ci=transform(git('show',legacy+':tests/helpers/mobile-cottage-ci-source.mjs').decode()).replace('5b294b07f6e0d722285fe7a44f43dbc97cbcb652ce4adafdeaaa44f312375e8d','COTTAGE_CLICK_CI_PACKET_SHA256')
assert 'COTTAGE_CLICK_CI_PACKET_SHA256' in ci
put('tests/helpers/cottage-click-ci-source.mjs',ci)

path='tests/helpers/closeout-source-epoch.mjs'
edit(path,"import {extendPotionClickSource} from './potion-click-source.mjs';", "import {extendPotionClickSource} from './potion-click-source.mjs';\nimport {extendCottageClickSource} from './cottage-click-source.mjs';")
edit(path,'export const sourceEpoch=extendPotionClickSource(prePotionClickSourceEpoch);','export const preCottageClickSourceEpoch=extendPotionClickSource(prePotionClickSourceEpoch);\nexport const sourceEpoch=extendCottageClickSource(preCottageClickSourceEpoch);')
path='tests/helpers/integrated-ci-source.mjs'
edit(path,'const priorCiSource=',"import {cottageClickCiSource,cottageClickCiCheckedSource,cottageClickHistoricalRead,cottageClickPriorInventory,assertCottageClickCiCurrent} from './cottage-click-ci-source.mjs';\nconst priorCiSource=")
edit(path,'potionClickCiSource(path,source)','potionClickCiSource(path,cottageClickCiSource(path,source))')
edit(path,'potionClickCiCheckedSource(path,source)','potionClickCiCheckedSource(path,cottageClickCiCheckedSource(path,source))')
edit(path,' assertPotionClickCiCurrent(read);\n const clickPriorRead=potionClickHistoricalRead(read);',' assertCottageClickCiCurrent(read);\n const beforeCottageRead=cottageClickHistoricalRead(read);\n assertPotionClickCiCurrent(beforeCottageRead);\n const clickPriorRead=potionClickHistoricalRead(beforeCottageRead);')
edit(path,' read=potionClickHistoricalRead(read);',' paths=cottageClickPriorInventory(paths,kind,read);read=cottageClickHistoricalRead(read);\n read=potionClickHistoricalRead(read);')
path='tests/helpers/copy-integration-source-closure.mjs'
copy_paths=['tests/helpers/closeout-source-epoch.mjs','tests/helpers/cottage-click-source.mjs',packet_path]
rows=[]
for name in copy_paths:
    before=sha(git('show',prior+':'+name).decode().replace('\r\n','\n').encode()) if name.endswith('closeout-source-epoch.mjs') else None
    rows.append(dict(path=name,before=before,after=sha(Path(name).read_bytes())))
addition='export const cottageClickHelperCopies='+json.dumps(rows,separators=(',',':'))+";\nfor(const row of cottageClickHelperCopies){assert.equal(files[row.path]??null,row.before,'exact cottage click helper-copy predecessor: '+row.path);files[row.path]=row.after;}\n"
edit(path,'const inside=(root,path)=>',addition+'const inside=(root,path)=>')

ci_import="import {cottageClickHistoricalRead,cottageClickCiRead,cottageClickCiPacket,cottageClickCiSource,cottageClickPriorInventory,assertCottageClickCiCurrent,assertCottageClickRawInventory} from './helpers/cottage-click-ci-source.mjs';"
for path in ['tests/ci-complete-calibration.test.mjs','tests/integrated-ci-source.cases.mjs']:
    edit(path,"import {readFileSync as actualPotionClickReadFileSync,readdirSync} from 'node:fs';", "import {readFileSync as actualCottageClickReadFileSync,readdirSync} from 'node:fs';\n"+ci_import+"\nconst actualPotionClickReadFileSync=cottageClickHistoricalRead(actualCottageClickReadFileSync);")
    edit(path,'discoverJs as actualPotionRegressionDiscoverJs','discoverJs as actualCottageClickDiscoverJs')
    needle='const rawMobilePotionDiscoverJs=' if 'calibration' in path else 'const discoverJs='
    edit(path,needle,"const actualPotionRegressionDiscoverJs=()=>cottageClickPriorInventory(actualCottageClickDiscoverJs(),'js',actualCottageClickReadFileSync);\nconst beforeCottageClickLua=()=>cottageClickPriorInventory(readdirSync('tests/lua').filter(n=>n.endsWith('.lua')).map(n=>'tests/lua/'+n).sort(),'lua',actualCottageClickReadFileSync);\n"+needle)
    text=Path(path).read_text(encoding='utf8')
    # All pre-existing Lua contracts belong to the explicit predecessor inventory.
    physical="readdirSync('tests/lua').filter(n=>n.endsWith('.lua')).map(n=>'tests/lua/'+n).sort()"
    marker="const beforeCottageClickLua=()=>cottageClickPriorInventory("+physical
    text=text.replace(marker,'const beforeCottageClickLua=()=>cottageClickPriorInventory(COTTAGE_RAW_LUA')
    text=text.replace(physical,'beforeCottageClickLua()').replace('COTTAGE_RAW_LUA',physical)
    text=text.replace("const {sourceEpoch,prePotionClickSourceEpoch}=", "const {preCottageClickSourceEpoch:sourceEpoch,prePotionClickSourceEpoch}=")
    if 'cases' in path:
        text=text.replace("const value=actualPotionClickReadFileSync(p,e);", "const value=actualCottageClickReadFileSync(p,e);")
    put(path,text)
    old=git('show',legacy+':'+path).decode()
    extra=old[old.index("test('cottage composition raw Full" if 'calibration' in path else "test('cottage composition production sources"):]
    append(path,transform(extra))

path='tests/integration-source-epoch.test.mjs'
old=git('show',legacy+':'+path).decode();start=old.index("test('cottage composition copy closure");end=old.find("\ntest(",start+1)
if end<0:end=len(old)
append(path,transform(old[start:end]))
# These two live union guards were explicitly fixed by7eac; retain that exact
# assertion structure, substituting only the name of the new outer predecessor.
for path in ['tests/defect-final-source-epoch.test.mjs','tests/encounter-formation-source-epoch.test.mjs']:
    old=git('show',legacy+':'+path).decode().replace('preMobileCottageSourceEpoch','preCottageClickSourceEpoch').replace('targets.mobileCottagePrior','targets.cottageClickPrior')
    put(path,old)
# Raw StS inventory must pass the explicit new outer discovery boundary first.
path='tests/sts-style-source-epoch.test.mjs'
old=git('show',legacy+':'+path).decode().replace('MobileCottage','CottageClick').replace('mobileCottage','cottageClick').replace('mobile-cottage','cottage-click')
put(path,old)
root.joinpath('prepared.json').write_text(json.dumps(dict(prior=prior,product=checkpoint,productionPacketSha256=sha(data),productionPacketBytes=len(data),copyPaths=copy_paths),indent=2)+'\n')
print('Prepared real cottage-click production and consumer continuation:',prior,checkpoint,sha(data))
