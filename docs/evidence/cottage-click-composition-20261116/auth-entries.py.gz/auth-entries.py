from pathlib import Path
import subprocess
path=Path('tests/helpers/cottage-click-ci-source.mjs');text=path.read_text()
before="const text=typeof raw==='string'?raw:raw.toString('utf8'),prior=cottageClickCiSource(path,text);"
after=before+"\n if(prior!==text)assertCottageClickCiCurrent(read);"
assert text.count(before)==1;text=text.replace(before,after)
before="const text=typeof raw==='string'?raw:raw.toString('utf8'),prior=checkedSource(path,text);"
after=before+"\n if(prior!==text)assertCottageClickCiCurrent(read);"
assert text.count(before)==1;text=text.replace(before,after)
path.write_text(text,encoding='utf8',newline='\n')
prior='3e96a1589435f8b06645db095775a789f24b1350'
source=subprocess.check_output(['git','show',prior+':tests/integrated-ci-source.cases.mjs']).decode()
start=source.index("test('potion click historical entry")
end=source.find("\ntest(",start+1)
if end<0:end=len(source)
test=source[start:end].replace('potion click historical entry','cottage click historical entry').replace('potionClick','cottageClick').replace('PotionClick','CottageClick').replace('actualCottageClickReadFileSync','actualCottageClickReadFileSync').replace("path='src/lua/abyss_battle_ui.lua'","path='src/lua/abyss_node_ui_events.lua'")
path=Path('tests/integrated-ci-source.cases.mjs');path.write_text(path.read_text().rstrip()+'\n\n'+test.lstrip(),encoding='utf8',newline='\n')
# The CI-only reader has its own before-current entry and must enforce the same
# fresh guard. Exercise it after warm success, not only the explicit assertion.
with path.open('a',encoding='utf8',newline='\n')as out:
 out.write("""
test('cottage click CI reader authenticates all current owners before exposing historical CI',()=>{
 const path='tests/helpers/closeout-source-epoch.mjs';
 const other='src/lua/abyss_relic_pending_ui.lua';let fault;
 const read=(p,e)=>{const raw=actualCottageClickReadFileSync(p,e);if(p!==fault)return raw;return typeof raw==='string'?raw+'\\n':Buffer.concat([raw,Buffer.from('\\n')]);};
 const reader=cottageClickCiRead(read),expected=cottageClickCiPacket.files[path].before.source;
 assert.equal(reader(path,'utf8'),expected);
 fault=other;assert.throws(()=>reader(path,'utf8'),/fresh complete integration source/);
 fault=undefined;assert.equal(reader(path,'utf8'),expected);
});
""")
