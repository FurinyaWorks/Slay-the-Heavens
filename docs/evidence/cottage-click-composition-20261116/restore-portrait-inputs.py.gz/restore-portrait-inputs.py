import hashlib,json,re,subprocess
from pathlib import Path
pack=json.loads(Path('art/performance/selection-budget-v1.json').read_text())
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir']).decode().strip()).resolve()
receipt=[]
for asset in pack['assets'].values():
 path=Path(asset['source']);raw=path.read_bytes()
 if raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1])
  content=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes()
  assert len(content)==size and hashlib.sha256(content).hexdigest()==oid
  assert oid==asset['sourceSha256'];path.write_bytes(content)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==asset['sourceSha256']
 receipt.append(dict(path=path.as_posix(),sha256=asset['sourceSha256'],bytes=path.stat().st_size))
Path('.artifacts/cottage-final/portrait-inputs.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
