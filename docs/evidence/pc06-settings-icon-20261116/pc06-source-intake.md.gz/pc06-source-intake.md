# PC06 有界源码核对（未实施 / 未验收）

原话为05:26–05:45：“右上角这个菜单按钮”“样式跟全局都不统一”“深褐色、深棕色”“样式要复用”。实际逐字稿127附近的完整原话、文件hash与PC06台账行固定在JSON。canonical为TASK-4.16；本轮没有改产品、Backlog、任务、PR或GUI，也没有运行Host/测试。

结论：**可单独复用#672既有的100161原生设置图标替换，不等同于PC06色调验收；#690只解决导航/说明入口，不含该图标替换。** Root先通过现有TASK-4.16 CLI记录计划，再决定选择性适配；不重新实现已有成果。

## 精确来源与实际控件

- Release36：`36b9b157ee6f05b65eb9f1da7e2978647d36c210`；closeout树：`00ff9b272625942a4d1f22085722142baac9ee2f`；#690树：`8129bd8684a7ccf420ba0a8ec5fe077372050708`。
- #672快照：`1f7ce04c53189db8c39b59c797a45d57a2c7bac1`；已有作者产品提交`9c1fb9513422d67b89966a4b15fb8e1f01125e78`，原提交`e7f882a159500b43e048c29de2801d42a1ff78e0`。源码/测试每路径Git blob、LF SHA256与完整函数片段均在JSON。
- 已完成的纯buildUI生成仅为closeout的default/candidate-art/v25/official四profile，以及#690的official。所有入口原生hit均48×48、presetButton四态，初始位置[576,316]。default/candidate-art/v25是36px棕色圆盘三横线；normal fill#241B19、hover#3A2E28、pressed#170F0E，来自既有mapHeader token。
- Release36/closeout/#690的official还挂载隐藏`officialBattleHud`⚙文字层。`abyss_game_ui_view.lua:386–415`首次refresh把旧四态子件隐藏、只显示该层，移至Theme HUD菜单[594,338.5]；`abyss_game_ui.lua:206`在构造返回前同步调用refresh。原hit/命令仍由`abyss_game_ui_input.lua:254`控制。
- 正式共享四态配色为normal/pressed#D6CBA5、hover#FFF3CE、disabled#8F918B，当前所有者是`official-battle-hud.mjs`既有共享palette，**不是新增DesignToken**。`ui_theme.icon.settings=100161`已经存在。批准依据是UI_DESIGN共享战斗顶栏要求、已采用reference-ui-lab/app.js:41的gear入口和style.css的无底色#d6cba5 HUD按钮，不需要猜新颜色或创作PNG。

## #672可选复用的最小切片

`9c1fb`的`officialBattleUtilityFaces`（#672文件23–37行，主要24与29–32行）把遍历tuple改为entry列表；deck仍保留▱文字/count，exitEntry的symbol由30×36字号18的“⚙”文本，替换为28×28、`image:theme.icon.settings`的原生image。四态颜色、overlay名字、原48px hit和事件owner不变。因此**生产最小范围只有`scripts/official-battle-hud.mjs`该函数6行diff**；Release36已有100161，无新增素材/模块/主题/Lua依赖。

不能整提交cherry-pick：作者提交还改HP/gold宽度/minFont、药水位置、menu y335、前景层级与测试。`5562bfd603dc2ccc816b61cb6c769c16bbaeb798`又纠正了把正式face激活扩到V25的P2，保留official-only条件；本次图标选择性复用也应保留此边界。

作者原测试`tests/mobile-run-hud.test.mjs:25–36`包含四态image100161/28px/no-text与原hit身份。它还包含**另一条几何依赖**：Release36 y338.5+24=362.5>360，而作者伴随Theme改为y335+24=359。因此不能把整个混合范围测试原样移过来又忽略失败，也不能顺带搬Theme几何改动。另两个作者测试依赖HP/gold及Lua前景变更，均不属于纯图标切片。

可落地RED建议：单独命名既有图标facet的纯生成合同，检查四态native image100161、28px、无文字glyph，原hit/state mapping及deck symbol/count不变；Release36现在的text symbol会在image.kind断言失败。此为选择性复用部分的新窄合同，不声称已移植/通过作者完整混合测试。本轮没有执行RED或写入测试。

## 已有作者证据与限制

根`.artifacts/mobile-1115-ci/`的`mobile-hud-receipt.json`保留最初字体/Unicode与依赖失败、前景order失败，green日志11/11和final日志3/3；`review-hud-9c1fb951.json`记录独审official pass及V25 P2，后由5562bfd纠正。这些原有文件的完整hash和收据正文已收入本intake JSON索引；**本轮只读，没有重跑、借用旧结果作当前通过或宣称手机图标验收**。

## 棕面观察不能变成根因

生成树“旧棕面可见/official层隐藏”与运行时刷新后的“只显示gear”是源码和纯生成观察。构造器返回前已有同步refresh，不能据此断言出现用户可见首帧、ready后仍棕色或这就是PC06根因；不提出额外首帧修复。原PC候选/profile/状态及同候选设备画面仍缺失，PC06色调/样式保持未验收。

更正保留：我在精确比较前曾过早说“#672相关文件未改这条样式链”，此说法错误。精确Git差异确认#672已有原生图标替换；配色及旧棕面清理逻辑未变，不应把图标修复等同色调完成。
