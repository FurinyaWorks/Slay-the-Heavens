import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {assertStsStyleCiCurrent} from '../../tests/helpers/sts-style-ci-source.mjs';
import {integrationRead} from '../../tests/helpers/release-picker-b9-integration.mjs';
import {discoverJs} from '../../scripts/ci-shards.mjs';
const files=discoverJs(),target='tests/helpers/sts-style-ci-source.mjs',archive='tests/helpers/integrated-ci-source.json.gz';
let changed=null,mode=null;
const read=(p,e)=>{if(changed===p&&mode==='missing')throw Error('missing '+p);const raw=readFileSync(p,e);return changed===p&&mode==='drift'?typeof raw==='string'?raw+'\n':Buffer.concat([raw,Buffer.from('\n')]):raw;};
const projected=integrationRead('picker',read);
for(const p of [target,archive])for(const m of ['missing','drift',null]){
 changed=m?p:null;mode=m;const start=performance.now();
 if(m){assert.throws(()=>assertStsStyleCiCurrent(files,read),e=>{assert(e.message.includes(p));return true;});assert.throws(()=>projected('tests/ci-complete-calibration.test.mjs'),e=>{assert(e.message.includes(p));return true;});}
 else {assertStsStyleCiCurrent(files,read);const buffer=projected(target);assert(Buffer.isBuffer(buffer));assert.equal(buffer.toString('utf8'),JSON.parse(readFileSync('tests/helpers/release-picker-b9-integration.json','utf8')).fixedStsValidatorBefore.source);}
 console.log(JSON.stringify({p,m,outcome:m?'rejected':'recovered-buffer',ms:performance.now()-start}));
}
