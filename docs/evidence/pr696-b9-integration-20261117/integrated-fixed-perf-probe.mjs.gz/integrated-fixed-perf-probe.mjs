import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
let corrupt=null,packetReads=0,total=0;
const packet='tests/helpers/release-picker-b9-integration.json';
const raw=(p,e)=>{total++;if(p===packet)packetReads++;const v=readFileSync(p,e);return p===corrupt?typeof v==='string'?v+'\n':Buffer.concat([v,Buffer.from('\n')]):v;};
for(const target of [null,'src/lua/abyss_card_flow.lua',packet,null]){
 corrupt=target;packetReads=0;total=0;const start=performance.now();
 if(target)assert.throws(()=>assertIntegratedCurrent(raw),e=>{assert.match(e.message,/fresh complete integration source/);assert(e.message.includes(target)||target===packet&&e.message.includes('B9 trust packet'));return true;});
 else assertIntegratedCurrent(raw);
 assert.equal(packetReads,1,'exactly one complete fresh boundary per fixed validation call');
 console.log(JSON.stringify({target,outcome:target?'rejected':'pass',packetReads,total,durationMs:performance.now()-start}));
}
