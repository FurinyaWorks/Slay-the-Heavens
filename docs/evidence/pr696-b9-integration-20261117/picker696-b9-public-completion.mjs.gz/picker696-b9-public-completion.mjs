import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {pathToFileURL} from 'node:url';
const m=await import(pathToFileURL(process.cwd()+'/tests/helpers/release-picker-b9-integration.mjs'));let bad=false,checks=0;
const read=(p,e)=>{const v=readFileSync(p,e);return bad&&p==='tests/helpers/release-picker-b9-integration.json'?v+'\n':v;};
for(const [side,path]of [['picker','src/lua/abyss_card_flow.lua'],['pc22','src/lua/abyss_node_ui_feedback.lua'],['selection','src/lua/abyss_card_flow.lua']]){
 const r=m.integrationProductionRead(side,read),raw=readFileSync(path,'utf8');assert.notEqual(r(path,'utf8'),raw);checks++;
 bad=true;assert.throws(()=>r(path,'utf8'));checks++;bad=false;assert.notEqual(r(path,'utf8'),raw);checks++;
 const paths=m.integrationInventory('js');assert(m.integrationPriorInventory(paths,side,'js',read).length<paths.length);checks++;
 bad=true;assert.throws(()=>m.integrationPriorInventory(paths,side,'js',read));checks++;bad=false;assert(m.integrationPriorInventory(paths,side,'js',read).length<paths.length);checks++;
}
console.log(JSON.stringify({checks,status:'PASS production and inventory warm packet drift/restore'}));
