import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {discoverJs} from '../../scripts/ci-shards.mjs';
import {integratedPriorInventory,integratedCiProof} from '../../tests/helpers/integrated-ci-source.mjs';
const inventories={js:discoverJs(),lua:readdirSync('tests/lua').filter(x=>x.endsWith('.lua')).map(x=>'tests/lua/'+x).sort()};
let bad=null,reads=0,packets=0;const packet='tests/helpers/release-picker-b9-integration.json';
const read=(p,e)=>{reads++;if(p===packet)packets++;const v=readFileSync(p,e);return p===bad?typeof v==='string'?v+'\n':Buffer.concat([v,Buffer.from('\n')]):v;};
const t=performance.now();
for(const [kind,current] of Object.entries(inventories)){
 bad=null;packets=0;const expected=integratedPriorInventory(current,'sts',kind,read);assert.equal(packets,1);
 for(const path of ['src/lua/abyss_card_flow.lua',packet]){bad=path;assert.throws(()=>integratedPriorInventory(current,'sts',kind,read),/fresh complete integration source/);}
 bad=null;packets=0;assert.deepEqual(integratedPriorInventory(current,'sts',kind,read),expected);assert.equal(packets,1);
 reads=0;assert.deepEqual(integratedPriorInventory(expected,'sts',kind,read),expected);assert.equal(reads,0,'historical no-op must remain zero IO');
 for(const paths of [current.slice(1),[...current,current[0]],[...current,'tests/foreign.'+kind]])assert.throws(()=>integratedPriorInventory(paths,'sts',kind,read),/inventory/);
}
assert.throws(()=>integratedPriorInventory([],'unknown','js',read),/known integration inventory/);
console.log(JSON.stringify({result:'PASS',ms:performance.now()-t,checks:'js/lua single auth, warm owner+packet reject/recovery, historical no-op zero IO, missing/duplicate/foreign inventory reject'}));
