import gzip,json,hashlib
from pathlib import Path
load=lambda n:json.loads(gzip.decompress(Path('tests/helpers/'+n+'.json.gz').read_bytes()))
h=lambda s:hashlib.sha256(s.encode()).hexdigest()
norm=lambda s:s.replace('\r\n','\n')
proof=load('integrated-ci-source');picker=load('release-picker-controls-ci-source');pc22=load('release-pc22-basic-feedback-ci-source');selection=load('release-selection-map-ci-source');bootstrap=load('release-bootstrap-ci-source');join=json.loads(Path('tests/helpers/release-picker-b9-integration.json').read_text())
production=lambda p:p.startswith('src/') or p=='config/architecture.json'
def joined(p,s):
 if production(p) or not isinstance(s,str) or '\r\r\n' in s or p not in join['files'] or h(norm(s))!=join['files'][p]:return s
 if p=='tests/helpers/sts-style-ci-source.mjs':return join['fixedStsValidatorBefore']['source']
 own=picker['files'].get(p)
 if own:return own['current']['source']
 for packet in [picker,pc22,selection]:
  other=packet['files'].get(p)
  if other and other.get('before'):return other['before']['source']
 return s
def layer(packet,p,s,before=None):
 if production(p):return s
 row=packet['files'].get(p)
 if not row or not row.get('before') or not isinstance(s,str) or '\r\r\n' in s:return s
 if before and row['before']['sha256']!=before['sha256']:return s
 return row['before']['source'] if h(norm(s))==row['current']['sha256'] else s
def public(p,s,t):
 if production(p):return s,False
 original=s;row=proof['files'].get(p);s=joined(p,s);mid=s!=original
 s=layer(bootstrap,p,layer(picker,p,s),row['current'] if row else None)
 if row and row['views'].get(t) and isinstance(s,str) and '\r\r\n' not in s and h(norm(s))==row['current']['sha256'] and row['views'][t]['sha256']!=row['current']['sha256']:s=row['views'][t]['source']
 return s,mid or s!=original
stats={'fileTargetPairs':0,'sourceReaderAuthorizations':0,'publicCalls':0,'publicAuthorizations':0,'foreignAuthorizations':0,'crlfAuthorizations':0}
for p,row in proof['files'].items():
 disk=Path(p).read_text();j=joined(p,disk);source=norm(layer(bootstrap,p,layer(picker,p,j)))
 for t in proof['sources']:
  stats['fileTargetPairs']+=1;stats['sourceReaderAuthorizations']+=int(j!=disk)
  inputs=[(source,'healthy')]
  if not production(p) and row['views'].get(t):inputs.append((source.replace('\n','\r\n'),'crlf'))
  inputs += [(x,'foreign') for x in [source+'\n',source[1:],source[:-1],None,{},17]]
  for s,kind in inputs:
   result,auth=public(p,s,t);stats['publicCalls']+=1;stats['publicAuthorizations']+=int(auth)
   if kind=='foreign':stats['foreignAuthorizations']+=int(auth)
   if kind=='crlf':stats['crlfAuthorizations']+=int(auth)
  for foreign in ['__proto__','constructor','foreign/'+p]:
   _,auth=public(foreign,source,t);stats['publicCalls']+=1;stats['publicAuthorizations']+=int(auth);stats['foreignAuthorizations']+=int(auth)
stats['loopCompleteAuthorizations']=stats['sourceReaderAuthorizations']+stats['publicAuthorizations']
stats['estimatedLoopSecondsAt1_4to1_7s']=[round(stats['loopCompleteAuthorizations']*x,1) for x in [1.4,1.7]]
stats['scope']='OFFLINE branch-condition estimate only: excludes prelude/postlude and hashing/import work; NOT executed consumer or passing evidence'
print(json.dumps(stats,indent=2))
