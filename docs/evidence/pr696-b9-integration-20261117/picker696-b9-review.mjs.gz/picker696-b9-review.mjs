import assert from 'node:assert/strict';import {readFileSync,readdirSync} from 'node:fs';import {execFileSync} from 'node:child_process';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const root=process.cwd(),load=p=>import(pathToFileURL(root+'/'+p)),hash=b=>createHash('sha256').update(b).digest('hex');let count=0;const check=f=>{f();count++;};
const m=await load('tests/helpers/release-picker-b9-integration.mjs'),e=await load('tests/helpers/closeout-source-epoch.mjs'),i=await load('tests/helpers/integrated-ci-source.mjs');
const head='e9866fece8a01ed5fd5dc5530d8b4d9da4bbc9bc',base='b9bca884ed9b9831965b409885d78f719b9a567a';
for(const p of ['scripts/official-assets-layout.mjs','scripts/official-picker-controls.mjs','scripts/official-run-layout.mjs','src/lua/abyss_node_ui_feedback.lua'])check(()=>assert.equal(readFileSync(p,'utf8'),execFileSync('git',['show',head+':'+p],{encoding:'utf8'})));
check(()=>assert.equal(readFileSync('src/lua/abyss_card_flow.lua','utf8'),execFileSync('git',['show',base+':src/lua/abyss_card_flow.lua'],{encoding:'utf8'})));
for(const [ref,stem]of [[head,'release-picker-map-integration'],[base,'release-card-contact-integration']])for(const ext of ['mjs','json'])check(()=>assert.equal(readFileSync('tests/helpers/'+stem+'.'+ext,'utf8'),execFileSync('git',['show',ref+':tests/helpers/'+stem+'.'+ext],{encoding:'utf8'})));
for(const old of [e.pickerMapSourceEpoch,e.cardContactSourceEpoch])for(const [name,target]of Object.entries(old.proof.targets))check(()=>assert.deepEqual(e.sourceEpoch.proof.targets[name],target));
for(const [path,row]of Object.entries(e.sourceEpoch.proof.current))if(row)check(()=>assert.equal(readFileSync(path,'utf8').replaceAll('\r\n','\n'),row.source));
check(()=>assert.equal(e.sourceEpoch.proof.owners.length,117));check(()=>assert.equal(Object.keys(e.sourceEpoch.proof.targets).length,70));
let bad,mode;const read=(p,enc)=>{if(p!==bad)return readFileSync(p,enc);if(mode==='missing')throw Object.assign(Error('missing '+p),{code:'ENOENT'});const raw=readFileSync(p,enc);return mode==='empty'?(enc?'':Buffer.alloc(0)):(typeof raw==='string'?raw+'\n':Buffer.concat([raw,Buffer.from('\n')]))};
const path='tests/ci-complete-calibration.test.mjs',raw=readFileSync(path,'utf8');
const readers=['picker','pc22','selection'].map(side=>m.integrationRead(side,read));const integrated=i.integratedRead('closeout',{read});
for(const r of [...readers,integrated])check(()=>assert.notEqual(r(path,'utf8'),raw));
for(bad of ['src/lua/abyss_card_flow.lua','src/lua/abyss_node_ui_feedback.lua','tests/helpers/copy-integration-source-closure.mjs','tests/helpers/release-picker-b9-integration.json',...Object.keys(m.integrationPacket.archives)])for(mode of ['missing','empty','drift']){
 for(const r of [...readers,integrated])check(()=>assert.throws(()=>r(path,'utf8')));
 const saved=bad;bad=undefined;for(const r of [...readers,integrated])check(()=>assert.notEqual(r(path,'utf8'),raw));bad=saved;
}
bad=undefined;
for(const side of ['picker','pc22','selection']){
 check(()=>{const text=m.integrationRead(side)(path,'utf8'),bytes=m.integrationRead(side)(path);assert(Buffer.isBuffer(bytes));assert.equal(bytes.toString(),text)});
 check(()=>assert.equal(m.integrationRead(side,(p,enc)=>{const v=readFileSync(p,enc);return typeof v==='string'?v.replaceAll('\n','\r\n'):v})(path,'utf8'),m.integrationRead(side)(path,'utf8')));
 for(const foreign of [raw+'\n',raw.slice(1),null,undefined,{},Buffer.from(raw),raw.replaceAll('\n','\r\r\n')])check(()=>{let reads=0;assert.equal(m.integrationCiSource(path,foreign,side,()=>{reads++;throw Error('foreign-read')}),foreign);assert.equal(reads,0)});
}
console.log(JSON.stringify({checks:count,head,base,production:352,owners:117,targets:70,ciFiles:Object.keys(m.integrationPacket.files).length,archives:Object.keys(m.integrationPacket.archives).length,files:Object.fromEntries(['tests/helpers/release-picker-b9-integration.mjs','tests/helpers/release-picker-b9-integration.json','tests/helpers/closeout-source-epoch.mjs','tests/helpers/integrated-ci-source.mjs'].map(p=>[p,hash(readFileSync(p))]))},null,2));
