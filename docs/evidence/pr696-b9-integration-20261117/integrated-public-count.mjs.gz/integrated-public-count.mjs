import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {integratedSource} from '../../tests/helpers/integrated-ci-source.mjs';
const p='tests/ci-complete-calibration.test.mjs',s=readFileSync(p,'utf8');let packetReads=0,totalReads=0;
const read=(p,e)=>{totalReads++;if(p==='tests/helpers/release-picker-b9-integration.json')packetReads++;return readFileSync(p,e);};
const start=performance.now(),result=integratedSource(p,s,'sts',read);console.log(JSON.stringify({path:p,changed:result!==s,packetReads,totalReads,ms:performance.now()-start}));
