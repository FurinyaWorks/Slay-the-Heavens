import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {discoverJs} from '../../scripts/ci-shards.mjs';
import {integratedPriorInventory} from '../../tests/helpers/integrated-ci-source.mjs';
let packets=0,total=0;const read=(p,e)=>{total++;if(p==='tests/helpers/release-picker-b9-integration.json')packets++;return readFileSync(p,e);};
const s=performance.now();const result=integratedPriorInventory(discoverJs(),'sts','js',read);console.log(JSON.stringify({packets,total,ms:performance.now()-s,length:result.length}));
