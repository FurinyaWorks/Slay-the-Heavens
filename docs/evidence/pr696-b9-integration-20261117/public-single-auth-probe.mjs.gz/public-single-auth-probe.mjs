import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {integratedSource,integratedRead,integratedCiProof} from '../../tests/helpers/integrated-ci-source.mjs';
const p='tests/ci-complete-calibration.test.mjs',packet='tests/helpers/release-picker-b9-integration.json';
const current=readFileSync(p,'utf8');let bad=null,reads=0,packets=0;
const read=(p,e)=>{reads++;if(p===packet)packets++;const v=readFileSync(p,e);return p===bad?typeof v==='string'?v+'\n':Buffer.concat([v,Buffer.from('\n')]):v;};
const start=performance.now();
for(const source of [current,integratedCiProof.files[p].current.source]){
 bad=null;packets=0;const expected=integratedSource(p,source,'sts',read);assert.notEqual(expected,source);assert.equal(packets,1);
 bad='src/lua/abyss_card_flow.lua';assert.throws(()=>integratedSource(p,source,'sts',read),/linked owner src\/lua\/abyss_card_flow.lua/);
 bad=null;packets=0;assert.equal(integratedSource(p,source,'sts',read),expected);assert.equal(packets,1);
}
for(const source of [current+'\n',null,{},17]){reads=0;assert.equal(integratedSource(p,source,'sts',read),source);assert.equal(reads,0);}
for(const path of ['__proto__','constructor','foreign/'+p]){reads=0;assert.equal(integratedSource(path,current,'sts',read),current);assert.equal(reads,0);}
assert.throws(()=>integratedSource(p,current,'unknown',read),/known integration input/);
const reader=integratedRead('sts',{read});packets=0;assert(Buffer.isBuffer(reader(p)));assert.equal(packets,1);
bad=packet;assert.throws(()=>reader(p),/B9 trust packet/);bad=null;packets=0;assert(Buffer.isBuffer(reader(p)));assert.equal(packets,1);
console.log(JSON.stringify({outcome:'PASS',ms:performance.now()-start,contracts:'raw+historical-only changed, fresh repeated calls, warm owner/packet rejection+recovery, foreign 0IO, invalid target, Buffer'}));
