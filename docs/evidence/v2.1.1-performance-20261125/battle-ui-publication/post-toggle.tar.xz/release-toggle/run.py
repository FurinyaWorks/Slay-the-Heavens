import json
import os
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
scratch = here.parent
image = 'node:24.19.0-bookworm-slim@sha256:a9f5f7c91a432850b2a8a7797adf5eadb6c733ceed61167806cee7ea7fbc29df'
variants=['aa','release-proof','release-proof','aa','aa','release-proof']
for index,arm in enumerate(variants):
    checkout=scratch/arm
    assert (checkout/'build/lua/abyss_data.lua').is_file()
    args=['docker','run','--rm','--network','none','--cpus','.5','--memory','1g',
          '--memory-swap','1g','--cgroupns','private','--read-only','--user',f'{os.getuid()}:{os.getgid()}',
          '--mount',f'type=bind,src={checkout},dst=/repo,readonly',
          '--mount',f'type=bind,src={here/"worker.mjs"},dst=/repo/scripts/runtime-baseline/worker.mjs,readonly',
          '--mount',f'type=bind,src={here/"host.lua"},dst=/repo/scripts/runtime-baseline/host.lua,readonly',
          '--workdir','/repo',image,'sh','-c',
          'cat /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.max; node scripts/runtime-baseline/worker.mjs']
    result=subprocess.run(args,capture_output=True,text=True,timeout=120)
    (here/f'{index+1:02}-{arm}.txt').write_text(result.stdout+result.stderr)
    print(arm,result.returncode,flush=True)
    assert result.returncode==0
