import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
const require=createRequire(import.meta.url);
const {lua,lauxlib,lualib,to_luastring,to_jsstring}=require('fengari');
const L=lauxlib.luaL_newstate();lualib.luaL_openlibs(L);
const rows=[];let previous=performance.now(),before=[0,0,0,0,0];
let beforeMethods={},beforeProperties={};
let previousCpu=process.cpuUsage();
function histogram(state,index){
 const result={};lua.lua_pushnil(state);
 while(lua.lua_next(state,index)!==0){
  const key=to_jsstring(lua.lua_tostring(state,-2));
  Object.defineProperty(result,key,{value:lua.lua_tonumber(state,-1),enumerable:true});lua.lua_pop(state,1);
 }
 return result;
}
const delta=(current,previous)=>Object.fromEntries(Object.entries(current).map(([key,value])=>[key,value-(Object.hasOwn(previous,key)?previous[key]:0)]).filter(([,value])=>value!==0));
const keys=['requireCalls','moduleLoads','nativeCalls','propertyWrites','snapshots'];
lua.lua_pushjsfunction(L,state=>{
 const now=performance.now(),label=to_jsstring(lua.lua_tostring(state,1));
 const cpu=process.cpuUsage(previousCpu);previousCpu=process.cpuUsage();
 console.log("PHASE_MARK "+label+" "+Math.round(process.uptime()*1000));
 const current=keys.map((_,i)=>lua.lua_tonumber(state,i+2));
 const methods=histogram(state,7),properties=histogram(state,8);
 rows.push({phase:label,elapsedMs:now-previous,cpuMs:(cpu.user+cpu.system)/1000,...Object.fromEntries(keys.map((key,i)=>[key,current[i]-before[i]])),nativeMethods:delta(methods,beforeMethods),propertyNames:delta(properties,beforeProperties),memory:process.memoryUsage()});
 previous=now;before=current;beforeMethods=methods;beforeProperties=properties;return 0;
});
lua.lua_setglobal(L,to_luastring('BASELINE_MARK'));
const fixture=readFileSync('tests/lua/support/game_ui_fixture.lua','utf8');
const needle='return NativeContract.control(self,spec)';
if(fixture.split(needle).length!==2)throw Error('Host instrumentation anchor changed');
lua.lua_pushstring(L,to_luastring(fixture.replace(needle,'ABYSS_HOST_CONTROL(self); '+needle)));
lua.lua_setglobal(L,to_luastring('BASELINE_FIXTURE'));
const code=readFileSync(new URL('./host.lua',import.meta.url),'utf8');
if(lauxlib.luaL_dostring(L,to_luastring(code))!==lua.LUA_OK)throw Error(to_jsstring(lua.lua_tostring(L,-1)));
console.log('RUNTIME_BASELINE_JSON '+JSON.stringify({rows,maxRssKiB:process.resourceUsage().maxRSS}));
