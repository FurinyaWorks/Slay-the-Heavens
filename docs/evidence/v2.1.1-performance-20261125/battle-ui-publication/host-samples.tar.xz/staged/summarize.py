import collections
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

root, dest = map(Path, sys.argv[1:])
runs = [json.loads(line) for line in (root / 'runs.jsonl').read_text().splitlines()]
rollups = collections.defaultdict(lambda: collections.defaultdict(list))
signatures = collections.defaultdict(set)
for run in runs:
    if not run['complete']:
        continue
    raw = (root / run['file']).read_text().splitlines()
    methods = collections.defaultdict(dict)
    starts = collections.defaultdict(dict)
    points = collections.defaultdict(list)
    phases = {}
    for line in raw:
        fields = line.split('\t')
        if fields[0] == 'PHASE':
            phases[fields[1]] = {
                'cpuMs': float(fields[2]), 'wallMs': float(fields[3]),
                'updates': int(fields[4]), 'longestUpdateCpuMs': float(fields[5]),
            }
        elif fields[0] == 'TRACE':
            points[fields[2]].append(fields)
        elif fields[0] == 'METHOD_BEGIN':
            starts[fields[1]][fields[2]] = int(fields[3])
        elif fields[0] == 'METHOD':
            methods[fields[1]][fields[2]] = int(fields[3])
    previous = {}
    for phase, totals in phases.items():
        if run['mode'] == 'trace':
            frames = points[phase]
            first, = [frame for frame in frames if frame[3] == 'begin']
            last, = [frame for frame in frames if frame[3] == 'end']
            frames = [frame for frame in frames if int(first[1]) <= int(frame[1]) <= int(last[1])]
            current = methods[phase]
            totals.update({
                name: int(last[index]) - int(first[index])
                for index, name in [
                    (9, 'created'), (10, 'destroyed'), (14, 'sdkMethods'),
                    (15, 'propertyWrites'), (16, 'getChild'), (17, 'setVisible'),
                ]
            })
            heaps = [float(f[6]) for f in frames]
            totals['heapPeakKiB'] = max(heaps)
            totals['heapNetDropSamples'] = sum(b < a for a, b in zip(heaps, heaps[1:]))
            totals['methodDeltas'] = {
                key: value - starts.get(phase, previous).get(key, 0) for key, value in current.items()
            }
            previous = current
    rollups[run['arm']][run['mode']].append({'round': run['round'], 'phases': phases})
    if run['mode'] == 'trace':
        for name in ('PARTICLE', 'RULES'):
            rows = [line for line in raw if line.startswith(name + '\t')]
            assert rows, (name, run)
            digest = hashlib.sha256(('\n'.join(rows) + '\n').encode()).hexdigest()
            signatures[name].add((len(rows), digest))

def stats(samples):
    samples = sorted(samples)
    return {
        'p50': statistics.median(samples),
        'p95': samples[math.ceil(len(samples) * .95) - 1],
        'max': samples[-1],
    }

summary = {}
for arm, modes in rollups.items():
    summary[arm] = {}
    for mode, samples in modes.items():
        metrics = {}
        for phase in samples[0]['phases']:
            rows = [sample['phases'][phase] for sample in samples]
            metrics[phase] = {
                key: stats([row[key] for row in rows])
                for key, value in rows[0].items() if isinstance(value, (int, float))
            }
        summary[arm][mode] = {'samples': samples, 'metrics': metrics}

assert len(runs) == 48 and all(run['complete'] for run in runs), 'Incomplete paired runs'
assert all(len(value) == 1 for value in signatures.values()), signatures
dest.write_text(json.dumps({
    'n': len(runs), 'rollups': summary,
    'signature': {name: list(value)[0] for name, value in signatures.items()},
}, indent=2, sort_keys=True) + '\n')
