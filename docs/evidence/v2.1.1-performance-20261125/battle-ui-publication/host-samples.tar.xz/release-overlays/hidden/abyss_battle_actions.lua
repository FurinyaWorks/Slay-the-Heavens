-- Read state, issue Run commands. No damage/energy/outcome rules live in this view.
local Combat = require("abyss_combat")
local Actors = require("abyss_actor")
local Run = require("abyss_run")
local Theme = require("abyss_theme")
local Events = require("abyss_events")
local RewardOwner = require("abyss_battle_reward_owner")
local M = {}
local L = Theme.layout
local reasons = { insufficient_energy = "能量不足", invalid_target = "请选择存活的敌人", card_content_unavailable = "此卡牌尚未实装，可选择其他卡牌或跳过。",
    card_not_in_hand = "这张牌已离开手牌", not_player_turn = "敌方行动中",
    normality_limit = "平庸：本回合已打出三张牌",
    velvet_choker_limit = "天鹅绒颈圈：本回合已打出六张牌",
    unplayable_card = "这张牌不能打出", entangled = "被缠绕时无法打出攻击牌",
    selection_pending = "请先完成当前选牌", discard_choice_pending = "请先完成弃牌选择",
    card_choice_pending = "请先完成当前选牌",
    requires_empty_draw_pile = "抽牌堆为空时才能打出", requires_only_attacks = "手牌均为攻击牌时才能打出",
    requires_no_other_attack = "手中没有其他攻击牌时才能打出", no_matching_draw_card = "抽牌堆中没有符合条件的牌",
    command_failed = "战斗操作发生错误，请重试。若再次失败，请反馈游戏日志。",
    advanced_card_not_enabled = "此牌效果尚未接入", not_in_combat = "战斗已经结束",
    empty_potion_slot = "此药水已使用", invalid_potion_slot = "请选择有效药水",
    smoke_not_allowed = '此战斗不能使用烟雾弹',
    effect_overflow = "当前状态已达上限", potion_slots_full = "药水槽已满，请先丢弃旧药水。",
    potion_content_unavailable = "该稀有度药水尚未实装。", potion_blocked_by_sozu = "遗物阻止获得药水。" }
local function feedbackPresented(owner,battle)
    local feedback=owner.feedback
    return owner.busy==true and feedback and feedback.busy==true and owner.run and owner.feedbackRun==owner.run and owner.run.combat==battle
        and owner.feedbackBattle==battle and feedback.battle==battle and owner.displayBattle==feedback.shadow
end
local function selectedPotionView(run,slot)
    if Theme.presentationProfile=='official-assets-first' then return Run.potionSlotView(run,slot) end
    return Run.potionView(run)[slot]
end
local emptyControls={"hero","statusInfo","statusDismiss","dragLayer","playArea","endTurn",
    "rewardStage","rewardList","skip","continue","goldReward","stolenGold","cardReward","claimPotion","exhaustIcon","exhaust"}
local potionButtons={"potionPopup","potionReward","emeraldKeyReward","relicReward1","relicReward2"}
local pileIcons={"drawIcon","discardIcon","exhaustIcon"}
local function feedbackRetired(view)
    local feedback=view.feedback
    return not view.busy and not view.feedbackRun and not view.feedbackBattle
        and not feedback.busy and not feedback.idleBattle and not feedback.battle
end
local function hiddenProjectionUnowned(view,host)
    return not view.active and not view.run and not view.viewRun and not view.viewBattle
        and not view.displayBattle and not view.suspendedBattle and feedbackRetired(view)
        and not view.gesture and not view.carry and not view.help and not view.info and not view.potionAim
        and not host.monsterSurfaces.engineDestroyed
end
local function hiddenNativeProjection(owner,host,revision)
    local function current()
        assert(not host.monsterSurfaces.engineDestroyed,"hidden battle projection cancelled")
        return owner.rewardRender==revision and not owner.active
    end
    local function child(parent,name)
        local control=parent:GetChild(name)
        if current() then return control end
    end
    local function hidden(parent,name)
        local control=child(parent,name)
        if not control then return false end
        local visible=control.visible
        return current() and visible==false
    end
    local function hiddenList(parent, names)
        for _,name in ipairs(names) do if not hidden(parent,name) then return false end end
        return true
    end
    local function hiddenSlots(stage,potionHelp)
        for i=1,10 do if not hidden(stage,"card"..i) then return false end end
        for i=1,L.battlePotions.count do
            if not hidden(i<=3 and stage or potionHelp,"potion"..i)
                or not hidden(potionHelp,"potionHelp"..i) or not hidden(potionHelp,"potionCaption"..i) then return false end
        end
        return true
    end
    local stage=host.stage
    if not hiddenList(stage,emptyControls) then return false end
    local potionHelp=child(stage,"potionHelp")
    if not (potionHelp and hiddenList(potionHelp,potionButtons) and hiddenSlots(stage,potionHelp)) then return false end
    local energy=child(stage,"energyIcon")
    if not (energy and hidden(energy,"light")) then return false end
    for _,name in ipairs(pileIcons) do
        local icon=child(stage,name)
        if not (icon and hidden(icon,"hit")) then return false end
    end
    return true
end
local function installActivation(owner,host,dependencies)
    local revision,retiring,checking
    local function verifyHiddenProjection()
        checking=true
        local ok,result=pcall(hiddenNativeProjection,owner,host,revision)
        checking=nil
        if not ok then error(result,0) end
        return result
    end
    local function retireOrReuse(wasActive)
        if not wasActive and not checking and revision and owner.rewardRender==revision
            and hiddenProjectionUnowned(owner,host) and verifyHiddenProjection()
            and hiddenProjectionUnowned(owner,host) then return end
        revision=nil
        local expected=(owner.rewardRender or 0)+1
        local nested=retiring
        retiring=true
        local ok,reason=pcall(owner.render,owner)
        retiring=nested
        if not ok then error(reason,0) end
        if not nested and owner.rewardRender==expected and hiddenProjectionUnowned(owner,host) then revision=expected end
    end
    function owner:setActive(active,suspend,deferRender)
        assert(type(active) == "boolean", "active must be boolean")
        local wasActive=self.active
        self.active=active
        -- Only the host may request a temporary same-battle cover. Plain false still unmounts.
        self.suspendedBattle = not active and suspend == true and self.run and self.run.combat or nil
        if not active then self.help=nil;dependencies.cancelPotionAim("已取消药水瞄准。") end
        host.root:SetVisible(active)
        if deferRender then return end
        if active or self.run or not self.reuseRetiredProjection then
            revision=nil;self:render()
        else retireOrReuse(wasActive) end
    end
end
-- Explicit ports preserve the approved implementation without a shared constructor closure.
function M.install(owner, ownership, host, dependencies)
    installActivation(owner,host,dependencies)
    local R = L.rewardPick
    local function inputCovered()return host.options.inputCovered and host.options.inputCovered()end
    local function combatInputReady()
        return owner.active and not owner.busy and not owner.gesture and not owner.suppressClick
            and owner.run and owner.run.phase=='combat' and not inputCovered()
    end
    local function reconcileSelection()
        if owner.run and owner.run.phase == "combat" then
            local battle, found = owner.run.combat, false
            if not battle.enemies[owner.target] or not Actors.isActive(battle.enemies[owner.target]) then
                for i, enemy in ipairs(battle.enemies) do if Actors.isActive(enemy) then owner.target = i break end end
            end
            for _, card in ipairs(battle.hand) do if card.uid == owner.selected then found = true break end end
            if not found then owner.selected = nil end
        else owner.selected = nil end
    end
    local function refresh(changed, deferRender)
        reconcileSelection()
        if not deferRender then owner:render() end
        if changed and host.options.onChange then host.options.onChange(owner) end
    end
    local function perform(command, origin, clearPlayedSelection, commandContext)
        if inputCovered()then return false,'panel_hidden' end
        local battle = owner.run.combat
        local before, first = Events.frame(battle), #battle.events + 1
        owner.busy, owner.feedbackRun, owner.feedbackBattle = true, owner.run, battle
        owner.displayBattle = {catalog = battle.catalog, rules = battle.rules}
        for k, v in pairs(before) do owner.displayBattle[k] = v end
        local shown, failure = pcall(owner.render, owner)
        if not shown then
            owner.busy, owner.displayBattle = false, nil
            print("ABYSS_FEEDBACK prepare_failed " .. tostring(failure))
            pcall(refresh)
            return false, "presentation_unavailable"
        end
        local called, ok, reason = pcall(command)
        if not called or not ok then
            owner.busy, owner.displayBattle = false, nil
            if not called then
                print("ABYSS_FEEDBACK command_failed " .. tostring(ok) .. " turn=" .. tostring(battle.turn)
                    .. (commandContext or ""))
            end
            refresh()
            return false, called and reason or "command_failed"
        end
        if clearPlayedSelection then
            -- Publish UI-only selection before feedback's mandatory first frame;
            -- that frame can then serve as the post-command refresh as well.
            owner.selected=nil
            reconcileSelection()
        end
        -- No core callback is retained by playback. The committed result is immutable to it.
        owner.feedbackLast = #battle.events
        owner.feedback:setFastMode(owner.fastMode==true)
        owner.feedback:begin(before, battle, first, owner.presentation, origin, owner.run.phase == "reward")
        return ok, reason, clearPlayedSelection and feedbackPresented(owner,battle)
    end
    function owner:chooseCards(kind, uids, token, generation,battle)
        if self.busy or not self.run or self.run.phase~="combat" then return false, "not_in_combat" end
        local command = kind=="discard" and Run.chooseDiscard or kind=="scry" and Run.chooseScry
            or kind=="hand" and Run.chooseHand or kind=='pile' and Run.choosePile or kind=='potion'and Run.choosePotionStance
        if not command then return false, "invalid_choice_kind" end
        return perform(function() return command(self.run,uids,token,generation,battle) end)
    end
    local function helpContextChanged(help)
        local current = owner.run and owner.run.combat
        local actor = current and (help.spec.index == 0 and current.player or current.enemies[help.spec.index])
        return not owner.active or owner.busy or owner.run ~= help.run or current ~= help.battle
            or current.turn ~= help.turn or actor ~= help.actor or not Actors.isPresent(actor)
            or help.spec.screenSlot and not dependencies.sameEnemySlot(help.spec.screenSlot,actor,current)
            or help.spec.kind=='rewardCard' and not RewardOwner.ready(owner,help.spec)
    end
    local function helpPointerChanged(help)
        if owner.gesture and owner.gesture.moving then return true end
        local card=help.card
        return card and (card.input.held~=card or card.browsed or not dependencies.cardReady(card))
    end
    local function fireHelp(help, dt)
        help.t = help.t + dt
        if help.t + 0.000001 >= L.statusInfo.delay then
            help.fired = true
            if help.held and help.card then
                owner.gesture,owner.carry,owner.selected=nil,nil,nil
                dependencies.cancelCardInputs()
                owner.suppressClick=help.card
                owner.swallow={touch=help.touch}
                ownership.releasedDragTouch=help.touch
                help.spec.press=help.card
            end
            owner:openHelp(help.spec,help.source,not help.held or not help.card)
        end
    end
    local function updateHelp(dt)
        local help = owner.help
        if not help then return end
        if helpContextChanged(help) or helpPointerChanged(help) then owner.help = nil
        elseif help.spec.kind == "potion" and (owner.run.potions ~= help.spec.inventory
            or owner.run.potions[help.spec.slot] ~= help.spec.potionId) then owner.help = nil
        elseif not help.fired then fireHelp(help, dt) end
    end
    local function animateRewardCards(view, dt)
        local k, moving = 1 - math.exp(-R.ease * dt), false
        for i, anim in ipairs(view.cards) do
            local scale, lift = dependencies.rewardTarget(i)
            for key, goal in pairs({scale = scale, lift = lift, rise = 0}) do
                local gap = goal - anim[key]
                if math.abs(gap) > 0.002 then
                    anim[key] = math.abs(gap) < 0.05 and goal or anim[key] + gap * k
                    moving = true
                end
            end
        end
        return moving
    end
    local function updateRewardCards(dt)
        local view = owner.rewardView
        if view and owner.active and not owner.busy and owner.run and owner.run.phase == "reward" and view.rewards == owner.run.rewards then
            if animateRewardCards(view, dt) then owner:render(true) end
        end
    end
    function owner:update(dt)
        if self.gesture then self.gesture.elapsed = (self.gesture.elapsed or 0) + dt end
        if dependencies.updateCarry then dependencies.updateCarry() end
        if self.potionAim and not dependencies.aimReady(self.potionAim) then self:render() end
        updateHelp(dt)
        if self.feedbackRun and (self.feedbackRun ~= self.run or self.feedbackBattle ~= (self.run and self.run.combat)) then
            self.feedback:cancel()
            self.feedbackRun, self.feedbackBattle = nil, nil
            self:render() return
        end
        dependencies.updateEnemyIntents(dt)
        self.feedback:update(dt)
        if host.updateRewardBanner then host.updateRewardBanner(dt) end
        dependencies.updateEnemyNames(dt)
        updateRewardCards(dt)
        host.cardView.update(dt)
        local info=self.info
        if info and (info.kind=='card' or info.kind=='rewardCard') then
            if self:cardHelpReady(info) then host.renderInfo(info.battle,true)
            else self:render(true) end
        end
    end
    function owner:start()
        if not self.active or host.options.embedded or self.busy then return false end
        self.feedback:cancel()
        self.run = Run.new(self.data, self.seed)
        self.seed = (self.seed + 1) % 65536
        assert(Run.startCombat(self.run, "raven_adept_solo"))
        self.target, self.selected = 1, nil
        dependencies.notice("") refresh(true)
        print("ABYSS_UI combat_started")
    end
    function owner:playSelected(target)
        if not self.active or not self.selected or self.busy or self.gesture or not self.run or self.run.phase ~= "combat" then return end
        local uid, origin = self.selected, self.cardPositions[self.selected]
        local ok, reason, presented = perform(function() return Run.play(self.run, uid, target) end, origin,
            Theme.presentationProfile=='official-assets-first', " play uid=" .. tostring(uid) .. " target=" .. tostring(target))
        if ok then self.selected = nil end
        dependencies.notice(ok and "" or reasons[reason] or "当前无法使用这张牌。")
        if reason ~= "presentation_unavailable" and not presented then refresh() end
    end
    function owner:chooseCard(token,uid)
        if self.busy or not self.run or self.run.phase~="combat" then return false end
        local ok,reason=perform(function() return Run.chooseCard(self.run,token,uid) end)
        dependencies.notice(ok and "" or reasons[reason] or "这次选牌已失效。")
        refresh()
        return ok,reason
    end
    local function claimCard(index, run)
        if owner.rewardScreen ~= "cards" then return end
        local ok, reason = Run.claimCardReward(run, index)
        if ok then
            -- Adopt the committed rewards object before local feedback; an
            -- unrelated replacement still resets the page on the next render.
            owner.rewardOwner, owner.rewardRun = run.rewards, run
            dependencies.rewardScreen("list")
        end
        dependencies.notice(ok and "卡牌已加入牌组。" or reasons[reason] or "当前无法领取奖励。")
        refresh(ok)
    end
    local function selectCombatCard(index, run)
        dependencies.cancelPotionAim("已取消药水瞄准。")
        local instance = run.combat.hand[index]
        if not instance then return end
        owner.selectionEpoch = (owner.selectionEpoch or 0) + 1
        if owner.selected == instance.uid then owner.selected = nil dependencies.notice("") refresh() return end
        local ok, reason = Combat.canPlay(run.combat, instance.uid, owner.target)
        if not ok then dependencies.notice(reasons[reason] or "当前无法使用这张牌。") refresh() return end
        owner.selected = instance.uid
        dependencies.notice("")  -- STS 式：选牌只靠抬起/发光反馈，不显示任何教学字幕
        refresh()
    end
    function owner:playSlot(index)
        local run = self.run
        if inputCovered() or not self.active or not run or self.busy or self.gesture or self.suppressClick then return end
        if run.phase == "reward" then return claimCard(index, run)
        elseif run.phase == "combat" then return selectCombatCard(index, run) end
        refresh()
    end
    function owner:endTurn()
        if inputCovered() or not self.active or not self.run or self.busy or self.gesture or self.suppressClick or self.run.phase ~= "combat" or self.run.combat.phase ~= "player" then return end
        self.selected = nil
        perform(function() return Run.endTurn(self.run) end)
    end
    local function potionBinding(index)
        local binding = owner.potionSlots and owner.potionSlots[index]
        if not binding or owner.potionRun ~= owner.run or owner.potionBattle ~= owner.run.combat
            or owner.run.potions[binding.slot] ~= binding.id then return end
        return binding
    end
    local function beginPotionAim(binding, item)
        owner.selected = nil
        owner.selectionEpoch = (owner.selectionEpoch or 0) + 1
        dependencies.cancelCardInputs()
        dependencies.cancelActionInputs()
        local battle = owner.run.combat
        local aim = {run=owner.run,battle=battle,turn=battle.turn,inventory=owner.run.potions,
            slot=binding.slot,id=binding.id,actors={},living={}}
        for i, actor in ipairs(battle.enemies) do aim.actors[i],aim.living[i]=actor,Actors.isActive(actor) end
        owner.potionAim = aim
        dependencies.notice(item.name .. " · 对一名敌人：点击敌人使用；再点药水或空白取消；点说明查看效果。")
        refresh()
        return true
    end
    function owner:usePotion(index)
        if not combatInputReady() then return false end
        local binding = potionBinding(index)
        if not binding then return false end
        local item = selectedPotionView(self.run,binding.slot)
        if not item or not item.canUse then dependencies.notice(reasons[item and item.reason] or "当前无法使用此药水。") return false end
        local previous = self.potionAim
        dependencies.cancelPotionAim()
        if previous and previous.slot == binding.slot then dependencies.notice("已取消药水瞄准。") refresh() return true end
        if item.targetPolicy == "enemy_one" then return beginPotionAim(binding, item) end
        return self:commitPotion(binding.slot, nil)
    end
    local function potionTargetReady(slot, target)
        local aim = owner.potionAim
        return not target or aim and aim.slot == slot and dependencies.aimReady(aim)
    end
    function owner:commitPotion(slot, target)
        if not combatInputReady() then return false end
        if not potionTargetReady(slot, target) then
            dependencies.cancelPotionAim("药水瞄准已失效，已取消。") refresh() return false
        end
        dependencies.cancelPotionAim()
        local ok, reason = perform(function() return Run.usePotion(self.run, slot, target) end)
        if ok then
            self.potionSlots[slot] = nil
        end
        dependencies.notice(ok and "药水已生效。" or reasons[reason] or "当前无法使用此药水。")
        if reason ~= "presentation_unavailable" then refresh() end
        return ok, reason
    end
    local function potionRewardNotice(ok, reason, claim)
        if not ok then return reasons[reason] or "当前无法处理药水。" end
        if reason == "potion_blocked_by_sozu" then return "遗物阻止获得药水。" end
        return claim and "药水已放入背包。" or "已放弃药水。"
    end
    local function processPotionReward(claim)
        if not owner.active or not owner.run or owner.busy or owner.gesture or owner.suppressClick then return false end
        if owner.rewardScreen ~= "list" then return false end
        local ok,reason=(claim and Run.claimPotionReward or Run.skipPotionReward)(owner.run)
        dependencies.notice(potionRewardNotice(ok, reason, claim))
        refresh(ok)
        return ok,reason
    end
    function owner.claimPotionReward(_) return processPotionReward(true) end
    function owner.skipPotionReward(_) return processPotionReward(false) end
    return {
        refresh=refresh, perform=perform, helpContextChanged=helpContextChanged, helpPointerChanged=helpPointerChanged, fireHelp=fireHelp,
        updateHelp=updateHelp, animateRewardCards=animateRewardCards, updateRewardCards=updateRewardCards, claimCard=claimCard, selectCombatCard=selectCombatCard,
        potionBinding=potionBinding, beginPotionAim=beginPotionAim, potionTargetReady=potionTargetReady, potionRewardNotice=potionRewardNotice, processPotionReward=processPotionReward
    }
end
return M
