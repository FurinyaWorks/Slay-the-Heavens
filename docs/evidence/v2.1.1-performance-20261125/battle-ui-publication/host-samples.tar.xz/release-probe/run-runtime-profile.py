#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--rounds',type=int,default=3)
parser.add_argument('--modes',nargs='+',default=['bare','trace','profile'])
parser.add_argument('--amount',type=int,choices=[10,75],default=75)
parser.add_argument('--observer',type=Path,required=True)
parser.add_argument('--arm',action='append',required=True,help='label:checkout[:source_overlay]')
args = parser.parse_args()
source = Path(__file__).resolve().parent
out = args.out.resolve()
out.mkdir(parents=True,exist_ok=True)
items = [arm.split(':') for arm in args.arm]
matrix = [(arm,mode) for arm in items for mode in args.modes]
with (out/'runs.jsonl').open('x') as results:
    for iteration in range(args.rounds):
        # Deterministically rotate arm and instrumentation order each round.
        order = list(reversed(matrix)) if iteration%2 else matrix
        offset = (iteration//2) % len(order)
        for arm,mode in order[offset:] + order[:offset]:
            label,checkout,*overlay = arm
            file = out/f'{iteration+1:02}-{label}-{mode}.txt'
            environment = dict(os.environ, PROFILE_MODE=mode,PROFILE_DECK_AMOUNT=str(args.amount),
                               PROFILE_OBSERVER=str(args.observer.resolve()))
            if overlay:
                environment['PROFILE_SOURCE'] = str(Path(overlay[0]).resolve())
            started = time.monotonic()
            with file.open('x') as raw:
                try:
                    proc = subprocess.run(['texlua',str(source/'runtime-probe.lua')],cwd=checkout,env=environment,
                                         stdout=raw,stderr=subprocess.STDOUT,timeout=60,check=False)
                    status = proc.returncode
                except subprocess.TimeoutExpired:
                    status = 'TIMEOUT'
            content = file.read_text(errors='replace')
            row = {'arm':label,'mode':mode,'round':iteration+1,'file':file.name,'workloadDeckSize':args.amount,
                   'status':status,'complete':status==0 and '\nCOMPLETE\t' in content,
                   'elapsedWallSeconds':time.monotonic()-started}
            results.write(json.dumps(row)+'\n')
            results.flush()
            print(json.dumps(row),flush=True)
