// Offline reproduction of buildNativeCandidate's prepareBuild data/UI subprocesses only.
// No base map, toolchain, candidate packaging or client is used.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {nativeAudioBuildArgs} from '../../scripts/build-native-audio-game.mjs';
import {artFeatureBuildArgs,readArtFeatures} from '../../scripts/art-features.mjs';
import {sourceInputs,payloadDigest} from '../../scripts/build-native-candidate.mjs';
import {backgroundRuntimeInventory} from '../../scripts/official-background.mjs';
import {portraitRuntimeInventory} from '../../scripts/official-portraits.mjs';
const root=process.cwd(),out='.artifacts/native-inputs',base='62328bdac7703c3ab241e0ddb19e0fa05474f76a';
const path='art/characters/key-visual/traveler-geo/official-landscape-v1/preview-native.png';
const sha=b=>createHash('sha256').update(b).digest('hex');
const head=spawnSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).stdout.trim();assert.equal(head,base);
const pointer=spawnSync('git',['show',base+':'+path],{encoding:'utf8'}).stdout;
const original=readFileSync(path);assert.equal(original.length,81155);assert.equal(sha(original),'e23d1daac5e7046f9119edbd6179fd16fa31abd245c24d395adfd1af31a91a43');assert.equal(original.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
const opts=nativeAudioBuildArgs([]).options;assert.deepEqual(opts.artFeatures,{cards:false,menuBackground:true,selectionAvatar:true,battlePortrait:true,monsters:false});
const runs=[];
function run(label,script,args,expected=0){const r=spawnSync(process.execPath,[script,...args],{encoding:'utf8',timeout:60000,maxBuffer:4*1024*1024});writeFileSync(join(out,label+'.log'),JSON.stringify({command:[process.execPath,script,...args],status:r.status,error:r.error?.message})+'\n'+r.stdout+r.stderr);runs.push({label,command:['node',script,...args],status:r.status});assert.equal(r.status,expected,label+': '+r.stderr);return r;}
const uiArgs=dir=>[dir,...artFeatureBuildArgs(opts.artFeatures),'--work-key='+opts.workKey];
const before=sourceInputs(root,opts),beforeDigest=payloadDigest(before);assert(!before.some(r=>readFileSync(r.path).subarray(0,43).toString().startsWith('version https://git-lfs.github.com/spec/v1')));
try{
 writeFileSync(path,pointer);assert.match(run('negative-pointer','scripts/build-ui.mjs',uiArgs(join(out,'negative-pointer-build')),1).stderr,/Background budget data changed/);
 const corrupt=Buffer.from(original);corrupt[corrupt.length-1]^=1;writeFileSync(path,corrupt);assert.match(run('negative-byte-drift','scripts/build-ui.mjs',uiArgs(join(out,'negative-drift-build')),1).stderr,/Background budget data changed/);
}finally{writeFileSync(path,original);}
const dir=join(out,'final');mkdirSync(dir,{recursive:true});
run('final-build-data','scripts/build-lua-data.mjs',['data',join(dir,'abyss_data.lua')]);
run('final-build-ui','scripts/build-ui.mjs',uiArgs(dir));
assert.deepEqual(readArtFeatures(dir),opts.artFeatures);
const bg=backgroundRuntimeInventory(dir),portraits=portraitRuntimeInventory(dir);assert.equal(bg.sourcePreviewSha256,sha(original));assert.equal(bg.renderProfile,'background-budget-v1');assert.equal(bg.images,4500);
const after=sourceInputs(root,opts);assert.equal(payloadDigest(after),beforeDigest);assert.equal(sha(readFileSync(path)),sha(original));
const outputs=readdirSync(dir,{withFileTypes:true}).filter(x=>x.isFile()).map(x=>{const p=join(dir,x.name),b=readFileSync(p);return{path:x.name,bytes:b.length,sha256:sha(b)};});
const receipt={schemaVersion:1,sourceCommit:base,sourceTree:spawnSync('git',['rev-parse',base+'^{tree}'],{encoding:'utf8'}).stdout.trim(),scope:'native default input generation only; not packaging/client/official import',defaultOptions:opts,sourceInputCount:before.length,sourcePayloadDigest:beforeDigest,pointerMaterializationOnly:true,allSelectedSourceInputsMaterialized:true,runs,background:bg,portraits,generatedOutputs:outputs,inputRecords:after,notRun:['GIL or candidate write/readback','native toolchain','official import/ready','client or GUI','device performance/capacity','Full/Hosted CI','release']};
writeFileSync(join(out,'preflight-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({sourceCommit:base,sourceInputCount:before.length,sourcePayloadDigest:beforeDigest,runs,generatedOutputCount:outputs.length,background:bg},null,2));
