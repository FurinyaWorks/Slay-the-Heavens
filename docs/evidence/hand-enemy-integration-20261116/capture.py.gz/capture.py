from pathlib import Path
import subprocess,json,gzip,hashlib,re
H='e259ca49be9d2e3b3526a5efa762814ef96df1c9'; E='4d40bdac703c80e51054d551f1512ff02fc0adbc';views=dict(hand=H,enemy=E)
git=lambda *a:subprocess.check_output(['git',*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
def record(raw):
 b=raw.decode().replace('\r\n','\n').encode();return dict(source=b.decode(),sha256=sha(b),gitBlob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def inventory(paths):return dict(js=sorted(p for p in paths if re.fullmatch(r'tests/[^/]+\.test\.mjs',p)),lua=sorted(p for p in paths if re.fullmatch(r'tests/lua/[^/]+\.lua',p)))
# Update only fresh helper identities, never historical descriptors.
f=Path('tests/helpers/copy-integration-source-closure.mjs');s=f.read_text();m=re.search(r'export const handEnemyHelperCopies=(\[.*?\]);',s);rows=json.loads(m[1]);
for row in rows:row['after']=sha(Path(row['path']).read_bytes())
f.write_text(s[:m.start(1)]+json.dumps(rows,separators=(',',':'))+s[m.end(1):])
files={n:set(git('ls-tree','-r','--name-only',c).decode().splitlines())for n,c in views.items()}
changed=set().union(*(set(git('diff','--name-only',c).decode().splitlines())for c in views.values()))
changed|={p.as_posix()for p in Path('tests/helpers').glob('hand-enemy*.mjs')}
changed|={p.as_posix()for p in Path('tests').glob('hand-enemy*.mjs')}
changed|={'src/lua/abyss_battle_card_view.lua','src/lua/abyss_battle_enemy_view.lua','src/lua/abyss_battle_render_actors.lua','src/lua/abyss_battle_targeting.lua'}
changed={p for p in changed if p.startswith(('src/','tests/','scripts/','config/','.github/'))and not p.endswith('.gz')};changed.discard('tests/helpers/hand-enemy-ci-source.mjs')
p=dict(schemaVersion=1,normalization='LF',viewCommits=views,productCommit=Path('.artifacts/hand-enemy-union/product.txt').read_text().strip(),currentTreeCommitted=False,viewInventories={n:inventory(f)for n,f in files.items()},currentInventory=inventory([f.as_posix()for f in Path('tests').rglob('*')if f.is_file()]),files={},immutableArchives={})
p['viewBlobInventories']={n:{line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in git('ls-tree','-r',c).decode().splitlines() if line.split('\t',1)[1].startswith(('src/','tests/','scripts/','config/','.github/'))} for n,c in views.items()}
for path in sorted(changed):p['files'][path]=dict(current=record(Path(path).read_bytes()),views={n:record(git('show',c+':'+path))if path in files[n]else None for n,c in views.items()})
for path in Path('tests/helpers').rglob('*.gz'):
 if path.name!='hand-enemy-ci-source.json.gz':p['immutableArchives'][path.as_posix()]=sha(path.read_bytes())
data=gzip.compress((json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0);Path('tests/helpers/hand-enemy-ci-source.json.gz').write_bytes(data)
leaf=Path('tests/helpers/hand-enemy-ci-source.mjs');s=leaf.read_text();s=re.sub(r"assert.equal\(hash\(bytes\),'[^']+'", "assert.equal(hash(bytes),'"+sha(data)+"'",s);leaf.write_text(s)
print(len(p['files']),len(p['immutableArchives']))
