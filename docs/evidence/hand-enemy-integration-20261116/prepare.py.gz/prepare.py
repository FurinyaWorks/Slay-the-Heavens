from pathlib import Path
import subprocess,re,json,gzip,hashlib,os,tempfile
H='e259ca49be9d2e3b3526a5efa762814ef96df1c9'; E='4d40bdac703c80e51054d551f1512ff02fc0adbc'
git=lambda *a,**kw:subprocess.check_output(['git',*a],**kw)
sha=lambda b:hashlib.sha256(b).hexdigest()
for p in git('diff','--name-only','--diff-filter=U').decode().splitlines():
 if p.startswith('tests/'):Path(p).write_bytes(git('show',H+':'+p))
# Real committed production union, exact four independent production files.
idx=tempfile.mktemp();env={**os.environ,'GIT_INDEX_FILE':idx};git('read-tree',H,env=env)
paths=['src/lua/abyss_battle_enemy_view.lua','src/lua/abyss_battle_render_actors.lua','src/lua/abyss_battle_targeting.lua']
for p in paths:git('update-index','--add','--cacheinfo','100644',git('rev-parse',E+':'+p).decode().strip(),p,env=env)
tree=git('write-tree',env=env).decode().strip();product=git('commit-tree',tree,'-p',H,'-p',E,input=b'fix(ui): preserve hand and enemy production union identity\n').decode().strip();os.unlink(idx)
Path('.artifacts/hand-enemy-union/product.txt').write_text(product+'\n')
p='tests/helpers/closeout-source-epoch.mjs';s=Path(p).read_text();s=s.replace("import {extendHandPost697Source}","import {extendEnemyGeometrySource} from './enemy-geometry-source.mjs';\nimport {extendEnemyPost697Source} from './enemy-post697-source.mjs';\nimport {extendHandEnemyUnion} from './hand-enemy-source.mjs';\nimport {extendHandPost697Source}")
s=s.replace('export const sourceEpoch=extendHandPost697Source(preHandPost697SourceEpoch,handBeforeMapSourceEpoch);', '''export const handPost697SourceEpoch=extendHandPost697Source(preHandPost697SourceEpoch,handBeforeMapSourceEpoch);
export const preEnemyGeometrySourceEpoch=preReleaseSelectionMapSourceEpoch;
export const preEnemyPost697SourceEpoch=extendEnemyGeometrySource(preEnemyGeometrySourceEpoch);
export const releaseSelectionMapLegacyEpoch=preHandPost697SourceEpoch;
export const enemyPost697SourceEpoch=extendEnemyPost697Source(preEnemyPost697SourceEpoch,releaseSelectionMapLegacyEpoch);
export const sourceEpoch=extendHandEnemyUnion(handPost697SourceEpoch,enemyPost697SourceEpoch);''');Path(p).write_text(s)
code='''// Exact committed union; both independent predecessor domains remain intact.
import assert from 'node:assert/strict';
import {createSourceEpochProjector} from './combined-epoch/source-epoch-runtime.mjs';
export function extendHandEnemyUnion(hand,enemy){
 const h=hand.proof,e=enemy.proof,current={...h.current};
 const changed=ENEMY_PATHS;
 for(const path of changed){assert(e.current[path]);current[path]=e.current[path];}
 for(const path of Object.keys(current))if(!changed.includes(path)&&path!=='src/lua/abyss_battle_card_view.lua')assert.deepEqual(h.current[path],e.current[path],'unchanged union production: '+path);
 const targets={...h.targets};
 for(const [name,target]of Object.entries(e.targets)){if(Object.hasOwn(targets,name))assert.deepEqual(targets[name],target,'shared historical domain: '+name);else targets[name]=target;}
 targets.handBeforeEnemyUnion={commit:HAND,files:h.current};targets.enemyBeforeHandUnion={commit:ENEMY,files:e.current};
 const owners=Object.keys(current).sort().filter(path=>Object.values(targets).some(target=>target.files[path]?.sha256!==current[path]?.sha256));
 const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
 return createSourceEpochProjector(freeze({...h,current,targets,owners,currentCommit:PRODUCT,currentTreeCommitted:true,currentCommitRole:'actual committed hand/enemy union; no device acceptance',enemyGeometryProducers:e.enemyGeometryProducers,enemyPost697Producers:e.enemyPost697Producers}),{allowConfigLayout:true,reuseFrozenInput:true});
}
'''.replace('ENEMY_PATHS',json.dumps(paths)).replace('HAND',json.dumps(H)).replace('ENEMY',json.dumps(E)).replace('PRODUCT',json.dumps(product))
Path('tests/helpers/hand-enemy-source.mjs').write_text(code)
# Copy closure keeps hand history, adds all enemy immutable source leaves and new union.
p='tests/helpers/copy-integration-source-closure.mjs';s=Path(p).read_text();ec=git('show',E+':'+p).decode();m=re.search(r'export const enemyGeometryHelperCopies=\[.*?\n\];',ec,re.S)[0];m2=re.search(r'export const enemyPost697HelperCopies=\[.*?\];',ec,re.S)[0]
rows=[]
for name in ['tests/helpers/closeout-source-epoch.mjs','tests/helpers/enemy-geometry-source.mjs','tests/helpers/enemy-geometry-source.json.gz','tests/helpers/enemy-post697-source.mjs','tests/helpers/enemy-post697-source.json.gz','tests/helpers/hand-enemy-source.mjs']:
 rows.append(dict(path=name,before=sha(git('show',H+':'+name))if name.endswith('closeout-source-epoch.mjs')else None,after=sha(Path(name).read_bytes())))
s=s.replace('const inside=(root,path)=>',m+'\n'+m2+'\nexport const handEnemyHelperCopies='+json.dumps(rows,separators=(',',':'))+";\nfor(const row of handEnemyHelperCopies){assert.equal(files[row.path]??null,row.before,'exact hand enemy copy predecessor: '+row.path);files[row.path]=row.after;}\nconst inside=(root,path)=>");Path(p).write_text(s)
print(product)
