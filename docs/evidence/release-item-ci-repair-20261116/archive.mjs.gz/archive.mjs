import{readFileSync,writeFileSync,readdirSync,mkdirSync}from'node:fs';import{gzipSync}from'node:zlib';import{createHash}from'node:crypto';
const here='.artifacts/ci699-repair',out='docs/evidence/release-item-ci-repair-20261116';mkdirSync(out,{recursive:true});const hash=b=>createHash('sha256').update(b).digest('hex'),manifest=[];
function save(name,raw,source){const compressed=gzipSync(raw);writeFileSync(out+'/'+name+'.gz',compressed);manifest.push({path:name+'.gz',source,rawBytes:raw.length,rawSha256:hash(raw),bytes:compressed.length,sha256:hash(compressed)});}
for(const file of readdirSync(here)){
 if(/^raw-job-\d+\.json$/.test(file)){const p=JSON.parse(readFileSync(here+'/'+file));save('job-'+p.jobId+'.log',Buffer.from(p.content),p.source);}
 else if(file.endsWith('.log')&&!/^job-\d/.test(file))save(file,readFileSync(here+'/'+file),'local bounded verification stdout/stderr');
}
for(const [id,file]of [[132976717778,'pr699-rules2-failed.log'],[132976717719,'pr699-job-132976717719.log'],[132976717949,'pr699-job-132976717949-retry.log']])save('job-'+id+'.log',readFileSync('F:/New folder/.artifacts/'+file),'gh api completed job logs');
for(const file of ['capture.mjs','archive.mjs','warm-red.mjs'])save(file,readFileSync(here+'/'+file),'local collector or exact historical RED probe');
writeFileSync(out+'/archive-manifest.json',JSON.stringify(manifest,null,2)+'\n');writeFileSync(out+'/capture.json',readFileSync(here+'/capture.json'));
console.log('ARCHIVED',manifest.length,manifest.reduce((n,r)=>n+r.bytes,0));
