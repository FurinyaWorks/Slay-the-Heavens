local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Theme,Run,View=require('abyss_theme'),require('abyss_run'),require('abyss_game_ui_navigation_view')
local cursor={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='endDrag'}
local geometry=0
local function checkGeometry(menu)
 local face=menu:GetChild('face')
 local names={'title','resume','map','mainMenu','rule','abandon','quit','dismissHint'}
 for _,name in ipairs(names)do local c=menu:GetChild(name)
  if c.visible~=false then
   local declared=Theme.layout.runMenu[name]
   local x,y=c.x or declared[1],c.y or declared[2]
   assert(math.abs(x-face.x)+c.sizeDeltaX/2<=face.sizeDeltaX/2+.01,'outside menu x '..name)
   assert(math.abs(y-face.y)+c.sizeDeltaY/2<=face.sizeDeltaY/2+.01,'outside menu y '..name)
  end
 end
 for i=1,#names do for j=i+1,#names do local a,b=menu:GetChild(names[i]),menu:GetChild(names[j])
  if a.visible~=false and b.visible~=false then
   local A,B=Theme.layout.runMenu[names[i]],Theme.layout.runMenu[names[j]]
   assert(math.abs((a.x or A[1])-(b.x or B[1]))>=(a.sizeDeltaX+b.sizeDeltaX)/2 or math.abs((a.y or A[2])-(b.y or B[2]))>=(a.sizeDeltaY+b.sizeDeltaY)/2,'overlap '..names[i]..'/'..names[j])
  end
 end end
end
local calls=0
for _,touch in ipairs({false,true})do
 local focus
 local api={events={Confirm='confirm',Cancel='cancel',Focus='focus'},directions={Left='left',Right='right'},modes={Specified='specified'},getFocus=function()return focus end,setFocus=function(c)focus=c end,isController=function()return true end}
 local ui,root=F.fixture(nil,function()calls=calls+1;return true end,nil,cursor,false,nil,{touchScreen=function()return touch end},api)
 local menu=root:GetChild('runMenu')
 for _,route in ipairs({false,true})do for _,active in ipairs({false,true})do for _,paused in ipairs({false,true})do
  View.runMenu({run=active and {phase='map'}or nil,sessionPaused=paused},menu,route)
  checkGeometry(menu);geometry=geometry+1
 end end end
 assert(F.start(ui));assert(Run.startCombat(ui.run,'cultist_solo'));ui:refresh();assert(ui.mode=='battle')
 local run,map,battle=ui.run,ui.map,ui.run.combat
 local copy=F.Combat.copy(run)
 local function equal(a,b)
  if type(a)~=type(b)then return false end
  if type(a)~='table'then return a==b end
  for k,v in pairs(a)do if not equal(v,b[k])then return false end end
  for k in pairs(b)do if a[k]==nil then return false end end
  return true
 end
 assert(ui:openMenu());ui:update(0);ui:syncController()
 local mapHit=menu:GetChild('map'):GetChild('hit')
 local official=Theme.presentationProfile=='official-assets-first'
 if official then
  assert(not menu:GetChild('map').visible and not mapHit.raycastTarget and not mapHit.interactable)
  assert(not mapHit.click and not ui.controller.byControl[mapHit],'hidden duplicate remains executable')
  assert(not mapHit.canControllerFocus,'hidden duplicate remains focusable')
  focus=menu:GetChild('resume'):GetChild('hit');assert(focus.navigationListeners.confirm())
 end
 local routeControl=official and root:GetChild('battlePanel'):GetChild('topBar'):GetChild('battleRoute'):GetChild('hit')or mapHit
 if not routeControl then error('no route control')end
 ui:update(0);ui:syncController();assert(routeControl.canControllerFocus,'C route action not focusable')
 -- A pointer release captured before menu-context retirement must not be reused.
 routeControl.listeners.down({touchId=71});routeControl.listeners.up({touchId=71})
 if official then assert(ui:openMenu() and ui:closeExit())else assert(ui:closeExit() and ui:openMenu())end
 assert(not routeControl.click({touchId=71}),'stale route pointer survived a newer menu generation')
 ui:update(0);ui:syncController();focus=routeControl
 assert(routeControl.navigationListeners.confirm()and ui.routeOpen,'C route activation failed')
 ui:update(0);ui:syncController()
 assert(not routeControl.navigationListeners.confirm(),'old controller route callback remains active in route overlay')
 local back=root:GetChild('mapPanel'):GetChild('previewBack');back=back:GetChild('hit')or back
 assert(back.canControllerFocus,'C route back not focusable');focus=back
 assert(back.navigationListeners.confirm())
 assert(not ui.exitOpen and not ui.menuOpen and not ui.routeOpen and ui.mode=='battle')
 assert(ui.run==run and ui.map==map and run.combat==battle and equal(run,copy)and calls==0,'route changed live run or submitted settlement')
 ui:disable()
end
print('NAVIGATION_INDEPENDENT_PASS geometry='..geometry..' controller_routes=2 stale_pointer=2 stale_controller=2')
