import {mkdirSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
const cwd='F:/New folder/.worktrees/release-pc-navigation-1115',root='F:/New folder/.artifacts/release-pc-qa-20261115';
const {buildUI}=await import(pathToFileURL(cwd+'/scripts/build-ui.mjs')),{buildLuaData}=await import(pathToFileURL(cwd+'/scripts/build-lua-data.mjs'));
const require=createRequire(pathToFileURL(cwd+'/package.json'));
const results=[];
for(const officialAssets of [false,true]){
 const dir=root+'/navigation-review-'+(officialAssets?'official':'default');mkdirSync(dir,{recursive:true});
 buildLuaData(cwd+'/data',dir+'/abyss_data.lua');buildUI(dir,undefined,{officialAssets});
 const r=spawnSync(process.execPath,[require.resolve('fengari-node-cli/src/lua-cli.js'),'-e',`dofile('${root}/navigation-independent-probe.lua')`],{cwd,encoding:'utf8',timeout:60000,maxBuffer:1024*1024,windowsHide:true,env:{...process.env,LUA_PATH:dir+'/?.lua;./src/lua/?.lua;;',LUA_INIT:'',LUA_INIT_5_3:''}});
 const result={officialAssets,node:process.version,status:r.status,stdout:r.stdout,stderr:r.stderr,error:String(r.error??'')};results.push(result);
 writeFileSync(root+'/navigation-independent-'+(officialAssets?'official':'default')+'.log',r.stdout+r.stderr+String(r.error??''));
}
writeFileSync(root+'/navigation-independent-results.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
