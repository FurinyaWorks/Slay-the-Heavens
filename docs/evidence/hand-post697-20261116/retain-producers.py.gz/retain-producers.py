from pathlib import Path
import hashlib,json,re
p=Path('tests/helpers/hand-post697-source.mjs');s=p.read_text(encoding='utf8');old=hashlib.sha256(p.read_bytes()).hexdigest();a="return createSourceEpochProjector(freeze({...prior,current,targets,owners,currentCommit:";b="return createSourceEpochProjector(freeze({...prior,current,targets,owners,mobileHandProducers:hand.mobileHandProducers,currentCommit:";assert s.count(a)==1;p.write_text(s.replace(a,b),encoding='utf8',newline='\n');new=hashlib.sha256(p.read_bytes()).hexdigest()
p=Path('tests/helpers/copy-integration-source-closure.mjs');s=p.read_text(encoding='utf8');assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf8',newline='\n')
p=Path('.artifacts/hand-post697/prepare.py');s=p.read_text(encoding='utf8');assert s.count(a)==1;p.write_text(s.replace(a,b),encoding='utf8',newline='\n')
p=Path('tests/integrated-ci-source.cases.mjs');s=p.read_text(encoding='utf8');a=" const current=sourceEpoch.proof,prior=preHandPost697SourceEpoch.proof,hand=handBeforeMapSourceEpoch.proof;";assert s.count(a)==1;p.write_text(s.replace(a,a+"\n assert.deepEqual(current.mobileHandProducers,hand.mobileHandProducers);assert.deepEqual(current.releaseSelectionMapProducers,prior.releaseSelectionMapProducers);"),encoding='utf8',newline='\n')
print(json.dumps(dict(oldHelperHash=old,newHelperHash=new)))
