from pathlib import Path
import re,subprocess,json
root=Path('.artifacts/hand-post697')
# Resolve the actual metadata conflict hunks into landed Map current domain,
# retaining the hand-specific history imports, tests and descriptors explicitly.
pat=re.compile(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> 33d71575c5f186a1b54f7bf3e4f1826c145aa1d9\n',re.S)
seen={}
for p in subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines():
 s=Path(p).read_text(encoding='utf8');i=0
 def resolve(m):
  global i
  left,right=m.groups();i+=1
  if p=='tests/helpers/closeout-source-epoch.mjs':
   if i==1:return left+right
   return "export const preReleaseSelectionMapSourceEpoch=extendSessionMenuEpoch(releaseSourceEpoch);\nexport const preMobileHandSourceEpoch=preReleaseSelectionMapSourceEpoch;\nexport const handBeforeMapSourceEpoch=extendMobileHandSource(preMobileHandSourceEpoch);\nexport const sourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);\n"
  if p=='tests/helpers/copy-integration-source-closure.mjs':
   descriptor=left[:left.index('for(const row of mobileHandHelperCopies)')]
   return descriptor+right+"// The original hand descriptor remains an immutable historical domain.\n// Current copies retain both production leaves; outer union owns closeout.\nfor(const row of mobileHandHelperCopies.filter(row=>!row.path.endsWith('closeout-source-epoch.mjs'))){assert.equal(files[row.path]??null,row.before,'exact hand leaf copy predecessor: '+row.path);files[row.path]=row.after;}\n"
  if p=='tests/helpers/integrated-ci-source.mjs':return left+right if i==1 else right
  if p=='tests/ci-complete-calibration.test.mjs':
   if i==1:return right+"import {readFileSync as actualHandReadFileSync} from 'node:fs';\nimport {mobileHandCiRead,mobileHandCiPacket,mobileHandPriorInventory,assertMobileHandCiCurrent,assertMobileHandRawInventory} from './helpers/mobile-hand-ci-source.mjs';\n"
   return right
  if p=='tests/integrated-ci-source.cases.mjs':
   if i==1:return right+"import {readFileSync as actualHandReadFileSync} from 'node:fs';\nimport {mobileHandCiRead,mobileHandCiPacket,mobileHandCiSource,mobileHandPriorInventory,assertMobileHandCiCurrent,assertMobileHandRawInventory} from './helpers/mobile-hand-ci-source.mjs';\n"
   return right
  if p=='tests/integration-source-epoch.test.mjs':return right+" const {preMobileHandSourceEpoch}=await import('./helpers/closeout-source-epoch.mjs');\n assert.equal(preMobileHandSourceEpoch.proof.currentTreeCommitted,false,'hand and landed Map share the complete original predecessor');\n"
  if p=='tests/sts-style-source-epoch.test.mjs':
   if i==1:return left+right
   # Historical hand assertions are kept as a separate explicit domain; the
   # following landed Map assertions remain independent and unchanged.
   return " {\n"+left.replace('currentRaw','handDomainRaw')+" }\n"+right
  raise AssertionError(p)
 s,n=pat.subn(resolve,s);assert n and '<<<<<<<'not in s,(p,n);Path(p).write_text(s,encoding='utf8',newline='\n');seen[p]=n
root.joinpath('conflict-resolution.json').write_text(json.dumps(seen,indent=2)+'\n')
print(json.dumps(seen))
