from pathlib import Path
import gzip,hashlib,json
root=Path('.artifacts/hand-post697');out=Path('docs/evidence/hand-post697-20261116');out.mkdir(parents=True,exist_ok=True);rows=[]
for p in sorted(root.iterdir()):
 if not p.is_file()or p.suffix not in ['.log','.mjs','.py','.lua','.json']:continue
 raw=p.read_bytes();body=gzip.compress(raw,mtime=0);name=p.name+'.gz';(out/name).write_bytes(body);rows.append(dict(path=name,source=p.as_posix(),rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),gitStoredBytes=len(body),gitStoredSha256=hashlib.sha256(body).hexdigest()))
(out/'archive-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(dict(evidence=len(rows),storedBytes=sum(r['gitStoredBytes']for r in rows))))
