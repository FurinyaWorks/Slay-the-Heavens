from pathlib import Path
import subprocess,json,re,hashlib
p=Path('tests/integrated-ci-source.cases.mjs');s=p.read_text(encoding='utf8');a='}),/fresh mobile hand added inventory source/);';assert s.count(a)==1;s=s.replace(a,"}),error=>{assert.match(error.message,/fresh (?:mobile hand added inventory source|complete integration source: mobile hand)/);assert(error.message.includes(path),'reject the intended added source');return true;});");p.write_text(s,encoding='utf8',newline='\n')
p=Path('tests/release-selection-map-source.test.mjs');s=p.read_text(encoding='utf8');assert s.count('./helpers/shop-post697-ci-source.mjs')==1;p.write_text(s.replace('./helpers/shop-post697-ci-source.mjs','./helpers/hand-post697-ci-source.mjs'),encoding='utf8',newline='\n')
p=Path('.artifacts/hand-post697/consumers.py');s=p.read_text(encoding='utf8');s=s.replace(".replace('activeShop','activeHand');exec(block)",".replace('activeShop','activeHand').replace('shop-post697','hand-post697');exec(block)");p.write_text(s,encoding='utf8',newline='\n')
p=Path('tests/sts-style-source-epoch.test.mjs');s=p.read_text(encoding='utf8');s=s.replace('handPost697HistoricalRead,assertHandPost697RawInventory}', 'handPost697HistoricalRead,assertHandPost697RawInventory,handPost697CiPacket}')
a=" assertHandPost697RawInventory(currentJs,'js');assertHandPost697RawInventory(currentLua,'lua');";assert s.count(a)==1;s=s.replace(a,a+"""
 // These are the actual filesystem bytes, before either history is entered.
 for(const [kind,paths]of [['js',currentJs],['lua',currentLua]])for(const target of ['release','hand']){
  for(const added of paths.filter(path=>!handPost697CiPacket.viewInventories[target][kind].includes(path))){
   for(const failure of ['missing','null','drift'])assert.throws(()=>handPost697PriorInventory(paths,kind,(path,encoding)=>{
    if(path===added){if(failure==='missing')throw Error('missing '+path);if(failure==='null')return null;const b=readFileSync(path,encoding);return typeof b==='string'?b+'\\n':Buffer.concat([b,Buffer.from('\\n')]);}
    return readFileSync(path,encoding);
   },target),error=>{assert(error.message.includes(added)||/null/.test(error.message));return true;});
  }
 }
""");p.write_text(s,encoding='utf8',newline='\n')
# Materialize only the two immutable official portrait inputs needed by the
# existing generated-Host builder; each must match its real Git LFS pointer.
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir']).decode().strip()).resolve();paths=['art/characters/traveler-geo/portraits/avatar96/preview-native-1x.png','art/characters/traveler-geo/portraits/battle133/preview-native-1x.png'];rows=[]
for path in paths:
 p=Path(path);raw=p.read_bytes();text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1]);body=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes();assert len(body)==size and hashlib.sha256(body).hexdigest()==oid;p.write_bytes(body);rows.append(dict(path=path,oid=oid,size=size))
Path('.artifacts/hand-post697/media-inputs.json').write_text(json.dumps(rows,indent=2)+'\n');print('Corrected consumer wiring and error-target specificity; materialized two exact media inputs')
