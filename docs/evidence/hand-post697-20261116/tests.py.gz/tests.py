from pathlib import Path
blocks=Path('.artifacts/hand-post697/ci-tests-template.mjs').read_text(encoding='utf8')
blocks=blocks.replace('shopPost697','handPost697').replace('ShopPost697','HandPost697').replace('shop-post697','hand-post697').replace('shop post697 union','hand post697 union').replace('actualShopPost697','actualHandPost697').replace("['release','shop']","['release','hand']").replace('src/lua/abyss_shop_selection.lua','src/lua/abyss_battle_card_view.lua')
blocks+="""
test('hand post697 union complete current production authenticates every one of 116 owners',async()=>{
 const {sourceEpoch,preHandPost697SourceEpoch,handBeforeMapSourceEpoch}=await import('./helpers/closeout-source-epoch.mjs');
 const {handPost697SourcePacket:p,extendHandPost697Source}=await import('./helpers/hand-post697-source.mjs');
 const current=sourceEpoch.proof,prior=preHandPost697SourceEpoch.proof,hand=handBeforeMapSourceEpoch.proof;
 assert.equal(current.currentCommit,'d956df3e8b429ad4d4042d9489108000fb9b327b');assert.equal(current.currentTreeCommitted,true);
 assert.equal(prior.owners.length,116);assert.equal(current.owners.length,116);assert.deepEqual(current.owners,prior.owners);
 for(const [name,target]of Object.entries(prior.targets))assert.deepEqual(current.targets[name],target,name);
 for(const [name,target]of Object.entries(hand.targets))assert.deepEqual(current.targets[name],target,name);
 assert.deepEqual(current.targets.handPost697Release,{commit:p.baseCommit,files:prior.current});
 assert.deepEqual(current.targets.handBeforeMap,{commit:p.handCommit,files:hand.current});
 assert.equal(Object.values(current.current).filter(Boolean).length,352);
 for(const [path,row]of Object.entries(current.current))if(row)assert.equal(actualHandPost697ReadFileSync(path,'utf8').replaceAll('\\r\\n','\\n'),row.source,path);
 for(const bad of [{...p,current:{}},{...p,before:{}},{...p,handBeforeMap:{}},{...p,currentTreeCommitted:false},{...p,currentCommit:'0'.repeat(40)}])assert.throws(()=>extendHandPost697Source(preHandPost697SourceEpoch,handBeforeMapSourceEpoch,bad));
 const anchor=Object.keys(p.current)[0],source=current.current[anchor].source,expected=prior.current[anchor].source;
 for(const crlf of [false,true]){
  let fault;const seen=[];
  const read=path=>{seen.push(path);if(path===fault?.path&&fault.missing)return null;const text=actualHandPost697ReadFileSync(path,'utf8').replaceAll('\\r\\n','\\n');return path===fault?.path?text+'\\n':crlf?text.replaceAll('\\n','\\r\\n'):text;};
  for(const path of current.owners){
   seen.length=0;assert.equal(sourceEpoch.preCombinedSource(anchor,source,{target:'handPost697Release',readSource:read}),expected);assert.deepEqual(seen,current.owners);
   for(const missing of [false,true]){fault={path,missing};assert.throws(()=>sourceEpoch.preCombinedSource(anchor,source,{target:'handPost697Release',readSource:read}),/linked owner identity/);}
   fault=undefined;assert.equal(sourceEpoch.preCombinedSource(anchor,source,{target:'handPost697Release',readSource:read}),expected);
  }
 }
});
"""
p=Path('tests/integrated-ci-source.cases.mjs');p.write_text(p.read_text(encoding='utf8').rstrip()+'\n\n'+blocks,encoding='utf8',newline='\n')
p=Path('tests/ci-complete-calibration.test.mjs');s=p.read_text(encoding='utf8');start=s.index("test('hand composition raw Full retains");raw=s[start:]
raw=raw.replace('hand composition raw Full retains complete discovery costs and real execution guards','hand post697 union raw Full retains complete actual discovery and physical execution guards').replace('assertMobileHandCiCurrent(actualHandReadFileSync);','assertHandPost697CiCurrent(actualHandPost697ReadFileSync);').replace('const js=actualHandDiscoverJs(),lua=handLegacyLua();',"const js=actualHandPost697DiscoverJs(),lua=readdirSync('tests/lua').filter(n=>n.endsWith('.lua')).map(n=>'tests/lua/'+n).sort();").replace('assertMobileHandRawInventory','assertHandPost697RawInventory').replace("actualHandReadFileSync('.github/", "actualHandPost697ReadFileSync('.github/").replace('mobileHandCiPacket.priorInventory.js','handPost697CiPacket.viewInventories.release.js')
s=s.replace("import {handPost697HistoricalRead,handPost697PriorInventory}","import {handPost697HistoricalRead,handPost697PriorInventory,handPost697CiPacket,assertHandPost697CiCurrent,assertHandPost697RawInventory}")
p.write_text(s.rstrip()+'\n\n'+raw,encoding='utf8',newline='\n')
print('Added bounded current union source/read/raw authorizations without new root entries')
