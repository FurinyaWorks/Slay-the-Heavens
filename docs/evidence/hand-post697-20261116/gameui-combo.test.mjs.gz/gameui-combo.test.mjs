import test from 'node:test';
import assert from 'node:assert/strict';
import {gameLayout} from '../../scripts/game-ui-layout.mjs';
import {nativeTheme} from '../../scripts/native-ui-theme.mjs';
import {applyOfficialAssets,officialAssetsTheme} from '../../scripts/official-assets-layout.mjs';
import {buildUI} from '../../scripts/build-ui.mjs';
import {buildLuaData,luaString} from '../../scripts/build-lua-data.mjs';
import {mkdtempSync,readdirSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
const parts=n=>n?.children??n?.controls??[];
const child=(n,name)=>parts(n).find(c=>c.name===name);
const all=n=>[n,...parts(n).flatMap(all)];
test('generated official Host composes hand values with read-only landed Map return',t=>{
 const directory=mkdtempSync(join(tmpdir(),'pc08-host-'));
 t.after(()=>rmSync(directory,{recursive:true,force:true}));
 buildLuaData('data',join(directory,'abyss_data.lua'));
 buildUI(directory,undefined,{officialAssets:true,nativePageLifecycle:true});
 const preloads=readdirSync(directory).filter(n=>n.endsWith('.lua')).map(n=>
  `package.preload[${luaString(n.slice(0,-4))}]=assert(loadfile(${luaString(join(directory,n).replaceAll('\\','/'))}))`).join('\n');
 const source=`package.path='./src/lua/?.lua;./build/lua/?.lua'\n${preloads}
local GameUI=require('abyss_game_ui');local create=GameUI.new;local F
GameUI.new=function(root,data,presentation,event,platform)
 for _,name in ipairs({'nodePanel','choicePanel'})do
  local page=root:GetChild(name);local prior=getmetatable(page);local active=true
  setmetatable(page,{__index=function(c,key)if key=='active'then return active end;return prior.__index(c,key)end,
   __newindex=function(c,key,value)assert(key~='active','active is readonly');return prior.__newindex(c,key,value)end})
  page.SetActive=function(c,value)active=value;F.setEngineActive(c,value)end
 end
 platform.nativePageLifecycle=true
 return create(root,data,presentation,event,platform)
end
F=dofile('tests/lua/support/game_ui_fixture.lua')
dofile('.artifacts/hand-post697/map-hand.lua')`;
 const result=spawnSync(process.execPath,[createRequire(import.meta.url).resolve('fengari-node-cli/src/lua-cli.js'),'-e',source],{
  encoding:'utf8',timeout:30000,maxBuffer:2*1024*1024,env:{...process.env,LUA_INIT:'',LUA_INIT_5_3:''}});
 assert.equal(result.status,0,result.stdout+result.stderr+String(result.error??''));
 assert.match(result.stdout,/POST697_GAMEUI_MAP_HAND_PASS 1/);
 console.log(result.stdout);
});
