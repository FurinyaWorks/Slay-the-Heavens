import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdtempSync} from 'node:fs';
import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';import {gunzipSync} from 'node:zlib';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
import {sourceEpoch,preHandPost697SourceEpoch,handBeforeMapSourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {handPost697CiPacket as ci,assertHandPost697CiCurrent} from '../../tests/helpers/hand-post697-ci-source.mjs';
import {handPost697SourcePacket as product} from '../../tests/helpers/hand-post697-source.mjs';
import {mobileHandSourcePacket as handProduct} from '../../tests/helpers/mobile-hand-source.mjs';import {releaseSelectionMapSourcePacket as mapProduct} from '../../tests/helpers/release-selection-map-source.mjs';
import {copyIntegrationSourceClosure} from '../../tests/helpers/copy-integration-source-closure.mjs';import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
const hand='4ace45fedbce5fb0507f793bca0e7b5c8992e061',release='33d71575c5f186a1b54f7bf3e4f1826c145aa1d9',checkpoint='d956df3e8b429ad4d4042d9489108000fb9b327b';
const git=(...a)=>execFileSync('git',['-c','core.quotePath=false',...a],{maxBuffer:32*1024*1024}),sha=b=>createHash('sha256').update(b).digest('hex'),norm=b=>b.toString().replaceAll('\r\n','\n');
const tree=ref=>new Map(git('ls-tree','-r','-z',ref).toString().split('\0').filter(Boolean).map(r=>{const i=r.indexOf('\t');return[r.slice(i+1),r.slice(0,i).split(' ')[2]];}));
const trees={hand:tree(hand),release:tree(release),product:tree(checkpoint)};
assert.deepEqual(git('show','-s','--format=%P',checkpoint).toString().trim().split(' '),[hand,release]);
const common=resolve(git('rev-parse','--git-common-dir').toString().trim());
function actualGit(ref,path){const b=git('show',ref+':'+path);if(!b.toString().startsWith('version https://git-lfs.github.com/spec/v1'))return b;const oid=/oid sha256:([a-f0-9]{64})/.exec(b.toString())[1],size=Number(/size (\d+)/.exec(b.toString())[1]),actual=readFileSync(common+'/lfs/objects/'+oid.slice(0,2)+'/'+oid.slice(2,4)+'/'+oid);assert.equal(actual.length,size);assert.equal(sha(actual),oid);return actual;}
for(const [path,row]of Object.entries(ci.files)){
 const current=norm(readFileSync(path));assert.equal(current,row.current.source,path+' current');assert.equal(sha(current),row.current.sha256,path);
 for(const [view,ref]of Object.entries(ci.viewCommits)){const prior=row.views[view];if(prior){assert.equal(norm(actualGit(ref,path)),prior.source,path+' actual '+view);assert.equal(trees[view].get(path),prior.gitBlob,path+' real blob '+view);}else assert(!trees[view].has(path),path+' true absent '+view);}
}
const oldArchives=new Set([...trees.hand.keys(),...trees.release.keys()].filter(p=>p.startsWith('tests/helpers/')&&p.endsWith('.gz')));
for(const path of oldArchives){assert(Object.hasOwn(ci.immutableArchives,path),path+' old archive retained');const ref=trees.hand.has(path)?hand:release;assert.equal(sha(actualGit(ref,path)),ci.immutableArchives[path],path+' immutable realGit');}
for(const [path,hash]of Object.entries(ci.immutableArchives))assert.equal(sha(readFileSync(path)),hash,path+' actual archive');
assert.deepEqual(Object.keys(ci.immutableArchives).filter(p=>!oldArchives.has(p)),['tests/helpers/hand-post697-source.json.gz']);
const current=sourceEpoch.proof,map=preHandPost697SourceEpoch.proof,oldHand=handBeforeMapSourceEpoch.proof;
let count=0;for(const [path,row]of Object.entries(current.current))if(row){assert.equal(norm(readFileSync(path)),row.source,path+' actual product');assert.equal(trees.product.get(path),row.gitBlob,path+' product checkpoint');count++;}
for(const [name,target]of Object.entries(map.targets))assert.deepEqual(current.targets[name],target,'all Map target '+name);
for(const [name,target]of Object.entries(oldHand.targets))assert.deepEqual(current.targets[name],target,'all hand target '+name);
assert.deepEqual(current.targets.handPost697Release,{commit:release,files:map.current});assert.deepEqual(current.targets.handBeforeMap,{commit:hand,files:oldHand.current});assert.deepEqual(current.mobileHandProducers,oldHand.mobileHandProducers);assert.deepEqual(current.releaseSelectionMapProducers,map.releaseSelectionMapProducers);
let producers=0;for(const p of [handProduct,mapProduct])for(const [path,row]of Object.entries(p.producers)){assert.equal(norm(actualGit(row.commit,path)),p.current[path].source,path+' true producer');assert.deepEqual(git('show','-s','--format=%P',row.commit).toString().trim().split(' ').filter(Boolean),row.parents,path+' true parents');producers++;}
const originalEight=git('diff','--name-only','-z','36b9b157','da45571b').toString().split('\0').filter(Boolean);assert.equal(originalEight.length,8);
for(const path of originalEight)assert.equal(norm(readFileSync(path)),norm(actualGit(hand,path)),path+' original eight');
for(const path of ['src/lua/abyss_game_ui_input.lua','src/lua/abyss_game_ui_view.lua'])assert.equal(norm(readFileSync(path)),norm(actualGit(release,path)),path+' landed Map');
const actualInv={js:readdirSync('tests').filter(n=>n.endsWith('.test.mjs')).map(n=>'tests/'+n).sort(),lua:readdirSync('tests/lua').filter(n=>n.endsWith('.lua')).map(n=>'tests/lua/'+n).sort()};assert.deepEqual(actualInv,ci.currentInventory);
for(const [view,paths]of Object.entries(trees).filter(([name])=>name!=='product')){const all=[...paths.keys()];assert.deepEqual(ci.viewInventories[view],{js:all.filter(p=>/^tests\/[^/]+\.test\.mjs$/.test(p)).sort(),lua:all.filter(p=>/^tests\/lua\/[^/]+\.lua$/.test(p)).sort()});}
assertHandPost697CiCurrent();assertIntegratedCurrent();
const copyRoot=mkdtempSync(resolve('.artifacts/hand-post697/isolated-source-'));copyIntegrationSourceClosure(copyRoot);const copied=await import(pathToFileURL(copyRoot+'/tests/helpers/closeout-source-epoch.mjs'));assert.deepEqual(copied.sourceEpoch.proof,current);assert.deepEqual(copied.handBeforeMapSourceEpoch.proof,oldHand);
const checked=git('grep','-n','releaseSelectionMapCiCheckedSource','--','tests').toString().split('\n').filter(line=>line&&!line.includes('import {')&&!line.includes('export const'));assert.equal(checked.length,1);assert(checked[0].includes('tests/helpers/integrated-ci-source.mjs'));
const summary={status:'pass',checkpoint,parents:[hand,release],bindings:Object.keys(ci.files).length,archives:Object.keys(ci.immutableArchives).length,oldArchives:oldArchives.size,production:count,owners:current.owners.length,ownersMap:map.owners.length,ownersHand:oldHand.owners.length,targetsCurrent:Object.keys(current.targets).length,targetsMap:Object.keys(map.targets).length,targetsHand:Object.keys(oldHand.targets).length,dedicatedProducers:producers,currentRaw:Object.fromEntries(Object.entries(actualInv).map(([k,v])=>[k,v.length])),oldViewRaw:Object.fromEntries(Object.entries(ci.viewInventories).map(([view,rows])=>[view,Object.fromEntries(Object.entries(rows).map(([k,v])=>[k,v.length]))])),originalEight,exactMapRuntime:2,isolatedSourceProofEqual:true,checkedCallers:checked};
writeFileSync('.artifacts/hand-post697/audit.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));
