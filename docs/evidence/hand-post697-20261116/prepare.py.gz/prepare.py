from pathlib import Path
import subprocess,json,gzip,hashlib,re
hand='4ace45fedbce5fb0507f793bca0e7b5c8992e061';release='33d71575c5f186a1b54f7bf3e4f1826c145aa1d9';product='d956df3e8b429ad4d4042d9489108000fb9b327b';model=Path('../goal-v2-shop-post697-1116')
git=lambda *a:subprocess.check_output(['git','-c','core.quotePath=false',*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,s):Path(p).write_text(s,encoding='utf8',newline='\n')
def edit(p,a,b):
 s=Path(p).read_text(encoding='utf8');assert s.count(a)==1,(p,a[:80]);put(p,s.replace(a,b))
def row(raw):
 s=raw.decode().replace('\r\n','\n');b=s.encode();return dict(source=s,sha256=sha(b),gitBlob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
runtime=['src/lua/abyss_battle_card_view.lua'];maps=['src/lua/abyss_game_ui_input.lua','src/lua/abyss_game_ui_view.lua'];p=dict(schemaVersion=1,normalization='LF',baseCommit=release,handCommit=hand,handProductCheckpoint='f5169260880043c0fbf5d51ad869e1b493cea85d',currentCommit=product,currentTreeCommitted=True,before={},current={},handBeforeMap={})
for path in runtime:
 p['before'][path]=row(git('show',release+':'+path));p['current'][path]=row(git('show',product+':'+path));assert git('rev-parse',hand+':'+path)==git('rev-parse',product+':'+path)
for path in maps:p['handBeforeMap'][path]=row(git('show',hand+':'+path));assert git('rev-parse',release+':'+path)==git('rev-parse',product+':'+path)
data=gzip.compress((json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0);Path('tests/helpers/hand-post697-source.json.gz').write_bytes(data)
code="""// Real committed hand-values and landed selection/map source union.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {createSourceEpochProjector} from './combined-epoch/source-epoch-runtime.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
const bytes=readFileSync(new URL('./hand-post697-source.json.gz',import.meta.url));
assert.equal(hash(bytes),'PRODUCTION_SHA','complete hand post697 production packet');
export const handPost697SourcePacket=freeze(JSON.parse(gunzipSync(bytes)));
export function extendHandPost697Source(original,handEpoch,packet=handPost697SourcePacket){
 const prior=original.proof,hand=handEpoch.proof;
 assert.deepEqual(packet,handPost697SourcePacket,'exact committed hand and actual Release identities');
 assert.equal(packet.currentTreeCommitted,true);assert.equal(hand.currentCommit,packet.handProductCheckpoint);
 const current={...prior.current};
 for(const [path,row]of Object.entries(packet.current)){
  assert.deepEqual(prior.current[path],packet.before[path],'actual landed Release predecessor: '+path);current[path]=row;
 }
 assert.deepEqual({...current,...packet.handBeforeMap},hand.current,'complete original hand source domain');
 const targets={...prior.targets};
 for(const [name,target]of Object.entries(hand.targets)){
  if(Object.hasOwn(targets,name))assert.deepEqual(targets[name],target,'shared history remains exact: '+name);
  else targets[name]=target;
 }
 targets.handPost697Release={commit:packet.baseCommit,files:prior.current};
 targets.handBeforeMap={commit:packet.handCommit,files:hand.current};
 const owners=Object.keys(current).sort().filter(path=>Object.values(targets).some(target=>target.files[path]?.sha256!==current[path]?.sha256));
 return createSourceEpochProjector(freeze({...prior,current,targets,owners,mobileHandProducers:hand.mobileHandProducers,currentCommit:packet.currentCommit,currentTreeCommitted:true,currentCommitRole:'actual hand values and landed Map union; device acceptance separate'}),{allowConfigLayout:true,reuseFrozenInput:true});
}
"""
put('tests/helpers/hand-post697-source.mjs',code.replace('PRODUCTION_SHA',sha(data)))
edit('tests/helpers/closeout-source-epoch.mjs',"import {extendMobileHandSource} from './mobile-hand-source.mjs';","import {extendMobileHandSource} from './mobile-hand-source.mjs';\nimport {extendHandPost697Source} from './hand-post697-source.mjs';")
edit('tests/helpers/closeout-source-epoch.mjs','export const sourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);','export const preHandPost697SourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);\nexport const sourceEpoch=extendHandPost697Source(preHandPost697SourceEpoch,handBeforeMapSourceEpoch);')
rows=[]
for path in ['tests/helpers/closeout-source-epoch.mjs','tests/helpers/hand-post697-source.mjs','tests/helpers/hand-post697-source.json.gz']:
 rows.append(dict(path=path,before=sha(git('show',release+':'+path))if path.endswith('closeout-source-epoch.mjs')else None,after=sha(Path(path).read_bytes()if path.endswith('.gz')else Path(path).read_text(encoding='utf8').encode())))
edit('tests/helpers/copy-integration-source-closure.mjs','const inside=(root,path)=>','export const handPost697HelperCopies='+json.dumps(rows,separators=(',',':'))+";\nfor(const row of handPost697HelperCopies){assert.equal(files[row.path]??null,row.before,'exact hand post697 helper predecessor: '+row.path);files[row.path]=row.after;}\nconst inside=(root,path)=>")
s=Path('.artifacts/hand-post697/ci-template.mjs').read_text(encoding='utf8').replace('shopPost697','handPost697').replace('ShopPost697','HandPost697').replace('shop-post697','hand-post697').replace('shop post697','hand post697').replace("shop:'d9cc12bfc0e620847afa10c7e5c515d748b8ccc3'","hand:'"+hand+"'").replace('5e2375f03a9a80d2abc8420ab7a401e89d525add',product)
s=re.sub(r"assert.equal\(hash\(bytes\),'[a-f0-9]{64}'","assert.equal(hash(bytes),'POST697_CI_SHA'",s);put('tests/helpers/hand-post697-ci-source.mjs',s)
c=Path('.artifacts/hand-post697/capture-template.py').read_text(encoding='utf8').replace('shop-post697','hand-post697').replace("shop='d9cc12bfc0e620847afa10c7e5c515d748b8ccc3'","hand='"+hand+"'").replace('5e2375f03a9a80d2abc8420ab7a401e89d525add',product)
c=c.replace("changed|={'src/lua/abyss_game_ui_input.lua', 'src/lua/abyss_shop_selection.lua', 'src/lua/abyss_game_ui_view.lua', 'src/lua/abyss_node_ui_input.lua'}","changed|="+repr(set(runtime+maps)))
# Replace the explicit shop ports by the independently measured three actual product paths.
c=re.sub(r"changed\|=\{[^\n]+\}\nchanged=",'changed|='+repr(set(runtime+maps))+'\nchanged=',c)
put('.artifacts/hand-post697/capture.py',c)
Path('.artifacts/hand-post697/production.json').write_text(json.dumps(dict(hand=hand,release=release,product=product,sha256=sha(data),bytes=len(data)),indent=2)+'\n')
print(json.dumps(dict(product=product,productionPacket=sha(data),bytes=len(data))))
