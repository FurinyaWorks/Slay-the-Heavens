local V=dofile('tests/lua/support/hand_layout_values_fixture.lua')
local CardView=require('abyss_battle_card_view')
local apply=V.upvalue(CardView.new,'applyHandPose')
local values,index=V.upvalue(apply,'handValues')
local calls,temporary=0,0
debug.setupvalue(apply,index,function(...)
 local a,b,c,d,e,f,g,h=values(...);calls=calls+1
 if type(a)=='table'then temporary=temporary+1 end
 return a,b,c,d,e,f,g,h
end)
local original,created=CardView.new
CardView.new=function(...)created=original(...);return created end
local H=dofile('tests/lua/support/battle_gesture_fixture.lua')
local host,ui,panel,event,tap,drain,deck,root=H.setup({'strike','defend','strike','defend','strike'},{'cultist'},{touchScreen=function()return true end})
for _=1,20 do host:update(.05)end
local run,battle,map=host.run,host.run.combat,host.map
local before=H.F.Combat.copy(run);before.elapsedSeconds=nil
local function geometry()
 for uid,entry in pairs(V.upvalue(created.update,'handPoses'))do
  local box=entry.box;local hit=box:GetChild('hit');local expected=V.reference(entry.current,entry.target)
  local actual={box.x,box.y,box.scale[1],box.localRotationZ,hit.x,hit.y,hit.sizeDeltaX,hit.sizeDeltaY}
  for i=1,8 do assert(actual[i]==expected[i],'union hand geometry changed '..i)end
  assert(ui.cardPositions[uid][1]==entry.current.x and ui.cardPositions[uid][2]==entry.current.y)
 end
end
calls,temporary=0,0
for _=1,3 do host:update(.05);geometry()end
local function get(path)
 local control=root
 for name in path:gmatch('[^/]+')do control=assert(control:GetChild(name),path)end
 return control
end
local function click(path,id)
 local box=get(path);local hit=box.kind=='cursorArea'and box or box:GetChild('hit')
 local listeners=hit.listeners or{}
 if listeners.down then listeners.down({touchId=id})end
 if listeners.up then listeners.up({touchId=id})end
 return assert(hit.click or listeners.click,path..' missing click')({touchId=id})
end
assert(host:openMenu());assert(click('runMenu/map',71));assert(host.routeOpen)
assert(not host.mapUI.navigationEnabled and not host.mapUI:choose('f1_l1'))
assert(click('mapPanel/previewBack',72));assert(not host.routeOpen and host.mode=='battle')
for _=1,3 do host:update(.05);geometry()end
ui:setHover(2);host:update(.05);geometry();ui:setHover(nil);host:update(.1);geometry()
assert(host.run==run and run.combat==battle and host.map==map)
local after=H.F.Combat.copy(run);after.elapsedSeconds=nil
assert(V.same(before,after),'Map preview and hand refresh changed complete Run/RNG')
assert(calls>0 and temporary==0,'union lost scalar-only temporary-free hand computation')
assert(host:disable());print('POST697_GAMEUI_MAP_HAND_PASS 1 calls='..calls..' temporary=0 runRngEqual=true')
