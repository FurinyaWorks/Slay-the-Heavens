package.path=(os.getenv('LIFECYCLE_GENERATED') or 'build/lua')..'/?.lua;build/lua/?.lua;src/lua/?.lua;'..package.path
local Browser=require('abyss_deck_browser')
local Controller=require('abyss_controller')
local F=dofile('tests/lua/support/game_ui_fixture.lua')
local spec={name='faceRoot',kind='container',children={{name='face',kind='container',children={{name='art',kind='image'}}},{name='hit',kind='cursorArea'}}}
local cursor={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='end'}
local function setup()
    local host=F.control({name='host',kind='container'})
    local focus,using
    local controller=Controller.new({events={Confirm='confirm',Cancel='cancel'},directions={},modes={},
        getFocus=function() return focus end,setFocus=function(c) focus=c end,isController=function() return using==true end})
    local counts={create=0,destroy=0};local picks={};local opts={}
    local factory={budget=.004,create=function(parent)
        counts.create=counts.create+1
        local box=F.control(spec,parent);parent.children[counts.create]=box
        if opts.onCreate then opts.onCreate(box) end
        return box
    end,destroy=function(box)
        counts.destroy=counts.destroy+1
        for k,v in pairs(host.children) do if v==box then host.children[k]=nil end end
    end}
    local pool=Browser.new(host,factory,{cursorEvents=cursor,controller=controller},'click',120,
        function(card)return {look={card.kind}}end,
        function(entry,model,unchanged) if opts.paint then opts.paint(entry,model,unchanged) end end,
        function(card) picks[#picks+1]=card.uid;return true end)
    local function update()
        pool:step();pool:step();controller:tick();controller:sync('deck',function() end)
    end
    return {host=host,pool=pool,opts=opts,picks=picks,counts=counts,controller=controller,update=update,
        focus=function(control) using=true;focus=control;controller:sync('deck') end}
end
local function one(uid)return {{uid=uid,kind='same'}} end
local function oldPointer()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();local hit=p.entries[1].hit
    hit.listeners.down({touchId=11})
    p:request(one('B'));s.update();assert(p.entries[1].hit==hit)
    hit.listeners.up({touchId=11});assert(not hit.click({touchId=11}));assert(#s.picks==0)
    hit.listeners.down({touchId=12});hit.listeners.up({touchId=12});assert(hit.click({touchId=12}) and s.picks[1]=='B')
    print('PASS legacy pointer release is rejected after rebind; new pointer succeeds')
end
local function oldConfirm()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();local hit=p.entries[1].hit;s.focus(hit)
    local deferred=hit.navigationListeners.confirm
    p:request(one('B'));s.update();assert(p.entries[1].hit==hit)
    assert(not deferred({pressId=1}),'stale confirm opened rebound '..tostring(s.picks[1]))
end
local function bindReentry()
    local s=setup();local p=s.pool
    s.opts.onCreate=function(box)
        local saved=box.SetVisible
        box.SetVisible=function(self,visible)
            if not visible and s.opts.onCreate then s.opts.onCreate=nil;p:request(one('B')) end
            return saved(self,visible)
        end
    end
    p:request(one('A'));s.update();s.update();assert(p.job.ready and p.job.cards[1].uid=='B')
    p:release();local left=0;for _ in pairs(s.host.children) do left=left+1 end
    assert(left==0 and #s.controller.records==0,'native roots='..left..', bound records='..#s.controller.records..', creates='..s.counts.create..', destroys='..s.counts.destroy)
end
local function paintReentry()
    local s=setup();local p=s.pool
    s.opts.paint=function(entry)
        if entry.root.tag==nil then entry.root.tag='A in progress';p:request(one('B'));s.update();entry.root.tag='stale A'
        else entry.root.tag='current B' end
    end
    p:request(one('A'));s.update()
    s.update()
    assert(p.job.ready and p.job.cards[1].uid=='B')
    assert(p.entries[1].root.tag=='current B','stale writes won: '..p.entries[1].root.tag)
    print('PASS old paint cannot overwrite later publication')
end
local function requestReentry()
    local s=setup();local p=s.pool
    local setVisible=s.host.SetVisible
    local first=true
    s.host.SetVisible=function(self,visible)
        if first and not visible then first=false;p:request(one('new B')) end
        return setVisible(self,visible)
    end
    p:request(one('old A'));s.update()
    assert(p.job.ready and p.job.cards[1].uid=='new B','outer superseded request overwrote nested latest request')
end
local function publishReentry()
    local s=setup();local p=s.pool
    s.opts.onCreate=function(box)
        if s.counts.create==2 then
            local hit,visible=box:GetChild('hit'),F.control({name='dummy'}).SetVisible
            hit.SetVisible=function(self,show)
                if show and s.opts.onCreate then s.opts.onCreate=nil;p:request(one('new B')) end
                return visible(self,show)
            end
        end
    end
    p:request({one('old A')[1],{uid='old B',kind='other'}});s.update();s.update()
    assert(p.job.ready and p.job.cards[1].uid=='new B')
    assert(not p.entries[2].root.visible,'old slot remained visible after reentrant Rebind reduced page')
end
local function deadChild()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();local hit=p.entries[1].hit
    local mt=getmetatable(hit)
    setmetatable(hit,{__index=function(t,k)if k=='alive'then return false end;return mt.__index(t,k)end,__newindex=mt.__newindex})
    p:request(one('B'));s.update()
    if p.job.error then p:request(one('B'));s.update() end
    assert(p.job.ready,'dead hit tree remains cached and prevents retry: '..tostring(p.job.error))
end
local function dragClick()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();local hit=p.entries[1].hit
    hit.listeners.down({touchId=2});hit.listeners.up({touchId=2});assert(not hit.click({touchId=2,dragging=true}))
    assert(not hit.click({touchId=2}), 'dragged Click left a live release token for a second Click')
end
local function rejectsConfirmRemoval()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();local hit=p.entries[1].hit
    local remove=hit.RemoveNavigationEventListener;local fail=true
    hit.RemoveNavigationEventListener=function(self,event,callback)
        if fail then fail=false;return false end
        return remove(self,event,callback)
    end
    p:request(one('B'));s.update();assert(p.job.error,'fixture did not inject Confirm removal rejection')
    p:request(one('B'));s.update()
    assert(p.job.ready,'native listener removal rejection permanently broke retry: '..tostring(p.job.error))
end
local function rejectsDestroy()
    local s=setup();local p=s.pool
    p:request(one('A'));s.update();p.factory.destroy=function()return false end;p:release()
    assert(#p.entries==1 or #(p.retired or {})==1,'failed native destruction lost all tracking')
    print('PASS destruction rejection retains ownership')
end
for _,case in ipairs({{'pointer',oldPointer},{'confirm',oldConfirm},{'reentrant bind',bindReentry},
    {'reentrant paint',paintReentry},{'reentrant request',requestReentry},{'reentrant publish',publishReentry},
    {'dead child retry',deadChild},{'Confirm removal retry',rejectsConfirmRemoval},{'drag Click release',dragClick},{'destruction rejection',rejectsDestroy}}) do
    local ok,err=pcall(case[2]);if not ok then print('FAIL '..case[1]..': '..tostring(err)) end
end
