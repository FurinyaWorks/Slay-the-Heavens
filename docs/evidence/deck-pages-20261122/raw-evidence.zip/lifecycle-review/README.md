# 牌库资源与输入生命周期独立复查

使用候选工作树的真实 Lua 模块、生成控件布局与共享模拟原生控件。流程、模型、资源分配和事件结果适用于离线夹具。官方客户端的派发顺序、像素呈现、控件真实内存和物理设备耗时待验。

在候选根运行以下命令。设置 LIFECYCLE_GENERATED 时使用相同候选生成的默认正式配置布局目录。

```sh
node scripts/build-lua-data.mjs data <generated>/abyss_data.lua
node scripts/build-ui.mjs <generated> --official-assets --native-page-lifecycle --refined-release-monsters
LIFECYCLE_GENERATED=<generated> luatex --luaonly <suite>.lua
```

- `pool-repro.lua` 注入创建、绘制、显示、请求重入，销毁拒绝与子控件单独销毁，覆盖旧 Down/Up、拖动回调与新手势。裸池直接调用独立于正式 Host 的焦点协议。
- `host-repro.lua` 从实际标题、选角、地图入口进入。冷开尚未创建卡面时，局部遮罩保留触屏返回与手柄取消。确认详情关闭恢复第 5 槽。注入一次实例化失败，再返回和重开，观察新请求独立完成。
- `confirm-repro.lua` 实际翻页后重放仍排队的旧槽 Confirm，验证焦点已切到返回而且无法打开重绑的卡面。`TEST_DETAIL_CONFIRM=1` 另模拟旧 Confirm 延迟到详情返回且焦点已恢复原槽，人工回调触发能力与官方是否派发需分别判断。
- `run-switch-repro.lua` 验证换 Run 立即释放旧物理根，下一版面第一页。
- `battle-switch-repro.lua` 验证同 Run 换战斗后，新抽牌堆从第一页开始。
- `resource-repro.lua` 走完 0/1/7/10/11/20/75/250 张的互动边界，校验 Frozen Eye、变费、切输入、同入口暖重开与不改 Run。混合能力牌高水位后，在 20 次循环中分别访问永久牌库、抽/弃/消耗堆。
- `hidden-grid-repro.lua` 先走 12 项现有选牌，再打开十牌只读浏览。`DESTROY_GRID=1` 使用同一夹具的刷新销毁模式。分别统计整个表单、浏览层和旧选择 Grid。
- `art-repro.lua` 明确启用每卡一形状的合成 native art 以观察租约，核对 12 张分页、关闭及 10 个旧战斗 lease 阻塞新牌面。正式渲染旗标保持 `cards=false`。

## 正式分段复验

使用 `LIFECYCLE_GENERATED=build/formal` 和 `F.deckBrowser()` 运行，实际模板为一壳与五段。 `segmented-repro.lua` 的 15 个用例覆盖五段各自首次请求返回空值、壳与段构造中关闭、同调用栈关闭和重开、更换 Run、OnDestroy 与分段或壳已挂载后抛错。所有用例保持同时最多十个活卡根。每个重新发布的卡根都有五个唯一存活段，且关闭/替换后旧任务不能重新发布。测试触发过构造失败，累计创建/删除可能为 11/1，存活上限为十。

正式生成树的 20 轮压力测试每轮访问永久、抽、弃、消耗四个入口。高水位之后壳和段零创建与销毁，牌库面板总 3,704 控件，浏览子树 3,161 控件（含容器），29 条控制记录、78 个 cursor 监听、58 个 navigation 监听。旧的 12 项选牌 Grid 经回收替身保留时，同一面板实际总 7,976 控件与 41 条控制记录。替身销毁配置为 3,704 与 29。两组均包含详细层及隐藏 Grid；旧选牌 Grid 的正式客户端真实保留量待验。
