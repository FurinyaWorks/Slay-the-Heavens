local directory=assert(os.getenv('PROBE'))
local build=assert(os.getenv('BUILD'))
local target=assert(os.getenv('TARGET'))
local source=os.getenv('SOURCE') or 'src/lua'
local profile=assert(os.getenv('PROFILE'))
local common=os.getenv('COMMON_SOURCE') or 'src/lua'
package.path=build..'/?.lua;build/lua/?.lua;'..source..'/?.lua;'..common..'/?.lua;src/lua/?.lua;tests/lua/?.lua;'..package.path
local counted=os.getenv('COUNTS')~='0'
local F=dofile(directory..(counted and '/instrumented-fixture.lua' or '/lean-fixture.lua'))
local Gate=require('abyss_page_reveal')
local Game=require('abyss_game_ui')
local Art=require('abyss_card_art_runtime')
local Combat=F.Combat
local max=tonumber(os.getenv('SAMPLES')) or 1
local amount=tonumber(os.getenv('AMOUNT')) or 20
local candidate=target~='baseline'
local realCreate=Game.new
local host,root,activeFocus,controller
local probeEligibleCalls,maxCreateMs,forcedCreate=0,0,tonumber(os.getenv('SLOW_CREATE_MS'))
local kinds={attack=true,skill=true,power=true,status=true,curse=true}
local defaults={attack=3,skill=3,power=2,status=1,curse=1}
local columns={'child','children','visible','size','position','image','anchor','scale','rotation','cursorBind','navBind','navLink','createNodes','destroyNodes','createRoot','destroyRoot','gridRefresh','gridFill'}
local function readiness(intent)
    local deck=host.deckUI
    if intent.page=='deckPanel' and deck.gridReady and not deck.pending and not deck.calibrating then deck.gridReady() end
    return (intent.page~='deckPanel' or not (deck.pending or deck.calibrating or deck.pendingGrid))
        and Art.presentationReady(intent.page)
end
Game.new=function(canvas,data,presentation,event,platform)
    platform.presentationReady=readiness
    platform.presentationPage=Art.setPresentationPage
    if candidate then
        local factory=F.deckBrowserFactory()
        local original=factory.create
        function factory.create(parent)
            local before=os.clock()
            if forcedCreate then
                while (os.clock()-before)*1000<forcedCreate do end
            end
            local result=original(parent)
            maxCreateMs=math.max(maxCreateMs,(os.clock()-before)*1000)
            return result
        end
        platform.deckBrowser=factory
    end
    platform.controllerApi={
        events={Confirm='confirm',Cancel='cancel',Focus='focus'},
        directions={Left='left',Right='right'},
        modes={Specified='specified'},
        getFocus=function() return activeFocus end,
        setFocus=function(control) activeFocus=control end,
        isController=function() return controller end,
    }
    host=realCreate(canvas,data,presentation,event,platform)
    local manager=host.controller
    if manager then
        local eligible=manager.eligible
        function manager:eligible(record)
            if counted then probeEligibleCalls=probeEligibleCalls+1 end
            return eligible(self,record)
        end
    end
    return host
end
local function tick()
    host:update(1/60)
    Art.update()
    host.pageReveal:step(Gate.intent(host))
end
local function settle()
    local iterations,worst=0,0
    while iterations<50 do
        local deck=host.deckUI
        local pending=deck.pending or deck.calibrating or deck.pendingGrid
        if not pending and not host.pageReveal:covered() then return iterations,worst end
        local start=os.clock()
        tick()
        worst=math.max(worst,os.clock()-start)
        iterations=iterations+1
    end
    error('unready page '..tostring(host.deckUI.prepareError)..':'..tostring(host.pageReveal.state)..':'..tostring(host.deckUI.calibrating))
end
local function makeCards(run)
    local choices={}
    for id,row in pairs(run.combat.catalog.cards) do
        if F.Presentation[id] and kinds[row.type] then choices[#choices+1]=row end
    end
    table.sort(choices,function(a,b) return a.id<b.id end)
    local wanted, picked = {}, {}
    for kind,limit in pairs(defaults) do wanted[kind]=limit end
    for _,row in ipairs(choices) do
        if wanted[row.type] > 0 then
            wanted[row.type]=wanted[row.type]-1
            picked[#picked+1]=row
        end
    end
    assert(#picked>=7)
    local cards={}
    for i=1,amount do
        local row=picked[(i-1)%#picked+1]
        cards[i]={cardId=row.id,uid=10000+i,upgraded=i%3==0 and row.upgrade~=nil,costForTurn=i%7==0 and 0 or nil}
        if row.type=='power' then cards[i].upgraded=true end
    end
    return cards
end
local function setup()
    activeFocus=nil
    controller=profile=='controller'
    host,root=F.fixture(nil,function()return true end)
    if not candidate then
        local grid=root:GetChild('deckPanel'):GetChild('pileGrid')
        if os.getenv('DESTROY_GRID')=='1' then grid.destroyOnRefresh=true end
        if os.getenv('DEFAULT_GRID')~='1' then
            function grid:flush()
                for i=0,math.min(self.itemCount,15)-1 do self:recycle(i,i+self.indexBase) end
            end
        end
    end
    settle()
    assert(host:start())
    settle()
    assert(F.confirmStart(host))
    settle()
    local run=host.run
    assert(require('abyss_run').startCombat(run,'cultist_solo'))
    run.combat.draw=makeCards(run)
    host:refresh()
    settle()
end
local function inventory()
    local result={nodes=0,listeners=0,faceRoots=0,visibleRoots=0}
    local panel=root:GetChild('deckPanel')
    local browser=panel:GetChild('pileGrid')
    local function walk(control,visible)
        if control.alive==false then return end
        result.nodes=result.nodes+1
        visible=visible and control.visible~=false
        for _,kind in ipairs({'listeners','navigationListeners','keyListeners'}) do
            for _ in pairs(control[kind] or {}) do result.listeners=result.listeners+1 end
        end
        if control.name=='AbyssBattlePileCard' then
            result.faceRoots=result.faceRoots+1
            if visible then result.visibleRoots=result.visibleRoots+1 end
        end
        for _,child in pairs(control.children or {}) do walk(child,visible) end
        for _,item in pairs(control.items or {}) do walk(item,visible) end
    end
    walk(panel,true)
    result.registrations=host.controller and #host.controller.records or 0
    result.art=Art.status().liveControls
    return result
end
local function measure(iteration,name,action)
    local elapsed,shell,turns,worst
    probeEligibleCalls,maxCreateMs=0,0
    local counts=F.measured(function()
        local start=os.clock()
        assert(action())
        shell=os.clock()-start
        turns,worst=settle()
        elapsed=os.clock()-start
    end,counted)
    local retained=inventory()
    local fields={target,profile,amount,counted and 'counted' or 'timed',iteration,name,shell*1000,elapsed*1000,math.max(shell,worst)*1000,turns,probeEligibleCalls,retained.nodes,retained.listeners,retained.faceRoots,retained.visibleRoots,retained.registrations,retained.art,maxCreateMs}
    for _,column in ipairs(columns) do fields[#fields+1]=counts[column] or 0 end
    print('ROW\t'..table.concat(fields,'\t'))
end
local clockTicks={}
for i=1,7 do
    local first=os.clock()
    local current=first
    while current==first do current=os.clock() end
    clockTicks[i]=current-first
end
print('CLOCK\t'..table.concat(clockTicks,'\t'))
print('FIELDS\ttarget\tprofile\tamount\tmode\titeration\toperation\tcallback_ms\ttotal_ms\tmax_step_ms\tturns\teligible\tnodes\tlisteners\tfaceRoots\tvisibleRoots\tregistrations\tnativeArt\tmax_create_ms\t'..table.concat(columns,'\t'))
for iteration=1,max do
    setup()
    local function open() return root:GetChild('battlePanel'):GetChild('drawIcon'):GetChild('hit').click() end
    local function close() return host:closeDeck() end
    local function sort() return root:GetChild('deckPanel'):GetChild('pileTools'):GetChild('type'):GetChild('hit').click() end
    local function flip() return host.deckUI:controllerStep(1) end
    if os.getenv('WARM_COMPARE')=='1' then
        host.deckUI:syncRun(host.run)
        measure(iteration,'startup_idle',function()
            if target~='prewarm' then return true end
            local pool
            for index=1,100 do
                local key,value=debug.getupvalue(host.deckUI.update,index)
                if key=='pool' then pool=value;break end
                if not key then break end
            end
            assert(pool)
            local turns,longest=0,0
            repeat
                local start=os.clock()
                local warmed=pool:prewarm()
                longest=math.max(longest,(os.clock()-start)*1000)
                turns=turns+1
                if warmed then break end
            until turns==50
            print('WARM	'..turns..'	'..longest)
            return true
        end)
    end
    measure(iteration,'cold',open)
    if amount>10 and (candidate or controller) then measure(iteration,'flip',flip) end
    measure(iteration,'sort',sort)
    measure(iteration,'idle120',function() for _=1,120 do tick() end return true end)
    measure(iteration,'close',close)
    measure(iteration,'warm',open)
    if os.getenv('REVISIT')~='0' then measure(iteration,'revisit20',function()
        for _=1,20 do
            assert(close());settle()
            assert(open());settle()
        end
        return true
    end) end
    assert(close());settle()
    host:disable()
    host,root,activeFocus=nil,nil,nil
    collectgarbage('collect')
end
