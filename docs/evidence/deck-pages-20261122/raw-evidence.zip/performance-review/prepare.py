import os,re
from pathlib import Path
base=Path(os.getenv('PERF_BASE_WORKTREE', str(Path(__file__).parent.parent/'deck-baseline')))/'tests/lua/support/game_ui_fixture.lua'
out=Path(__file__).parent/'instrumented-fixture.lua'
source=base.read_text()
metrics={'GetChild':'child','GetChildren':'children','SetVisible':'visible','SetSizeDelta':'size','SetAnchoredPosition':'position','SetImage':'image','SetAnchorMin':'anchor','SetAnchorMax':'anchor','SetPivot':'anchor','SetLocalScale':'scale','SetLocalRotation':'rotation','AddCursorEventListener':'cursorBind','AddNavigationEventListener':'navBind','SetControllerNavigation':'navLink'}
source="""
local counts, mode, tracked = {}, nil, setmetatable({}, {__mode='k'})
local function count(control, key)
    if mode and tracked[control] then counts[key]=(counts[key] or 0)+1 end
end
local function measured(func,enabled)
    counts={};mode=enabled
    local result=func()
    mode=nil
    return counts,result
end
"""+source
for method,col in metrics.items():
    target=f'function Control:{method}'
    source,n=re.subn(r'^('+rf'function Control:{method}' + r'\([^\n]*?\))', lambda m:m[0]+f" count(self,'{col}');",source,count=1,flags=re.M)
    assert n==1,method
source=source.replace("    engineAlive[control]=false","    count(control,'destroyNodes')\n    engineAlive[control]=false")
source=source.replace("        sizeDeltaX = spec.size and spec.size[1], sizeDeltaY = spec.size and spec.size[2] }","""        sizeDeltaX = spec.size and spec.size[1], sizeDeltaY = spec.size and spec.size[2] }
    if spec.name=='deckPanel' or parent and tracked[parent] then
        tracked[self]=true
        count(self,'createNodes')
    end""")
source=source.replace("            self.itemCount, self.refreshCallback = amount, fn","""            count(self,'gridRefresh')
            self.itemCount, self.refreshCallback = amount, fn""")
source=source.replace("            self.refreshCallback(self.items[slot], index)","""            count(self,'gridFill')
            self.refreshCallback(self.items[slot], index)""")
source=source.replace("    GameUI = {new=newGameUI},","""    GameUI = {new=newGameUI},
    measured=measured,
    destroy=destroyControl,
    deckBrowserFactory=function()
        local serial=0
        return {
            create=function(parent)
                local card=control(assert(Templates.AbyssBattlePileCard),parent)
                serial=serial+1
                parent.children['dynamicCard'..serial]=card
                count(card,'createRoot')
                return card
            end,
            destroy=function(card)
                count(card,'destroyRoot')
                for key,value in pairs(card.parent.children) do
                    if value==card then card.parent.children[key]=nil;break end
                end
                destroyControl(card)
            end,
        }
    end,""")
out.write_text(source)
