import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Worker} from 'node:worker_threads';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';

const scratch=process.env.PROBE;
const seed=JSON.parse(readFileSync('experiments/art-tech-lab/seed.save.json'));
const workerPath=join(scratch,'sdk/node_modules/beyond-simulator-mcp/dist/worker.js');
const workerBytes=readFileSync(workerPath);
const workerSha256=createHash('sha256').update(workerBytes).digest('hex');
assert.equal(workerSha256,'de72d4f80b230cfac330ab0ac6fa9d05e51bb8f51d352f08dd1ee6bcba0fe09d');
const archive=structuredClone(seed);
const root=seed.assets.server.root.children[0];
const templateId=1800000001,gridId=1800000002,rootId=1800000003,scriptId=1800000004;
const partitioned=process.env.SPLIT_TEMPLATE==='1';
const full=process.env.FULL_TEMPLATE==='1'||partitioned;
const script={
 id:'s'+scriptId,guid:scriptId,path:'grid-probe.lua',controlAsset:'server-control-template',controlId:'n'+rootId,
 source:`
function OnStart()
    local grid=assert(script.object:GetChild('grid'))
    local previous,retired={},{}
    local same=script.object:GetChild('grid')
    print('CONTROL-HANDLE',grid==same,rawequal(grid,same),tostring(grid.id)==tostring(same.id),type(grid.id),rawequal(grid.id,same.id))
    for _,n in ipairs({0,1,7,10,11,20,75,250,10,10,0,10,0}) do
        local current,count,reused,visible= {},0,0,0
        grid:RefreshItems(n,function(card,index)
            assert(index==count,'unexpected callback index')
            count=count+1
            local id=tostring(card.id)
            if previous[id] then reused=reused+1 end
            assert(not current[id],'non-unique native control id '..id)
            current[id]=card
            if card.visible then visible=visible+1 end
        end)
        local destroyed=0
        for _,handle in pairs(previous) do
            if not handle.alive then destroyed=destroyed+1 end
        end
        print('GRID',n,count,#grid:GetChildren(),count-reused,reused,destroyed,visible)
        previous=current
    end
end
`,
};
const grid={...root.children.find(n=>n.kind==='grid'),id:'n'+gridId,guid:gridId,name:'grid',itemPrefabId:templateId,
  layoutConstraint:'Fixed',layoutConstraintFixedCount:5,previewCount:5,children:[]};
const shell={...root,id:'n'+rootId,guid:rootId,name:'probe',children:[grid],scriptMappingIds:[script.id]};
let chunks=[];
let template={...root,id:'n'+templateId,guid:templateId,name:'template',children:[]};
if(full){
 const specs=JSON.parse(readFileSync(join(scratch,'snapshot/generated/game-ui-templates.json')));
 const spec=specs.find(node=>node.name==='AbyssBattlePileCard');
 const prototypes=Object.fromEntries([root,...root.children].map(node=>[node.kind,node]));
 let next=1900000000;
 const project=(s,id=++next)=>{
  const kind={text:'textbox',cursorArea:'cursor'}[s.kind]??s.kind;
  const model=prototypes[kind];
  assert(model,'unknown projected card node kind '+kind);
  const node={...structuredClone({...model,children:[]}),id:'n'+id,guid:id,kind,name:s.name,
    visible:s.visible!==false,scriptMappingIds:[],children:(s.children??[]).map(child=>project(child))};
  for(const transform of Object.values(node.transformByPlatform)){
   transform.offset={x:s.position?.[0]??0,y:s.position?.[1]??0};
   transform.size={x:s.size?.[0]??0,y:s.size?.[1]??0};
   transform.scale={x:s.scale?.[0]??1,y:s.scale?.[1]??1,z:1};
  }
  if(kind==='textbox') Object.assign(node,{text:s.text?.content??'',fontSize:s.text?.fontSize??20});
  if(kind==='image') Object.assign(node,{imageId:s.image,imageType:s.image>100006?'Basic':null});
  return node;
 };
 if(partitioned){
  const rolePaths=[['face','nativePlayableRim'],['face','stsReferenceBack'],
    ['face','stsReferenceChrome','frame'],['face','stsReferenceChrome','banner']];
  chunks=rolePaths.flatMap(roles=>{
   const parent=roles.reduce((node,role)=>node.children.find(child=>child.name===role),spec);
   const parts=parent.children;
   parent.children=[];
   return parts.toReversed().map(part=>({roles,part}));
  }).map((chunk,index)=>({...chunk,template:project(chunk.part,templateId+index+5)}));
 }
 template=project(spec,templateId);
 shell.children=[];
 script.source=`
function OnStart()
    local focus=script.object
    local created,elapsed,partTimes={},{},{}
    for i=1,20 do
        local start=os.clock()
        local face=assert(game.InstantiateClientUIControl(${templateId},focus))
        elapsed[i]=(os.clock()-start)*1000
        created[i]=face
        assert(face:GetChild('face'))
        ${chunks.map(({roles,template})=>`do
            local owner=face${roles.map(role=>`:GetChild('${role}')`).join('')}
            local before=os.clock()
            local part=assert(game.InstantiateClientUIControl(${template.guid},owner))
            partTimes[#partTimes+1]=(os.clock()-before)*1000
            assert(part.name=='${template.name}')
        end`).join('\n')}
        local function nodes(box,signature)
            local children=box:GetChildren()
            if signature then signature[#signature+1]=box.name..':'..#children..':'..box.sizeDeltaX..':'..box.sizeDeltaY end
            local total=1
            for _,child in ipairs(children) do total=total+nodes(child,signature) end
            return total
        end
        local signature=i==1 and {} or nil
        assert(nodes(face,signature)==356)
        if signature then print('TEMPLATE-TREE',table.concat(signature,';')) end
        if i==10 or i==20 then
            local keep=focus:GetChildren()
            assert(#keep==10)
            for j=i-9,i do
                game.DestroyClientUIControl(created[j])
                assert(not created[j].alive)
            end
            assert(#focus:GetChildren()==0)
        end
    end
    print('FULL-TEMPLATE',table.concat(elapsed,','),table.concat(partTimes,','))
end
`;
}
archive.assets.server.root.children=[shell];archive.assets.server.selectedId=shell.id;
archive.assets.client.root.children=[template,...chunks.map(chunk=>chunk.template)];archive.assets.client.selectedId=template.id;
archive.assets.scripts=[script];
archive.meta={name:'Public SDK Grid ownership probe'};
const worker=new Worker(pathToFileURL(workerPath));
let index=0;
const pending=new Map();
worker.on('message',r=>{
 const task=pending.get(r.id);
 if(!task) return;
 pending.delete(r.id);
 if(r.ok) task.resolve(r.value);else task.reject(Error(r.error));
});
worker.on('error',error=>{for(const task of pending.values())task.reject(error)});
function call(action,args={}){
 const id=++index;
 return new Promise((resolve,reject)=>{
  pending.set(id,{resolve,reject});worker.postMessage({id,action,args});
 });
}
try{
 await call('start',{archive,clockMode:'manual',muteAudio:true});
 const step=await call('step',{dt:1/60,inspect:true});
 const snapshot=await call('get',{inspect:true,view:true,paint:true});
 const report={kind:'public-npm-worker-black-box',supportedReplayIdentity:false,sdk:'beyond-simulator-mcp@0.5.2',
   workerSha256,fixture:'minimal synthetic SDK model; no official GIL or device',records:[],step,snapshot};
 function search(node){
  if(typeof node==='string'&&(node.startsWith('GRID')||node.startsWith('FULL-TEMPLATE')||node.startsWith('CONTROL-HANDLE')||node.startsWith('TEMPLATE-TREE')))report.records.push(node);
  if(node&&typeof node==='object')for(const item of Object.values(node))search(item);
 }
 search(snapshot);
 writeFileSync(join(scratch,process.env.REPORT_NAME??(partitioned?'sdk-split-template-results.json':full?'sdk-template-probe-results.json':'sdk-grid-probe-results.json')),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report.records.map(row=>row.startsWith('TEMPLATE-TREE')?createHash('sha256').update(row).digest('hex'):row)));
 assert.equal(report.records.length, full?2:14);
}finally{
 await worker.terminate();
}
