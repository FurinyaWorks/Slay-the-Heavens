from pathlib import Path
p=Path(__file__).parent
source=(p/'snapshot/source/abyss_card_skin.lua').read_text()
i=source.index('local function referenceState(')
j=source.index('\nlocal function referenceBody(',i)
replacement="""local function referenceLeaves(node,list)
    local children=node:GetChildren()
    if #children==0 then list[#list+1]=node
    else for _,child in ipairs(children)do referenceLeaves(child,list)end end
end
local function referenceFrame(state)
    if state.frameParts then return state.frameParts end
    local frame=state.root:GetChild('frame')
    local capacity=#Theme.officialAssets.stsCardReference.geometry.frameProfiles.power
    local parts={}
    for first=1,capacity,50 do
        local batch=frame:GetChild('batch'..math.floor((first-1)/50))
        for i=first,math.min(capacity,first+49) do parts[i]=batch:GetChild('part'..i) end
    end
    state.frameParts=parts
    return parts
end
local function referenceRarityMaterials(state)
    if state.materials then return end
    local materials={frame=referenceFrame(state),plaque={state.root:GetChild('plaqueFace')}}
    for _,group in pairs(state.groups) do
        for _,part in ipairs(group:GetChildren())do
            local key=referenceMaterials[part.name]
            if key and key~='portrait' and key~='frame' and key~='plaque' then
                materials[key]=materials[key] or {}
                referenceLeaves(part,materials[key])
            end
        end
    end
    local banner={front={},fold={}}
    for _,part in ipairs(state.root:GetChild('banner'):GetChildren())do
        referenceLeaves(part,banner[part.name=='front' and 'front' or 'fold'])
    end
    state.materials,state.banner=materials,banner
end
local bodyKinds={bodyFit='outer',paperWell='body',topBevel='shade',leftBevel='shade',rightBevel='outer',bottomBevel='outer',innerLight='bevel',cornerBevel='bevel'}
local function referenceBodyMaterials(state)
    if state.bodyMaterials then return state.bodyMaterials end
    local materials={}
    for _,part in ipairs(state.back:GetChild('body'):GetChildren())do
        local key=bodyKinds[part.name];materials[key]=materials[key] or {};referenceLeaves(part,materials[key])
    end
    state.bodyMaterials=materials
    return materials
end
local function referenceWell(state,kind)
    if state.wells[kind] then return state.wells[kind] end
    local parts={}
    referenceLeaves(state.groups[kind]:GetChild('well'),parts)
    state.wells[kind]=parts
    return parts
end
local function referenceState(box,root,templateKind)
    local state=referenceStates[box]
    if state then return state end
    local back=box:GetChild('stsReferenceBack')
    local portraits=back:GetChild('portraits')
    state={root=root,back=back,groups={},wells={}}
    for _,kind in ipairs({'attack','skill','power'})do state.groups[kind]=portraits:GetChild(kind) end
    if templateKind then
        state.rarity,state.bodyKind,state.wellKind='common','geo',templateKind
    else
        referenceRarityMaterials(state)
        referenceBodyMaterials(state)
        for _,kind in ipairs({'attack','skill','power'})do referenceWell(state,kind) end
    end
    state.cost=box:GetChild('stsReferenceCost'):GetChild('costMaterial')
    referenceStates[box]=state;return state
end
"""
source=source[:i]+replacement+source[j:]
source=source.replace("for key,parts in pairs(state.bodyMaterials)do","for key,parts in pairs(referenceBodyMaterials(state))do")
source=source.replace("ipairs(state.wells[state.kind])","ipairs(referenceWell(state,state.kind))")
source=source.replace("    local tokens=Theme.officialAssets.stsCardReference\n    local rarity=tokens.rarity[key]", "    referenceRarityMaterials(state)\n    local tokens=Theme.officialAssets.stsCardReference\n    local rarity=tokens.rarity[key]")
source=source.replace("    local count=previous and math.max(#profiles[previous],#geometry) or #state.frameParts", "    local parts=referenceFrame(state)\n    local count=previous and math.max(#profiles[previous],#geometry) or #parts")
source=source.replace("moveReferencePart(state.frameParts[i],geometry[i]", "moveReferencePart(parts[i],geometry[i]")
out=p/'lazy-material/abyss_card_skin.lua'
out.parent.mkdir(exist_ok=True)
out.write_text(source)
