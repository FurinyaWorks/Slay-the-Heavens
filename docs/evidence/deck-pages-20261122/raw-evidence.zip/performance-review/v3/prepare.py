from pathlib import Path
import re
p=Path(__file__).parent
common=p.parent
base=(p/'snapshot/game_ui_fixture.lua').read_text()
prelude=(common/'instrumented-fixture.lua').read_text().split("local advanceShop",1)[0]
metrics={'GetChild':'child','GetChildren':'children','SetVisible':'visible','SetSizeDelta':'size','SetAnchoredPosition':'position','SetImage':'image','SetAnchorMin':'anchor','SetAnchorMax':'anchor','SetPivot':'anchor','SetLocalScale':'scale','SetLocalRotation':'rotation','AddCursorEventListener':'cursorBind','AddNavigationEventListener':'navBind','RemoveNavigationEventListener':'navUnbind','SetControllerNavigation':'navLink'}
def make(numbered):
    source=prelude+base
    if numbered:
        for method,col in metrics.items():
            source=re.sub(r'^('+rf'function Control:{method}' + r'\([^\n]*?\))',lambda m:m[0]+f" count(self,'{col}');",source,count=1,flags=re.M)
        source=source.replace("    engineAlive[control]=false","    count(control,'destroyNodes')\n    engineAlive[control]=false")
        source=source.replace("        sizeDeltaX = spec.size and spec.size[1], sizeDeltaY = spec.size and spec.size[2] }","""        sizeDeltaX = spec.size and spec.size[1], sizeDeltaY = spec.size and spec.size[2] }
    if spec.name=='deckPanel' or parent and tracked[parent] then
        tracked[self]=true
        count(self,'createNodes')
    end""")
        source=source.replace("parent.children['nativeBrowserCard'..serial]=box","parent.children['nativeBrowserCard'..serial]=box\n            count(box,part and 'createPart' or 'createRoot')")
        source=source.replace("        destroy=function(box)\n            for key", "        destroy=function(box)\n            count(box,'destroyRoot')\n            for key")
        source=source.replace("            self.itemCount, self.refreshCallback = amount, fn","""            count(self,'gridRefresh')
            self.itemCount, self.refreshCallback = amount, fn""")
        source=source.replace("            self.refreshCallback(self.items[slot], index)","""            count(self,'gridFill')
            self.refreshCallback(self.items[slot], index)""")
    source=source.replace("    GameUI = {new=newGameUI},","    GameUI = {new=newGameUI},\n    measured=measured,")
    return source
(p/'instrumented-fixture.lua').write_text(make(True))
(p/'lean-fixture.lua').write_text(make(False))
run=(common/'run.lua').read_text()
run=run.replace("local F=dofile(directory..(counted and '/instrumented-fixture.lua' or '/lean-fixture.lua'))","""local v3=os.getenv('TARGET')~='baseline'
local fixtures=v3 and directory or directory..'/..'
local F=dofile(fixtures..(counted and '/instrumented-fixture.lua' or '/lean-fixture.lua'))""")
run=run.replace("local probeEligibleCalls,maxCreateMs,forcedCreate=0,0,tonumber(os.getenv('SLOW_CREATE_MS'))","""local probeEligibleCalls,maxCreateMs,forcedCreate=0,0,tonumber(os.getenv('SLOW_CREATE_MS'))
local atomic""")
run=run.replace("'navLink','createNodes'", "'navLink','navUnbind','createNodes'").replace("'createRoot','destroyRoot'", "'createRoot','createPart','destroyRoot'")
run=run.replace("    if candidate then\n        local factory=F.deckBrowserFactory()","    if candidate then\n        local factory=platform.deckBrowser")
run=run.replace("function factory.create(parent)","function factory.create(parent,part)").replace("local result=original(parent)","local result=original(parent,part)")
run=run.replace("            maxCreateMs=math.max(maxCreateMs,(os.clock()-before)*1000)","""            local elapsed=(os.clock()-before)*1000
            maxCreateMs=math.max(maxCreateMs,elapsed)
            if atomic then atomic[#atomic+1]=(part and part.name or 'root')..'='..elapsed end""")
run=run.replace('    host,root=F.fixture(nil,function()return true end)',"    local cursor=os.getenv('TOUCH')=='1' and {CursorDown='down',CursorUp='up',CursorExit='exit',\n        CursorEndDrag='dragEnd',CursorDrag='drag',CursorEnter='enter'} or nil\n    host,root=F.fixture(nil,function()return true end,nil,cursor,nil,nil,nil,nil,candidate and F.deckBrowser() or nil)")
run=run.replace("    probeEligibleCalls,maxCreateMs=0,0","    probeEligibleCalls,maxCreateMs=0,0\n    atomic={}")
run=run.replace("    print('ROW", """    if #atomic>0 then print('ATOMS\t'..iteration..'\t'..name..'\t'..table.concat(atomic,'\t')) end
    atomic=nil
    print('ROW""")
(p/'run.lua').write_text(run)
matrix=(common/'run-matrix.py').read_text().split("elif selection=='ablation':",1)[0]
matrix=matrix.replace("here=Path('/workspace/scratch/work/performance-review')","here=Path(__file__).parent")
matrix=matrix.replace("target:here.parent/path","target:here.parent.parent/path")
matrix=matrix.replace("'BASELINE'", "'BASELINE'")
matrix=matrix.replace("here/('baseline-generated' if target=='baseline' else 'snapshot/generated')","(here.parent if target=='baseline' else here)/('baseline-generated' if target=='baseline' else 'snapshot/generated')")
matrix=matrix.replace("'WARM\\t'","'WARM\\t','ATOMS\\t'")
(p/'run-matrix.py').write_text(matrix)
