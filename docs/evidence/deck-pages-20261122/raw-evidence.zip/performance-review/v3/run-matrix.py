import os
from pathlib import Path
import re
import subprocess
import sys

here=Path(__file__).parent
dirs = {
    'baseline': Path(os.getenv('PERF_BASE_WORKTREE', str(here.parent.parent/'deck-baseline'))),
    'candidate': Path(os.getenv('PERF_CANDIDATE_WORKTREE', str(here.parent.parent/'deck-pages'))),
}
def execute(target,profile,amount,samples,counts,session,mode='',overlays=''):
    environ={**os.environ,'PROBE':str(here),'TARGET':target,'PROFILE':profile,'BUILD':str((here.parent if target=='baseline' else here)/('baseline-generated' if target=='baseline' else 'snapshot/generated')),
      'AMOUNT':str(amount),'COUNTS':str(counts),'SAMPLES':str(samples),'REVISIT':'0' if not counts else '1'}
    if target!='baseline':
        environ['COMMON_SOURCE']=str(here/'snapshot/source')
        environ['SOURCE']=environ['COMMON_SOURCE']
    if mode=='prewarm':
        environ['WARM_COMPARE']='1'
    if mode=='slow-native':
        environ['SLOW_CREATE_MS']='7'
    if mode=='destroy':
        environ['DESTROY_GRID']='1'
    if overlays:
        environ['SOURCE']=str(here/overlays)
    proc=subprocess.run(['luatex','--luaonly',str(here/'run.lua')], cwd=dirs['baseline' if target=='baseline' else 'candidate'],
      env=environ, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    logfile=here/f'{session}-{target}-{profile}-{amount}-{counts}-{mode}.log'
    logfile.write_text(proc.stdout)
    if proc.returncode!=0:
        raise RuntimeError(f'{target} {profile} {amount} {session}: {proc.stdout[-900:]}')
    for line in proc.stdout.splitlines():
        if line.startswith(('CLOCK\t','FIELDS\t','ROW\t','WARM\t','ATOMS\t')):
            print(f'{session}\t{line}',flush=True)
selection=sys.argv[1]
if selection=='timing':
    for session in range(1,7):
        targets=('baseline','candidate') if session%2 else ('candidate','baseline')
        for profile,amount in [('controller',20),('keyboard',75)]:
            for target in targets:
                execute(target,profile,amount,6,0,session)
elif selection=='count':
    for profile in ('controller','keyboard'):
        for amount in (0,1,7,10,11,20,75,250):
            for target in ('baseline','candidate'):
                execute(target,profile,amount,1,1,selection)
    for target in ('baseline','candidate'):
        execute(target,'controller',20,1,1,selection,'destroy')
