local build=assert(os.getenv('DECK_REVIEW_BUILD'))
package.path=build..'/?.lua;src/lua/?.lua;tests/lua/?.lua;'..package.path
local Fixture=dofile('tests/lua/support/game_ui_fixture.lua')
local Gate=require('abyss_page_reveal')
local Game=require('abyss_game_ui')
local Run=require('abyss_run')
local create=Game.new
local host,root
local device,focus=false,nil
local issueCount=0
local pointer={CursorDown='down',CursorUp='up',CursorExit='exit',CursorEndDrag='enddrag'}
local controller={events={Confirm='confirm',Cancel='cancel',Focus='focus',LostFocus='blur'},
    directions={Left='left',Right='right'},modes={Specified='specified'},
    isController=function()return device end,getFocus=function()return focus end,
    setFocus=function(control)focus=control end}
local function ready(intent)
    if intent.page~='deckPanel' then return true end
    local deck=host.deckUI
    if deck.gridReady and not deck.pending and not deck.calibrating then deck.gridReady() end
    if deck.prepareError then return false,deck.prepareError end
    return not (deck.pending or deck.calibrating or deck.pendingGrid)
end
local function check(label,cond)
    if cond then print('PASS '..label) else issueCount=issueCount+1;print('FAIL '..label) end
end
local function createCard(parent)
    local box=Fixture.control(assert(Fixture.Templates.AbyssBattlePileCard),parent)
    parent.serial=(parent.serial or 0)+1;parent.children['browser_card_'..parent.serial]=box
    return box
end
local function destroyCard(control)
    for key,child in pairs(control.parent.children) do
        if child==control then control.parent.children[key]=nil;return end
    end
end
Game.new=function(gameRoot,data,presentation,event,platform)
    platform.keyEvents={KeyboardCraftspersonKey38Down='previousKey',KeyboardCraftspersonKey39Down='nextKey'}
    platform.presentationReady=ready
    platform.presentationPage=require('abyss_card_art_runtime').setPresentationPage
    platform.deckBrowser={create=createCard,destroy=destroyCard,budget=.050}
    host=create(gameRoot,data,presentation,event,platform)
    return host
end
host,root=Fixture.fixture(nil,function()return true end,nil,pointer,false,nil,nil,controller,{create=createCard,destroy=destroyCard,budget=.050})
local function tick()
    host:update(1/60)
    require('abyss_card_art_runtime').update()
    local published,changed=host.pageReveal:step(Gate.intent(host),1/60)
    -- Production OnUpdate refreshes after the reveal changes state.
    if published or changed then host:refresh() end
end
local function settle()
    for turn=1,25 do tick();if not host.pageReveal:covered() then return true end end
    return false
end
local function cloneCards(catalog,amount)
    local cards={}
    for i=1,amount do
        cards[i]=Fixture.Combat.copy(catalog[(i-1)%#catalog+1])
        cards[i].uid=1000+i
        cards[i].upgraded=i%4==0
    end
    return cards
end
local function tap(control,id)
    local ev={touchId=id}
    if control.listeners.down then control.listeners.down(ev) end
    if control.listeners.up then control.listeners.up(ev) end
    return control.listeners.click(ev)
end
local function nav(control,name)
    if not host.controller:focus(control) then return false end
    host.controller:tick()
    return control.navigationListeners[name or 'confirm']()
end
local function positions(container)
    local found={}
    for _,cell in ipairs(container:GetChildren()) do
        local child=cell:GetChild('hit')
        if cell.visible and child.raycastTarget~=false then found[cell.x..','..cell.y]=cell end
    end
    return found
end
local function visibleCount(lookup)
    local count=0
    for _ in pairs(lookup) do count=count+1 end
    return count
end
assert(settle());assert(host:start());assert(settle());assert(Fixture.confirmStart(host));assert(settle())
local deck=host.deckUI
local panel=root:GetChild('deckPanel')
local pager=panel:GetChild('pileGrid')
local previous=panel:GetChild('previous'):GetChild('hit')
local next=panel:GetChild('next'):GetChild('hit')
local pageHint=panel:GetChild('pageHint')
local returnHit=panel:GetChild('pileReturn'):GetChild('hit')
local run=host.run
local original=run.deck
run.deck=cloneCards(original,11)
assert(host:openDeck())
check('first feedback shows requested count and page before a card is created',pageHint.visible and pageHint.text:find('1/2') and pager.serial==nil)
check('previous disabled and next enabled',not previous.interactable and previous.raycastTarget==false and next.interactable)
check('read-only scroller replaced',pager.RefreshItems==nil and not panel:GetChild('grid').visible)
check('return can cancel preparation',tap(returnHit,1))
if not deck.visible then assert(settle());assert(host:openDeck()) end
check('first page reaches ready',settle())
check('first page has exactly 10 visible cards',visibleCount(positions(pager))==10)
local map=positions(pager)
for y=1,2 do
    for x=1,5 do check('5×2 coordinate '..x..','..y,map[(((x-1)-2)*177)..','..(155.5-(y-1)*237)]~=nil) end
end
local a=map['-354,155.5']
if a then
    local hit=a:GetChild('hit')
    hit.listeners.down({touchId=21})
    check('click next with card A held',tap(next,22))
    check('last page reaches ready',settle())
    check('last page has one valid slot',visibleCount(positions(pager))==1 and previous.interactable and not next.interactable)
    hit.listeners.up({touchId=21})
    check('stale touch up cannot open any rebound card',not hit.listeners.click({touchId=21}) and not deck.detailPages)
    check('left arrow uses the shared previous action',panel.keyListeners.previousKey() and settle() and deck.pageIndex==1)
    local old=positions(pager)['-354,155.5']:GetChild('hit')
    old.listeners.down({touchId=23})
    check('right arrow flips the shared page with a card held',panel.keyListeners.nextKey() and settle() and deck.pageIndex==2)
    old.listeners.up({touchId=23})
    check('old keyboard-crossing gesture invalidated',not old.listeners.click({touchId=23}) and not deck.detailPages)
    device=true;host:syncController()
    check('input device change keeps page two',deck.pageIndex==2)
    local last=positions(pager)['-354,155.5']
    if last then
        local lastHit=last:GetChild('hit')
        check('controller confirm opens detail',nav(lastHit))
        check('detail data matches last unique card',deck.cardDetail and deck.cardDetail.instance.uid==1011)
        check('detail can return via controller',settle() and nav(returnHit))
        check('detail back returns to page two',settle() and deck.pageIndex==2)
        check('detail back restores card focus',focus==lastHit)
    end
end
if deck.visible then assert(host:closeDeck());settle() end
check('warm reopen same entry',host:openDeck() and deck.pageIndex==2)
if deck.visible then
    settle()
    local costs=panel:GetChild('pileTools'):GetChild('cost'):GetChild('hit')
    device=false;host:syncController()
    check('sort resets page',tap(costs,30) and deck.pageIndex==1)
    settle()
    local power=panel:GetChild('filterPower'):GetChild('hit')
    check('filter stays available in permanent deck',power.parent.visible and tap(power,31))
    check('filtered empty state is visible with zero pages',panel:GetChild('pileChrome'):GetChild('empty').visible and pageHint.text:find('0/0'))
    check('filtered empty reaches ready',settle())
end
if deck.visible then host:closeDeck();settle() end
-- The top of draw is its last physical element, independent of page preparation.
assert(Run.startCombat(run,'cultist_solo'))
run.relics={'frozen_eye'}
run.combat.draw=cloneCards(original,11);run.combat.discard=cloneCards(original,7);run.combat.exhaust={}
host:refresh();settle()
check('draw enters through Host',host:openDeck('draw'))
if deck.visible then
    settle()
    check('Frozen Eye first page begins at actual next draw',deck.cards[1].uid==1011 and run.combat.draw[1].uid==1001)
    if not host.pageReveal:covered() then tap(next,40);settle() end
    host:closeDeck();settle()
end
check('discard switches back to page one',host:openDeck('discard') and deck.pageIndex==1)
if deck.visible then host:closeDeck();settle() end
check('empty exhaust shows empty and stays usable',host:openDeck('exhaust') and not deck.pendingGrid and deck.pageCount==0 and settle())
if deck.visible then host:closeDeck();settle() end
print('PRODUCT_REVIEW_FAILURES '..issueCount)
