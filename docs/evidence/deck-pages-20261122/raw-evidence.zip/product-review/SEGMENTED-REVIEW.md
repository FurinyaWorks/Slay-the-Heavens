# 正式 V3 分段牌面独立复审

## 结果

对同一次正式生成的分段与未分段模板做结构对比。每段挂在原层、尺寸完全相同、位移为零。展平五个同尺寸包装后，子树与未分段版本深度相等，唯一例外是保留但始终隐藏的 `nativePlayableRim` 移除了内部 40 个 Image 以及五个 Container。原整张牌 356 个节点。分段后含五个新包装共 316 个节点。

| 原生创建单元 | 节点 |
| --- | ---: |
| 主根 | 58 |
| 背底 | 42 |
| 横幅 | 71 |
| 轮廓批次 0 | 51 |
| 轮廓批次 1 | 51 |
| 轮廓批次 2 | 43 |

分段的真实 Host 交互、0/1/7/10/11/20/75/250 张矩阵、真实 OnStart/OnUpdate/OnDestroy 的绑定与未绑定生成版夹具均通过。冷开达到十根和五十段后，翻页、暖开和详情切换累计创建数不变。卡 A 按下后用箭头或第二指翻页，旧抬起都被拒绝。

## 视觉证据

`split-visual` 保存分段图、原始 Host 模型和比较结果。对照由同一代码及数据通过展平模板夹具生成，按逻辑牌面位置固定离线绘制顺序。开场反馈、十张首页、一张尾页、详情和筛选空态，五张 1280×720 舞台图与展平模式分别为 0 个差异像素。证据是仓库 PIL 几何与文字诊断，未知原生纹理仍标 ID。原生容器锚定、覆盖、渲染和实际显示时间仍待同候选实机。

## 复现

```sh
review=/workspace/scratch/work/product-review
node scripts/build-lua-data.mjs data "$review/segmented/abyss_data.lua"
node scripts/build-ui.mjs "$review/segmented" --official-assets --refined-release-monsters --native-page-lifecycle
for c in segmented-product segmented-matrix segmented-native-smoke segmented-unbound-smoke; do
  DECK_REVIEW_BUILD="$review/segmented" luatex --luaonly "$review/$c.lua"
done
```
