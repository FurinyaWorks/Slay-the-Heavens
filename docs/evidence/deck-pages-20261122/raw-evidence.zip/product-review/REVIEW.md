# 牌库产品与视觉独立复审

开发基线为 `develop@00229683d0d38660c98ced2f4a41e89d84fc5e4e`。研究参考为 `release/v2.0.0@013bdffb7d4767075d7ebcf0be9eacd275bfbe89`。复审在开发分支未提交阶段发起，本记录对应各脚本旁的日志。筹备工作树始终由主执行者修改。

## 已复现并复测

- 第一版新池的 Grid 校准标志未清除。真实 Host 造齐十张后仍卡在准备门禁。修后 `product.lua` 通过正式布局首屏和空结果发布。
- 第一版返回仍被全屏物理盖板及控制器条件挡住。修后 Host 以局部盖板发布首反馈，返回可立即取消。官方客户端的实际命中派发待验。
- 第一版详情返回在盖板阻断聚焦时丢掉待恢复位置。修后手柄从第 2 页进入最后一张，返回复原同页和该物理控件焦点。
- 首屏十个根坐标恰为 5×2。边界按钮和尾页空槽不可命中。用第二指翻页期间保持卡 A 的按下，旧抬起及 Click 被拒绝。新手势可以详情浏览。
- 混合阵容逐页覆盖 0、1、7、10、11、20、75 和 250 张，无 UID 合并。筛选和排序归第一页，重开恢复现页。初始牌组本地 UID、Frozen Eye 的真实顶牌、←/→ 翻页期间的旧手势拒绝与列表缩短后的页码夹取均通过 Host 验证。临时费用与伤害增长的文本与完整详情通过。
- 原有真实 `controller_host.lua` 从地图/战斗出牌、奖励到强制多选回归通过。矩阵也验证了强制选择不可取消、可选选择返回 token 和 0、未满足 required 时不可确认。旧 Grid 的静置扫描断言需要更新；临时改为 0 后在原测试第 120 行发现旧详情切 scope 依赖脏标记，主执行者将优化限制在新浏览池后，七组旧控制器生命周期用例均复测通过。
- 实际 `abyss_ui.lua` 的 OnStart/OnUpdate/OnDestroy 通过注入候选模板 ID 的原生 API fixture。首反馈的第一次更新仍零创建，10 张后翻页、暖开无新创建。

## 视觉证据

`visual` 包含候选首反馈、首页、末页、详情及空滤结果和 develop 截图对照。PNG 来自仓库同款 PIL 诊断，运行生成的布局和实际 Lua，未知原生纹理仍以 id 标记。候选的舞台范围和可见 deckPanel 文本无栅格尺寸溢出报警。置灰、焦点、圆角颜色、原生字体、实际像素显示和设备延迟仍须真实客户端复核。

研究快照的地图四态共享和放大详情在开发基线有实际源码差异。正式地图返回当时生成四份几何相同的 16 节点树。分页按钮的状态几何也有复用空间，Pressed 有 0.96 缩放，压缩时应保真。浏览卡的动态费用 Halo 原版明确隐藏，新池修后继续保持。

## 本机复现

从候选工作树执行以下命令。示例输出目录为独立工作区，不写跟踪文件。

```sh
review=/workspace/scratch/work/product-review
node scripts/build-lua-data.mjs data "$review/official/abyss_data.lua"
node scripts/build-ui.mjs "$review/official" --official-assets --refined-release-monsters --native-page-lifecycle
DECK_REVIEW_BUILD="$review/official" luatex --luaonly "$review/product.lua"
DECK_REVIEW_BUILD="$review/official" luatex --luaonly "$review/matrix.lua"
DECK_REVIEW_BUILD="$review/official" luatex --luaonly "$review/native-smoke.lua"
```
