from pathlib import Path
import gzip,json,hashlib
p=Path('tests/helpers/item-post697-ci-source.json.gz');storage=json.loads(gzip.decompress(p.read_bytes()));wanted=storage['sourceTable'];found={};pack=storage['packet']
for archive in sorted(pack['immutableArchives']):
 if archive=='tests/helpers/item-post697-source.json.gz':continue
 raw=Path(archive).read_bytes();assert hashlib.sha256(raw).hexdigest()==pack['immutableArchives'][archive]
 try:root=json.loads(gzip.decompress(raw))
 except (UnicodeDecodeError,json.JSONDecodeError):continue
 def walk(value,path):
  if isinstance(value,dict):
   for key,item in value.items():
    if key=='source'and isinstance(item,str):
     k=hashlib.sha256(item.encode('utf8')).hexdigest()
     if k in wanted and k not in found:
      assert wanted[k]==item,'same hash different bytes';found[k]=dict(kind='archive-source',archive=archive,archiveSha256=pack['immutableArchives'][archive],jsonPath=path+[key])
    if isinstance(item,(dict,list)):walk(item,path+[key])
  elif isinstance(value,list):
   for i,item in enumerate(value):
    if isinstance(item,(dict,list)):walk(item,path+[i])
 walk(root,[])
refs={**storage,'storageSchemaVersion':2,'codec':'sha256-exact-utf8-archive-source','sourceTable':{k:found.get(k,value)for k,value in wanted.items()}};data=gzip.compress((json.dumps(refs,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0)
r=dict(status='read-only candidate measurement',uniqueSources=len(wanted),exactOldArchiveAtoms=len(found),newLiteralAtoms=len(wanted)-len(found),plainTableBytes=len(p.read_bytes()),referencedTableBytes=len(data),savedBytes=len(p.read_bytes())-len(data),references=found)
Path('.artifacts/item-post697/immutable-reuse-measure.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='references'}))
