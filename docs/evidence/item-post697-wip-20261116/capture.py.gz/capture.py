from pathlib import Path
import gzip,hashlib,json,re,subprocess
git=lambda *a:subprocess.check_output(['git','-c','core.commitGraph=false','-c','core.quotePath=false',*a])
sha=lambda b:hashlib.sha256(b).hexdigest()
views=dict(release='33d71575c5f186a1b54f7bf3e4f1826c145aa1d9',item='68a17f53dd4e8ebd72f6dc146ddc1652eb8b8cdd');product='249adac4baec43183e8c81fecda6047656b564c4'
def record(raw):
 s=raw.decode().replace('\r\n','\n');b=s.encode();return dict(source=s,sha256=sha(b),gitBlob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def inventory(paths):return dict(js=sorted(p for p in paths if re.fullmatch(r'tests/[^/]+\.test\.mjs',p)),lua=sorted(p for p in paths if re.fullmatch(r'tests/lua/[^/]+\.lua',p)))
files={name:set(git('ls-tree','-r','--name-only',commit).decode().splitlines())for name,commit in views.items()}
changed=set().union(*(set(git('diff','--name-only',commit,product).decode().splitlines())for commit in views.values()))|set(git('diff','--name-only',product).decode().splitlines())
changed|={p.as_posix()for p in Path('tests/helpers').glob('item-post697*.mjs')}
changed|={'src/lua/abyss_game_ui_input.lua','src/lua/abyss_game_ui_view.lua'}
changed={p for p in changed if (p.startswith(('src/','tests/','scripts/','config/','data/','.github/')) or p=='.gitattributes') and not p.endswith('.gz')}
changed.discard('tests/helpers/item-post697-ci-source.mjs')
p=dict(schemaVersion=1,normalization='LF',viewCommits=views,productCommit=product,currentTreeCommitted=False,viewInventories={name:inventory(paths)for name,paths in files.items()},currentInventory=inventory([f.as_posix()for f in Path('tests').rglob('*')if f.is_file()]),files={},immutableArchives={})
for path in sorted(changed):p['files'][path]=dict(current=record(Path(path).read_bytes()),views={name:record(git('show',commit+':'+path))if path in files[name]else None for name,commit in views.items()})
common=Path(git('rev-parse','--git-common-dir').decode().strip()).resolve();restored=[]
for path in sorted(Path('tests/helpers').rglob('*.gz')):
 if path.as_posix()=='tests/helpers/item-post697-ci-source.json.gz':continue
 raw=path.read_bytes()
 if raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1]);raw=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes();assert len(raw)==size and sha(raw)==oid;path.write_bytes(raw);restored.append(dict(path=path.as_posix(),oid=oid,size=size))
 p['immutableArchives'][path.as_posix()]=sha(raw)
# One thin packet's lossless storage encoding. Semantic records stay complete.
from copy import deepcopy

def add_source(table,binding):
 key=binding['sha256'];source=binding['source'];body=source.encode('utf8')
 if key in table:assert table[key]==source,'same hash different exact UTF8 bytes'
 assert sha(body)==key,'source binding hash'
 table[key]=source
 return dict(sourceKey=key,sha256=key,gitBlob=binding['gitBlob'])

def encode(full):
 packet=deepcopy(full);table={}
 for row in packet['files'].values():
  row['current']=add_source(table,row['current'])
  row['views']={key:add_source(table,b)if b is not None else None for key,b in row['views'].items()}
 return dict(storageSchemaVersion=1,codec='sha256-exact-utf8',packet=packet,sourceTable=table)

def decode(stored):
 assert set(stored)=={'storageSchemaVersion','codec','packet','sourceTable'}
 assert stored['storageSchemaVersion']==1 and stored['codec']=='sha256-exact-utf8'
 assert stored['packet']['schemaVersion']==1
 table=stored['sourceTable'];used=set()
 for key,source in table.items():assert isinstance(source,str)and sha(source.encode('utf8'))==key,'same hash bytes'
 def bind(b):
  if b is None:return None
  assert set(b)=={'sourceKey','sha256','gitBlob'}
  key=b['sourceKey'];assert key==b['sha256']and key in table,'source reference'
  source=table[key];body=source.encode('utf8');assert sha(body)==b['sha256'];assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==b['gitBlob']
  used.add(key);return dict(source=source,sha256=b['sha256'],gitBlob=b['gitBlob'])
 full=deepcopy(stored['packet'])
 for row in full['files'].values():
  assert 'current'in row and row['current']is not None and 'views'in row
  assert set(row['views'])==set(full['viewCommits']),'explicit null or history reference'
  row['current']=bind(row['current']);row['views']={key:bind(value)for key,value in row['views'].items()}
 assert used==set(table),'no unreferenced atom'
 return full

plain=(json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode();normal=gzip.compress(plain,mtime=0);stored=encode(p);recovered=decode(stored);assert recovered==p,'every semantic field roundtrip'
assert(json.dumps(recovered,ensure_ascii=False,separators=(',',':'))+'\n').encode()==plain,'exact full serial roundtrip'
data=gzip.compress((json.dumps(stored,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0);Path('tests/helpers/item-post697-ci-source.json.gz').write_bytes(data)
roundtrip=dict(fullFieldsExact=True,fullSerializedBytesExact=True,normalGzipBytes=len(normal),tableGzipBytes=len(data),savedBytes=len(normal)-len(data),normalGzipSha256=sha(normal),tableGzipSha256=sha(data),fullSerializedSha256=sha(plain),uniqueSources=len(stored['sourceTable']),bindingChecks=[dict(path=path,currentSha256=row['current']['sha256'],currentGitBlob=row['current']['gitBlob'],views={name:None if value is None else dict(sha256=value['sha256'],gitBlob=value['gitBlob'])for name,value in row['views'].items()})for path,row in recovered['files'].items()])
Path('.artifacts/item-post697/storage-roundtrip.json').write_text(json.dumps(roundtrip,indent=2)+'\n')
leaf=Path('tests/helpers/item-post697-ci-source.mjs');text=leaf.read_text(encoding='utf8');marker='POST697_CI_SHA'
if marker not in text:
 old=json.loads(Path('.artifacts/item-post697/capture.json').read_text(encoding='utf8'))['sha256'];assert text.count(old)==1;text=text.replace(old,marker)
assert text.count(marker)==1;leaf.write_text(text.replace(marker,sha(data)),encoding='utf8',newline='\n')
receipt=dict(sha256=sha(data),bytes=len(data),bindings=len(p['files']),archives=len(p['immutableArchives']),currentInventory={k:len(v)for k,v in p['currentInventory'].items()},viewInventories={n:{k:len(v)for k,v in d.items()}for n,d in p['viewInventories'].items()},materialized=restored)
Path('.artifacts/item-post697/capture.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
