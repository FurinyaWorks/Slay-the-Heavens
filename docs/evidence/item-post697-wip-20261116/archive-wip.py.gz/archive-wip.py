from pathlib import Path
import gzip,json,hashlib
src=Path('.artifacts/item-post697');dst=Path('docs/evidence/item-post697-wip-20261116');dst.mkdir(parents=True,exist_ok=True);rows=[]
for p in sorted(src.iterdir()):
 if not p.is_file()or p.suffix not in ['.py','.mjs','.json','.log','.md','.lua']:continue
 raw=p.read_bytes();body=gzip.compress(raw,mtime=0);name=p.name+'.gz';(dst/name).write_bytes(body);rows.append(dict(path=name,rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),gitStoredBytes=len(body),gitStoredSha256=hashlib.sha256(body).hexdigest()))
(dst/'archive-manifest.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(dict(savedFiles=len(rows),storedBytes=sum(r['gitStoredBytes']for r in rows))))
