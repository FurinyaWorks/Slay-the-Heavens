from pathlib import Path
import subprocess,re,json
G=lambda *a:subprocess.check_output(['git','-c','core.quotePath=false',*a]);release='33d71575c5f186a1b54f7bf3e4f1826c145aa1d9';pat=re.compile(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> '+release+r'\n',re.S);seen={}
for p in G('diff','--name-only','--diff-filter=U').decode().splitlines():
 if p.startswith('backlog/'):continue
 s=Path(p).read_text(encoding='utf8');i=0
 def fix(m):
  global i
  i+=1;l,r=m.groups()
  if p=='tests/ci-complete-calibration.test.mjs':
   if i==1:
    l=l.replace("const rawBootstrapReadFileSync=itemTitleShadowBootstrapRead('release',rawReleaseReadFileSync);","const rawBootstrapReadFileSync=releaseSelectionMapCiRead(rawReleaseReadFileSync);").replace('const liveDiskReadFileSync=releaseItemTitleShadowCiRead(itemCheckpointRead);','const liveDiskReadFileSync=releaseBootstrapCiRead(rawBootstrapReadFileSync);')
    return r.splitlines(True)[0]+l
   return r
  if p=='tests/helpers/closeout-source-epoch.mjs':
   if i==1:return l+r
   return "export const preReleaseSelectionMapSourceEpoch=extendSessionMenuEpoch(releaseSourceEpoch);\nexport const preReleaseItemTitleShadowSourceEpoch=preReleaseSelectionMapSourceEpoch;\nexport const itemBeforeMapSourceEpoch=extendReleaseItemTitleShadowSource(preReleaseItemTitleShadowSourceEpoch);\nexport const sourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);\n"
  if p=='tests/helpers/copy-integration-source-closure.mjs':
   descriptor=l[:l.index('for(const row of releaseItemTitleShadowHelperCopies)')]
   return descriptor+r+"// Original item descriptor is historical; retain both production leaves.\nfor(const row of releaseItemTitleShadowHelperCopies.filter(row=>!row.path.endsWith('closeout-source-epoch.mjs'))){assert.equal(files[row.path]??null,row.before,'exact item leaf predecessor: '+row.path);files[row.path]=row.after;}\n"
  if p=='tests/helpers/integrated-ci-source.mjs':
   if i==1:return l+''.join(line for line in r.splitlines(True)if 'import {releaseBootstrapCiSource'not in line)
   return r
  if p=='tests/integrated-ci-source.cases.mjs':return l+r if i==1 else r
  if p=='tests/integration-source-epoch.test.mjs':return l+r
  if p=='tests/session-menu-navigation.test.mjs':
   if i==1:return "import {sourceEpoch,releaseSourceEpoch,preReleaseItemTitleShadowSourceEpoch,preReleaseSelectionMapSourceEpoch} from './helpers/closeout-source-epoch.mjs';\n"
   return l+r if i==2 else r
  if p=='tests/sts-style-source-epoch.test.mjs':
   if i==1:return l+r
   return " {\n"+l+" assert.deepEqual(rawJs,integratedCiProof.inventory);assert.deepEqual(rawLua,integratedCiProof.luaInventory);\n }\n"+r
  raise AssertionError(p)
 s,n=pat.subn(fix,s);assert n and'<<<<<<<'not in s,(p,n)
 if p=='tests/integrated-ci-source.cases.mjs':
  assert s.count(' })(releaseRead);')<=1
  s=s.replace(' })(releaseRead);\n','').replace(' })(releaseRead)\n','')
 if p=='tests/helpers/integrated-ci-source.mjs':s=s.replace(' source=itemCiRepairSource(path,source);\n','')
 if p=='tests/ci-complete-calibration.test.mjs':
  old=G('show','68a17f53:tests/ci-complete-calibration.test.mjs').decode();start=old.index("test('release item-title-shadow raw Full");end=old.find('\ntest(',start+1);s=s.rstrip()+'\n\n'+old[start:end if end>=0 else len(old)]
 Path(p).write_text(s,encoding='utf8',newline='\n');seen[p]=n
Path('.artifacts/item-post697/conflict-resolution.json').write_text(json.dumps(seen,indent=2)+'\n');print(json.dumps(seen))
