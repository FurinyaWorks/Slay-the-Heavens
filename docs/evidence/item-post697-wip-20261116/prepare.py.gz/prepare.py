from pathlib import Path
import subprocess,json,gzip,hashlib,re
item='68a17f53dd4e8ebd72f6dc146ddc1652eb8b8cdd';release='33d71575c5f186a1b54f7bf3e4f1826c145aa1d9';product='249adac4baec43183e8c81fecda6047656b564c4';R=Path('.artifacts/item-post697');G=lambda *a:subprocess.check_output(['git','-c','core.quotePath=false',*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,s):Path(p).write_text(s,encoding='utf8',newline='\n')
def edit(p,a,b):
 s=Path(p).read_text(encoding='utf8');assert s.count(a)==1,(p,a[:90]);put(p,s.replace(a,b))
def row(raw):
 s=raw.decode().replace('\r\n','\n');b=s.encode();return dict(source=s,sha256=sha(b),gitBlob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
old=json.loads(gzip.decompress(Path('tests/helpers/release-item-title-shadow-source.json.gz').read_bytes()));runtime=sorted(old['current']);maps=['src/lua/abyss_game_ui_input.lua','src/lua/abyss_game_ui_view.lua']
p=dict(schemaVersion=1,normalization='LF',baseCommit=release,itemCommit=item,itemProductCheckpoint='df5ad3dc3b8b02e56d93a4dfe394b103dc0498e9',currentCommit=product,currentTreeCommitted=True,before={},current={},itemBeforeMap={})
for path in runtime:p['before'][path]=row(G('show',release+':'+path));p['current'][path]=row(G('show',product+':'+path));assert G('rev-parse',item+':'+path)==G('rev-parse',product+':'+path)
for path in maps:p['itemBeforeMap'][path]=row(G('show',item+':'+path));assert G('rev-parse',release+':'+path)==G('rev-parse',product+':'+path)
data=gzip.compress((json.dumps(p,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0);Path('tests/helpers/item-post697-source.json.gz').write_bytes(data)
source=Path('../goal-v2-hand-post697-1116/tests/helpers/hand-post697-source.mjs').read_text(encoding='utf8').replace('handPost697','itemPost697').replace('HandPost697','ItemPost697').replace('hand-post697','item-post697').replace('hand post697','item post697').replace('hand-values','item/title/shadow').replace('handEpoch','itemEpoch').replace('handProductCheckpoint','itemProductCheckpoint').replace('handBeforeMap','itemBeforeMap').replace('handCommit','itemCommit').replace('mobileHandProducers','releaseItemTitleShadowProducers').replace('const prior=original.proof,hand=itemEpoch.proof;','const prior=original.proof,item=itemEpoch.proof;').replace('hand.','item.').replace('complete original hand source domain','complete original item source domain').replace('actual hand values and landed Map union','actual item/title/shadow and landed Map union')
source=re.sub(r"assert.equal\(hash\(bytes\),'[a-f0-9]{64}'", "assert.equal(hash(bytes),'"+sha(data)+"'",source);put('tests/helpers/item-post697-source.mjs',source)
edit('tests/helpers/closeout-source-epoch.mjs',"import {extendReleaseItemTitleShadowSource} from './release-item-title-shadow-source.mjs';","import {extendReleaseItemTitleShadowSource} from './release-item-title-shadow-source.mjs';\nimport {extendItemPost697Source} from './item-post697-source.mjs';")
edit('tests/helpers/closeout-source-epoch.mjs','export const sourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);','export const preItemPost697SourceEpoch=extendReleaseSelectionMapSource(preReleaseSelectionMapSourceEpoch);\nexport const sourceEpoch=extendItemPost697Source(preItemPost697SourceEpoch,itemBeforeMapSourceEpoch);')
rows=[]
for path in ['tests/helpers/closeout-source-epoch.mjs','tests/helpers/item-post697-source.mjs','tests/helpers/item-post697-source.json.gz']:
 rows.append(dict(path=path,before=sha(G('show',release+':'+path))if path.endswith('closeout-source-epoch.mjs')else None,after=sha(Path(path).read_bytes())))
edit('tests/helpers/copy-integration-source-closure.mjs','const inside=(root,path)=>','export const itemPost697HelperCopies='+json.dumps(rows,separators=(',',':'))+";\nfor(const row of itemPost697HelperCopies){assert.equal(files[row.path]??null,row.before,'exact item post697 helper predecessor: '+row.path);files[row.path]=row.after;}\nconst inside=(root,path)=>")
leaf=Path('../goal-v2-hand-post697-1116/tests/helpers/hand-post697-ci-source.mjs').read_text(encoding='utf8').replace('handPost697','itemPost697').replace('HandPost697','ItemPost697').replace('hand-post697','item-post697').replace('hand post697','item post697').replace("hand:'4ace45fedbce5fb0507f793bca0e7b5c8992e061'","item:'"+item+"'").replace('d956df3e8b429ad4d4042d9489108000fb9b327b',product)
leaf=re.sub(r"assert.equal\(hash\(bytes\),'[a-f0-9]{64}'","assert.equal(hash(bytes),'POST697_CI_SHA'",leaf)
codec="""// This one packet's storage encoding only. It does not authorize reads.
export function decodeItemPost697Storage(storage){
 assert.equal(storage.storageSchemaVersion,1,'item packet storage schema');
 assert.equal(storage.codec,'sha256-exact-utf8','item packet storage codec');
 assert.deepEqual(Object.keys(storage).sort(),['codec','packet','sourceTable','storageSchemaVersion']);
 assert.equal(storage.packet?.schemaVersion,1,'item packet semantic schema');
 assert(storage.sourceTable&&typeof storage.sourceTable==='object'&&!Array.isArray(storage.sourceTable));
 const used=new Set();
 for(const [key,value]of Object.entries(storage.sourceTable)){
  assert.equal(typeof value,'string','source table exact UTF8 text');
  assert.equal(Buffer.from(value,'utf8').toString('utf8'),value,'source table UTF8 roundtrip');
  assert.equal(hash(value),key,'source table same-hash bytes');
 }
 const binding=b=>{
  if(b===null)return null;
  assert(b&&typeof b==='object'&&!Array.isArray(b),'explicit binding or null');
  assert.deepEqual(Object.keys(b).sort(),['gitBlob','sha256','sourceKey']);
  assert.equal(b.sourceKey,b.sha256,'binding source reference hash');
  assert(Object.hasOwn(storage.sourceTable,b.sourceKey),'binding source reference exists');
  const source=storage.sourceTable[b.sourceKey];used.add(b.sourceKey);
  assert.equal(hash(source),b.sha256,'decoded binding exact hash');
  assert.equal(createHash('sha1').update(`blob ${Buffer.byteLength(source)}\\0`).update(source).digest('hex'),b.gitBlob,'decoded binding exact Git blob');
  return{source,sha256:b.sha256,gitBlob:b.gitBlob};
 };
 const files=Object.fromEntries(Object.entries(storage.packet.files).map(([path,row])=>{
  assert(Object.hasOwn(row,'current')&&Object.hasOwn(row,'views'),'complete current and history record');
  assert.deepEqual(Object.keys(row.views).sort(),Object.keys(storage.packet.viewCommits).sort(),'explicit null or exact history domain');
  return[path,{current:binding(row.current),views:Object.fromEntries(Object.entries(row.views).map(([name,value])=>[name,binding(value)]))}];
 }));
 assert.deepEqual([...used].sort(),Object.keys(storage.sourceTable).sort(),'no unreferenced source atoms');
 return{...storage.packet,files};
}
const stored=JSON.parse(gunzipSync(bytes));
const packet=decodeItemPost697Storage(stored);
"""
leaf=leaf.replace('const packet=JSON.parse(gunzipSync(bytes));',codec).replace('export const itemPost697CiPacket=freeze(packet);','export const itemPost697StoredPacket=freeze(stored);\nexport const itemPost697CiPacket=freeze(packet);')
put('tests/helpers/item-post697-ci-source.mjs',leaf)
(R/'production.json').write_text(json.dumps(dict(item=item,release=release,product=product,sha256=sha(data),bytes=len(data),productOwners=len(runtime)),indent=2)+'\n');print(json.dumps(dict(product=product,productOwners=len(runtime),productionBytes=len(data))))
