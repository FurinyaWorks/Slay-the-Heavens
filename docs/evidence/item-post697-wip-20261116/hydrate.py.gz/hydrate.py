from pathlib import Path
import re,hashlib,subprocess,json
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir']).decode().strip()).resolve();rows=[]
for p in Path('tests/helpers').rglob('*.gz'):
 raw=p.read_bytes()
 if not raw.startswith(b'version https://git-lfs.github.com/spec/v1'):continue
 s=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',s)[1];size=int(re.search(r'size (\d+)',s)[1]);body=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes();assert len(body)==size and hashlib.sha256(body).hexdigest()==oid;p.write_bytes(body);rows.append(dict(path=p.as_posix(),oid=oid,size=size))
Path('.artifacts/item-post697/materialized.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))

