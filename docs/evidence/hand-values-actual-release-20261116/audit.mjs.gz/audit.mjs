import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {sourceEpoch,preMobileHandSourceEpoch} from '../../tests/helpers/closeout-source-epoch.mjs';
import {mobileHandSourcePacket} from '../../tests/helpers/mobile-hand-source.mjs';
import {mobileHandCiPacket,assertMobileHandCiCurrent} from '../../tests/helpers/mobile-hand-ci-source.mjs';
import {assertIntegratedCurrent} from '../../tests/helpers/integrated-ci-source.mjs';
const original='12f0981ca55017ade6f7be24f50889373b7996f7',merged='a0bcfdfb9b1bfe1934da1ba5e46f861e90af1821',release='1cc5479b713edab6fd26db4e20f8eb22b7401cb2',oldBase='b67226945c2be47c8fff31f1362412b973f68875',originalProduct='da45571bb8e667a2ad9910acf60cafd8721839d4';
const git=(...args)=>execFileSync('git',['-c','core.commitGraph=false','-c','core.quotePath=false',...args],{maxBuffer:32*1024*1024});
const oid=ref=>git('rev-parse',ref).toString().trim(),hash=b=>createHash('sha256').update(b).digest('hex'),norm=b=>Buffer.from(b.toString().replaceAll('\r\n','\n'));
assert.equal(oid(oldBase+'^{tree}'),oid(release+'^{tree}'));assert.equal(oid(merged+'^{tree}'),oid(original+'^{tree}'));
git('merge-base','--is-ancestor',original,merged);git('merge-base','--is-ancestor',release,merged);git('merge-base','--is-ancestor',oldBase,original);
const productPaths=git('diff','--name-only','36b9b157ee6f05b65eb9f1da7e2978647d36c210',originalProduct).toString().trim().split('\n');assert.equal(productPaths.length,8);
for(const path of productPaths){assert.equal(oid(original+':'+path),oid(originalProduct+':'+path),path+' original eight Git blobs');assert.equal(hash(norm(readFileSync(path))),hash(git('show',originalProduct+':'+path)),path+' unchanged original eight disk inputs');}
assert.equal(oid(merged+':src/lua'),oid(originalProduct+':src/lua'));
for(const path of ['tests/helpers/mobile-hand-source.mjs','tests/helpers/mobile-hand-source.json.gz','tests/helpers/closeout-source-epoch.mjs','tests/helpers/copy-integration-source-closure.mjs'])assert.equal(hash(path.endsWith('.gz')?readFileSync(path):norm(readFileSync(path))),hash(git('show',original+':'+path)),path+' production/copy helper unchanged');
for(const [path,row]of Object.entries(mobileHandSourcePacket.producers)){assert.equal(oid(row.commit+':'+path),mobileHandSourcePacket.current[path].gitBlob);assert.deepEqual(git('show','-s','--format=%P',row.commit).toString().trim().split(' '),row.parents);}
const oldBytes=git('show',merged+':tests/helpers/mobile-hand-ci-source.json.gz'),old=JSON.parse(gunzipSync(oldBytes));
for(const key of Object.keys(old))if(key!=='files')assert.deepEqual(mobileHandCiPacket[key],old[key],key+' original packet field');
let changed=[],added=[];
for(const [path,row]of Object.entries(mobileHandCiPacket.files)){
 if(!Object.hasOwn(old.files,path)){assert.equal(path,'tests/sts-style-source-epoch.test.mjs');assert.equal(row.before.source,git('show',oldBase+':'+path).toString().replaceAll('\r\n','\n'));assert.equal(row.beforeCommit,oldBase);added.push(path);continue;}
 assert.deepEqual(row.before,old.files[path].before,path+' original predecessor');assert.equal(row.beforeCommit,old.files[path].beforeCommit);
 if(row.current.sha256!==old.files[path].current.sha256)changed.push(path);
}
assert.deepEqual(changed,['tests/helpers/integrated-ci-source.mjs','tests/integrated-ci-source.cases.mjs']);assert.deepEqual(added,['tests/sts-style-source-epoch.test.mjs']);
const proof=sourceEpoch.proof;let currentBindings=0;
for(const [path,row]of Object.entries(proof.current))if(row!==null){assert.equal(readFileSync(path,'utf8').replaceAll('\r\n','\n'),row.source,path+' current disk binding');assert.equal(oid(merged+':'+path),row.gitBlob,path+' real current Git binding');currentBindings++;}
assert.deepEqual(proof.owners,preMobileHandSourceEpoch.proof.owners);assert.equal(proof.owners.length,116);
const code=readFileSync('tests/helpers/integrated-ci-source.mjs','utf8'),scope=code.slice(code.indexOf('export function assertIntegratedCurrent('),code.indexOf('export function extendIntegratedHelperClosure('));
assert(scope.includes('assertMobileHandCiCurrent(read)'));assert(scope.includes("mobileHandCiCheckedSource(path,read(path,'utf8'))"));assert(scope.indexOf('assertMobileHandCiCurrent(read)')<scope.indexOf("mobileHandCiCheckedSource(path,read(path,'utf8'))"));
assert(code.includes('source=mobileHandCiSource(path,source,undefined,read);'));assert(code.includes('prior=integratedSource(path,text,target,read);'));
assertMobileHandCiCurrent();assertIntegratedCurrent();
const result={status:'pass',original,merged,release,originalTree:oid(original+'^{tree}'),mergeTree:oid(merged+'^{tree}'),actualBootstrapTree:oid(release+'^{tree}'),oldBootstrapTree:oid(oldBase+'^{tree}'),unchangedSourceTree:oid(merged+':src/lua'),unchangedProductFiles:productPaths,productionBindings:currentBindings,ownersBefore:preMobileHandSourceEpoch.proof.owners.length,ownersCurrent:proof.owners.length,newOwners:[],originalActivePacketSha256:hash(oldBytes),changedBindings:changed,addedBindings:added,bindings:Object.keys(mobileHandCiPacket.files).length,archives:Object.keys(mobileHandCiPacket.immutableArchives).length,checkedCaller:'helpers/integrated-ci-source.mjs:assertIntegratedCurrent; complete same-raw-reader precondition',rawBefore:Object.fromEntries(Object.entries(mobileHandCiPacket.priorInventory).map(([k,v])=>[k,v.length])),rawCurrent:Object.fromEntries(Object.entries(mobileHandCiPacket.currentInventory).map(([k,v])=>[k,v.length]))};
writeFileSync('.artifacts/hand-values-final/audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
