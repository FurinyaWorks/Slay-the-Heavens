from pathlib import Path
import subprocess
source=subprocess.check_output(['git','show','13a3c70046391cadee86ecffb57ded3450906687:tests/integrated-ci-source.cases.mjs']).decode()
names=['enemy geometry historical CI reader','enemy geometry public CI source','enemy geometry current inventory','enemy geometry integrated reader and source']
path=Path('tests/integrated-ci-source.cases.mjs');text=path.read_text()
for name in names:
 start=source.index("test('"+name);end=source.find('\ntest(',start+1)
 block=source[start:]if end<0 else source[start:end]
 block=block.replace('actualEnemyGeometryReadFileSync','actualHandReadFileSync').replace('actualEnemyGeometryDiscoverJs','actualHandDiscoverJs').replace('enemyGeometry','mobileHand').replace('EnemyGeometry','MobileHand').replace('enemy geometry','mobile hand').replace('src/lua/abyss_battle_enemy_view.lua','src/lua/abyss_battle_card_view.lua').replace('src/lua/abyss_battle_targeting.lua','src/lua/abyss_battle_card_view.lua')
 block=block.replace("const production='src/lua/abyss_battle_card_view.lua';fault={path:other,kind:'missing'};", "const production='src/lua/abyss_battle_card_view.lua';fault={path:anchor,kind:'missing'};")
 text=text.rstrip()+'\n\n'+block.lstrip()
path.write_text(text,encoding='utf8',newline='\n')
