from pathlib import Path
path=Path('tests/sts-style-source-epoch.test.mjs');text=path.read_text()
before="import {discoverJs,jsPlanningWeights,timings} from '../scripts/ci-shards.mjs';"
assert text.count(before)==1;text=text.replace(before,before+"\nimport {mobileHandPriorInventory,assertMobileHandRawInventory} from './helpers/mobile-hand-ci-source.mjs';")
before=" const rawJs=discoverJs(),rawLua=readdirSync('tests/lua').filter(p=>p.endsWith('.lua')).map(p=>'tests/lua/'+p).sort();"
assert text.count(before)==1
after=""" const currentRaw={js:discoverJs(),lua:readdirSync('tests/lua').filter(p=>p.endsWith('.lua')).map(p=>'tests/lua/'+p).sort()},historical={};
 for(const [kind,paths]of Object.entries(currentRaw)){
  assertMobileHandRawInventory(paths,kind);
  historical[kind]=mobileHandPriorInventory(paths,kind,readFileSync);
  for(const path of paths.filter(path=>!historical[kind].includes(path))){
   assert.throws(()=>assertMobileHandRawInventory(paths.filter(p=>p!==path),kind),/inventory/);
   for(const value of [null,readFileSync(path,'utf8')+'\\n'])assert.throws(()=>mobileHandPriorInventory(paths,kind,(p,e)=>p===path?value:readFileSync(p,e)),/fresh complete integration source|replaceAll/);
  }
 }
 const {js:rawJs,lua:rawLua}=historical;"""
path.write_text(text.replace(before,after),encoding='utf8',newline='\n')
