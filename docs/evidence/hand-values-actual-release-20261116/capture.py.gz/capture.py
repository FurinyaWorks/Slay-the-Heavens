from pathlib import Path
import gzip,hashlib,json,re,subprocess
base='a0bcfdfb9b1bfe1934da1ba5e46f861e90af1821'
git=lambda *args:subprocess.check_output(['git','-c','core.commitGraph=false',*args])
sha=lambda b:hashlib.sha256(b).hexdigest()
def record(raw):
 text=raw.decode().replace('\r\n','\n');data=text.encode()
 return dict(source=text,sha256=sha(data),gitBlob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
name='tests/helpers/mobile-hand-ci-source.json.gz';oldbytes=git('show',base+':'+name);packet=json.loads(gzip.decompress(oldbytes));changed=[]
for path,row in packet['files'].items():
 current=record(Path(path).read_bytes())
 if current!=row['current']:row['current']=current;changed.append(path)
assert set(changed)<={'tests/helpers/integrated-ci-source.mjs','tests/integrated-ci-source.cases.mjs'},changed
added=[]
path='tests/sts-style-source-epoch.test.mjs'
before=record(git('show',packet['baseCommit']+':'+path));current=record(Path(path).read_bytes())
if before!=current:
 packet['files'][path]=dict(beforeCommit=packet['baseCommit'],before=before,current=current);added.append(path)
common=Path(git('rev-parse','--git-common-dir').decode().strip()).resolve();materialized=[]
for path,digest in packet['immutableArchives'].items():
 raw=Path(path).read_bytes()
 if raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
  text=raw.decode();oid=re.search(r'oid sha256:([a-f0-9]{64})',text)[1];size=int(re.search(r'size (\d+)',text)[1]);raw=(common/'lfs'/'objects'/oid[:2]/oid[2:4]/oid).read_bytes();assert sha(raw)==oid and len(raw)==size
  Path(path).write_bytes(raw);materialized.append(dict(path=path,oid=oid,size=size))
 assert sha(raw)==digest,path
data=gzip.compress((json.dumps(packet,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0);Path(name).write_bytes(data)
leaf=Path('tests/helpers/mobile-hand-ci-source.mjs');text=leaf.read_text();oldsha=sha(oldbytes)
if oldsha not in text:
 current=json.loads(Path('.artifacts/hand-values-final/capture.json').read_text())['currentPacketSha256'];assert text.count(current)==1;text=text.replace(current,oldsha)
assert text.count(oldsha)==1;leaf.write_text(text.replace(oldsha,sha(data)),encoding='utf8',newline='\n')
result=dict(originalPacketCommit=base,originalPacketSha256=oldsha,currentPacketSha256=sha(data),currentPacketBytes=len(data),changedBindings=changed,addedBindings=added,bindings=len(packet['files']),archives=len(packet['immutableArchives']),materializedInputs=materialized,rawBefore={k:len(v)for k,v in packet['priorInventory'].items()},rawCurrent={k:len(v)for k,v in packet['currentInventory'].items()})
Path('.artifacts/hand-values-final/capture.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
