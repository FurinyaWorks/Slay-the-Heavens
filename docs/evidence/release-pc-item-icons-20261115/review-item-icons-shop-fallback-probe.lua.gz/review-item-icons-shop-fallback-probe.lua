local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Run,Map,Nodes=require('abyss_run'),require('abyss_map'),require('abyss_nodes')
local host,root=F.fixture();assert(F.start(host))
local run,map=Run.new(F.Data,42),Map.generate(F.Data,42)
while not run.nodeFlow do
 local available=Map.available(map);assert(#available>0)
 for _,node in ipairs(available)do if node.type=='shop'then assert(Nodes.enter(run,map,node.id));break end end
 if not run.nodeFlow then assert(Map.choose(map,available[1].id))end
end
host.run,host.map=run,map;host.nodeUI.run,host.nodeUI.map=run,map
run.nodeFlow.relics[1].id='old_coin';host:refresh()
local icon=root:GetChild('nodePanel'):GetChild('shopView'):GetChild('relic1'):GetChild('icon')
local parent=icon.parent
local pool=parent:GetChild('iconArt')
assert(pool.visible and not icon.visible,'new old_coin semantic art must be painted before lookup loss')
parent.children.iconArt=nil
host:refresh()
print('ITEM_ICON_SHOP_FALLBACK_ACTUAL iconVisible='..tostring(icon.visible)..' image='..tostring(icon.imageId)..' poolUnavailable=true')
assert(icon.visible,'same-item shop relic must expose original icon when semantic pool lookup is unavailable')
print('ITEM_ICON_SHOP_FALLBACK_PASS')
