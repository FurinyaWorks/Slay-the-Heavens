local F=dofile('tests/lua/support/game_ui_fixture.lua')
local Run,Rewards=require('abyss_run'),require('abyss_relic_rewards')
local host,root=F.fixture();assert(F.start(host))
local run=host.run;run.nodeFlow=nil;run.phase='map';assert(Run.startCombat(run,'cultist_solo'))
run.phase='reward';run.rewards={manualContinue=true,gold=0,goldClaimed=true,cardResolved=true,cards={},relics={}}
for i,sourceId in ipairs({'Bronze Scales','Oddly Smooth Stone'})do
 local definition=assert(Rewards.definition(run,sourceId));assert(F.Theme.lowCostArt.relic.assets[definition.id])
 run.rewards.relics[i]={id=definition.id,sourceId=sourceId}
end
host:refresh()
local passed=0
for i,item in ipairs(run.rewards.relics)do
 local face=root:GetChild('battlePanel'):GetChild('potionHelp'):GetChild('relicReward'..i):GetChild('normal')
 local icon,pool=face:GetChild('rewardIcon'),face:GetChild('rewardIconArt')
 local ok=pool.visible and not icon.visible
 if ok then passed=passed+1 end
 print('ITEM_ICON_REWARD_ALIAS_ACTUAL id='..item.id..' sourceId='..item.sourceId..' poolVisible='..tostring(pool.visible)..' iconVisible='..tostring(icon.visible)..' image='..tostring(icon.imageId))
end
print('ITEM_ICON_REWARD_ALIAS_CASES '..passed..' 2')
assert(passed==2,'formal source aliases must paint distinct existing canonical recipes in both real reward rows')
print('ITEM_ICON_REWARD_ALIAS_PASS')
