local F=dofile('tests/lua/support/game_ui_fixture.lua')
local root=F.Viewport.apply(F.control({children=F.Layout}),1280,720)
local platform={imageSource='static',color=function(r,g,b,a)return{r=r,g=g,b=b,a=a}end}
local view=require('abyss_relic_view_ui').new(root:GetChild('relicPanel'),root:GetChild('relicBar'),'click',platform,function()return ''end,function()end,function()end,'map')
local run={data=F.Data,relics={'old_coin'},phase='map',relicCounters={}}
assert(view:open(run,1))
local icon=root:GetChild('relicPanel'):GetChild('single'):GetChild('icon')
local pool=icon.parent:GetChild('iconArt')
assert(pool.visible and not icon.visible,'new relic details art must draw before pool loss')
icon.parent.children.iconArt=nil
view:render()
print('ITEM_ICON_DETAILS_FALLBACK_ACTUAL iconVisible='..tostring(icon.visible)..' image='..tostring(icon.imageId)..' poolUnavailable=true')
assert(icon.visible,'same-item relic details must expose original icon when semantic pool lookup is unavailable')
print('ITEM_ICON_DETAILS_FALLBACK_PASS')
